/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	/*绘制分时图*/
	var ChartTime = __webpack_require__(4);
	/*绘制K线图*/
	var ChartK = __webpack_require__(18);
	/*绘制折线图*/
	var ChartLine = __webpack_require__(26);
	
	/*加载样式文件*/
	__webpack_require__(67);
	
	window.EmchartsMobileTime = ChartTime;
	window.EmchartsMobileK = ChartK;
	window.EmchartsMobileLine = ChartLine;


/***/ },
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制手机分时图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	// 绘制坐标轴
	var DrawXY = __webpack_require__(5);
	// 主题
	var theme = __webpack_require__(7);
	var common = __webpack_require__(8); 
	// 获取分时图数据
	var GetDataTime = __webpack_require__(9); 
	// 绘制分时折线图
	var DrawLine = __webpack_require__(13); 
	// 绘制分时折线图中的平均线
	var DrawAvgCost = __webpack_require__(14); 
	// 绘制成交量图
	var DrawV = __webpack_require__(15);
	// 工具
	var common = __webpack_require__(8); 
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 交互效果
	var Interactive = __webpack_require__(16); 
	// 水印
	var watermark = __webpack_require__(17);
	
	var ChartTime = (function() {
	
	    // 构造函数
	    function ChartTime(options) {
	        this.defaultoptions = theme.chartTime;
	        this.options = {};
	        // this.options = extend(this.defaultoptions, options);
	        extend(true, this.options, theme.defaulttheme, this.defaultoptions, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.onChartLoaded = options.onChartLoaded == undefined ? function(op){
	
	        }:options.onChartLoaded;
	        
	    }
	
	    // 初始化
	    ChartTime.prototype.init = function() {
	
	        this.options.type = "TL";
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        // this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable","on");
	        this.container.style.position = "relative";
	        // 画布
	        var ctx = canvas.getContext('2d');
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr;
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / 8;
	        // 画布内容向坐偏移的距离
	        this.options.padding_left = theme.defaulttheme.padding_left * dpr;
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / 8;
	        // 缩放默认值
	        this.options.scale_count = 0;
	        // 画布上第一个图表的高度
	        this.options.c_1_height = canvas.height * 0.5;
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0",this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr + 0.5;
	        
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	        
	    };
	
	    // 绘图
	    ChartTime.prototype.draw = function(callback) {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        // 初始化交互
	        var inter = this.options.interactive = new Interactive(this.options);
	        // 显示loading效果
	        inter.showLoading();
	        var _this = this;
	        try{
	            
	            GetDataTime(this.options.code,
	                function(data){
	                    if(data){
	                        dataCallback.apply(_this,[data]);
	                    }else{
	                        dataCallback.apply(_this,[[]]);
	                    }
	                    /*绑定事件*/
	                    bindEvent.call(_this,_this.options.context);
	                    // 传入的回调函数
	                    if(callback){
	                        callback();
	                    }
	                    
	                },inter);
	
	        }catch(e){
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	    };
	    // 重绘
	    ChartTime.prototype.reDraw = function() {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        dataCallback.call(this);
	    }
	    /*删除canvas画布*/
	    ChartTime.prototype.clear = function(cb) {
	        if(this.container){
	            this.container.innerHTML = "";
	        }else{
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	    /*回调函数*/
	    function dataCallback(data){
	
	        this.options.data = data == null ? this.options.data : data;
	
	        // 图表交互
	        var inter = this.options.interactive;
	
	        try{
	
	            // 保留的小数位
	            this.options.pricedigit = data.pricedigit || 2;
	            // 获取单位绘制区域
	            var rect_unit = common.get_rect.apply(this,[this.options.context.canvas,this.options.data.total]);
	            this.options.rect_unit = rect_unit;
	
	            // 绘制坐标轴
	            new DrawXY(this.options);
	
	            if(data && data.data && data.data.length > 0){
	                // 绘制分时折线图
	                new DrawLine(this.options);
	                // 绘制分时折线图平均线
	                new DrawAvgCost(this.options);
	            }
	            
	            // 绘制分时图成交量
	            new DrawV(this.options);
	            // 隐藏loading效果
	            inter.hideLoading();
	            // 图表加载完成时间
	            this.onChartLoaded(this);
	
	        }catch(e){
	            // 暂无数据
	            // inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	        // 加水印
	        watermark.apply(this,[this.options.context,170,20 - this.options.canvas.height / 8]);
	
	        return true;
	    }
	
	    // 绑定事件
	    function bindEvent(ctx){
	        var _this = this;
	        var timer_s,timer_m;
	        var canvas = ctx.canvas;
	        var inter = this.options.interactive;
	
	        var delayed = false;
	        var delaytouch = this.options.delaytouch = true;;
	
	        // 触摸事件
	        canvas.addEventListener("touchstart",function(event){
	            // 显示交互效果
	            if(delaytouch){
	                delayed = false;
	                timer_s = setTimeout(function(){
	                    delayed = true;
	                    inter.show();
	                    dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	                    event.preventDefault();
	                },200);
	            }else{
	                inter.show();
	                dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	            }
	
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	
	        });
	        // 手指滑动事件
	        canvas.addEventListener("touchmove",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	                if(delayed){
	                    dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	                    event.preventDefault();
	                }
	            }else{
	                dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	            }
	            
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	
	        });
	         // 手指离开事件
	        canvas.addEventListener("touchend",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	            }
	            // 隐藏交互效果
	            inter.hide();
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	
	        });
	
	        canvas.addEventListener("touchcancel",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	                // delay.style.display = "none";
	            }
	            // 隐藏交互效果
	            inter.hide();
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	        });
	
	
	        // if(!delaytouch){
	            canvas.addEventListener("mousemove",function(event){
	                //console.info(event);
	                dealEvent.apply(_this,[inter,event]);
	                event.preventDefault();
	            });
	
	            canvas.addEventListener("mouseleave",function(event){
	                //console.info(event);
	                inter.hide();
	                event.preventDefault();
	            });
	
	            canvas.addEventListener("mouseenter",function(event){
	                //console.info(event);
	                dealEvent.apply(_this,[inter,event]);
	                inter.show();
	                event.preventDefault();
	            });
	
	        // }
	        
	    }
	    // 处理交互事件
	    function dealEvent(inter,eventposition){
	        // 画布对象
	        var canvas = this.options.canvas;
	        // 分时行情数据
	        var time_data = this.options.data.data;
	        // 单位绘制区域
	        var rect_unit = this.options.rect_unit;
	        // 单位绘图区域的宽度
	        var rect_w = rect_unit.rect_w;
	        // K线柱体的宽度
	        // var bar_w = rect_unit.bar_w;
	
	        // 鼠标事件位置
	        var w_x = eventposition.offsetX || (eventposition.clientX - this.container.getBoundingClientRect().left);
	        var w_y = eventposition.offsetY || (eventposition.clientY - this.container.getBoundingClientRect().top);
	
	        // 鼠标在画布中的坐标
	        var c_pos = common.windowToCanvas.apply(this,[canvas,w_x,w_y]);
	        var c_x = (c_pos.x).toFixed(0);
	        // var c_y = (c_pos.y).toFixed(0);
	
	        // 当前点在数组中的下标
	        var index = Math.floor((c_x - this.options.padding_left)/rect_w);
	
	        if(time_data[index]){
	            // Tip显示行情数据
	            inter.showTip(canvas,w_x,time_data[index]);
	
	            // 显示十字指示线的
	            var cross = common.canvasToWindow.apply(this,[canvas,time_data[index].cross_x,time_data[index].cross_y]);
	            var cross_w_x = cross.x;
	            var cross_w_y = cross.y;
	            inter.cross(canvas,cross_w_x,cross_w_y);
	        }
	
	    }
	
	    return ChartTime;
	})();
	
	module.exports = ChartTime;


/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制直角坐标系
	 */
	var extend = __webpack_require__(6);
	/*主题*/
	var theme = __webpack_require__(7);
	var DrawXY = (function(){
	    //构造方法
	    function DrawXY(options){
	        /*设置默认参数*/
	        this.defaultoptions = theme.draw_xy;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
	    };
	    /*绘图*/
	    DrawXY.prototype.draw = function(){
	        var data = this.options.data;
	        var ctx = this.options.context;
	        var type = this.options.type;
	        // var dpr = this.options.dpr;
	
	        /*Y轴上的最大值*/
	        var y_max = data.max;
	        /*Y轴上的最小值*/
	        var y_min = data.min;
	
	        /*Y轴上分隔线数量*/
	        var sepe_num = this.options.sepe_num;
	        /*开盘收盘时间数组*/
	        var oc_time_arr = data.timeStrs;
	
	        /*K线图的高度*/
	        var k_height = this.options.c_1_height;
	        /*Y轴标识线列表*/
	        var line_list_array = getLineList(y_max, y_min, sepe_num, k_height);
	
	        if(type == "TL"){
	            drawXYTime.call(this,ctx,y_max,y_min,line_list_array);
	        }else{
	            drawXYK.apply(this,[ctx,y_max,y_min,line_list_array]);
	        }
	
	        // 绘制横坐标刻度
	        if(oc_time_arr){
	            drawXMark.apply(this,[ctx,k_height,oc_time_arr]);
	        }
	        
	    };
	    // 绘制分时图坐标轴
	    function drawXYTime(ctx,y_max,y_min,line_list_array){
	        var _this = this;
	        var sepe_num = line_list_array.length;
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	
	            if (i < (sepe_num -1) / 2) {
	                ctx.fillStyle = '#007F24';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	            else if(i > (sepe_num -1) / 2){
	                ctx.fillStyle = '#FF0A16';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	            else{
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = '#cadef8';
	            }
	
	            ctx.moveTo(0, Math.round(item.y));
	            ctx.lineTo(ctx.canvas.width, Math.round(item.y));
	            // 绘制纵坐标刻度
	            if(isNaN(item.num)){
	                ctx.fillText("0.00", 0, item.y - 10);
	            }else{
	                ctx.fillText((item.num).toFixed(this.options.pricedigit), 0, item.y - 10);
	            }
	
	            ctx.stroke();
	            // 绘制纵坐标涨跌幅
	            drawYPercent.call(_this,ctx,y_max, y_min, item);
	        }
	
	    }
	    //绘制K线图坐标轴
	    function drawXYK(ctx,y_max,y_min,line_list_array){
	        var sepe_num = line_list_array.length;
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	
	            if (i < (sepe_num -1) / 2) {
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	            else if(i > (sepe_num -1) / 2){
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	            else{
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	
	            
	            ctx.moveTo(0, Math.round(item.y));
	            ctx.lineTo(ctx.canvas.width, Math.round(item.y));
	            // 绘制纵坐标刻度
	            if(isNaN(item.num)){
	                ctx.fillText("0.00", 0, item.y - 10);
	            }else{
	                ctx.fillText((item.num).toFixed(this.options.pricedigit), 0, item.y - 10);
	            }
	            ctx.stroke();
	        }
	
	    }
	    /*绘制纵坐标涨跌幅*/
	    function drawYPercent(ctx,y_max, y_min, obj){
	        /*纵坐标中间值*/
	        var y_middle = (y_max + y_min)/2;
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        /*纵坐标刻度涨跌幅*/
	        if(y_middle){
	            var percent = ((obj.num - y_middle)/y_middle * 100).toFixed(2) + "%";
	        }else{
	            var percent = "0.00%";
	        }
	        /*绘制纵坐标刻度百分比*/
	        ctx.fillText(percent, k_width - ctx.measureText(percent).width, obj.y - 10);
	        ctx.stroke();
	    }
	    /*绘制横坐标刻度值*/
	    function drawXMark(ctx,k_height,oc_time_arr){
	        // var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        ctx.beginPath();
	        ctx.fillStyle = '#999';
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        var y_date = k_height + ctx.canvas.height/8/2;
	
	        ctx.fillText(oc_time_arr[0], padding_left, y_date);
	        ctx.fillText(oc_time_arr[1], (k_width-padding_left)/2 + padding_left - ctx.measureText(oc_time_arr[1]).width/2, y_date);
	        ctx.fillText(oc_time_arr[2], k_width - ctx.measureText(oc_time_arr[2]).width, y_date);
	        // ctx.moveTo(0,k_height + 10);
	    }
	    /*Y轴标识线列表*/
	    function getLineList(y_max, y_min, sepe_num, k_height) {
	        var ratio = (y_max - y_min) / (sepe_num-1);
	        var result = [];
	        for (var i = 0; i < sepe_num; i++) {
	            result.push({
	                num:  (y_min + i * ratio),
	                x: 0,
	                y: k_height - (i / (sepe_num-1)) * k_height
	            });
	        }
	        return result;
	    }
	    return DrawXY;
	})();
	
	module.exports = DrawXY;

/***/ },
/* 6 */
/***/ function(module, exports) {

	var hasOwn = Object.prototype.hasOwnProperty;
	var toStr = Object.prototype.toString;
	
	var isArray = function isArray(arr) {
		if (typeof Array.isArray === 'function') {
			return Array.isArray(arr);
		}
	
		return toStr.call(arr) === '[object Array]';
	};
	
	var isPlainObject = function isPlainObject(obj) {
		if (!obj || toStr.call(obj) !== '[object Object]') {
			return false;
		}
	
		var hasOwnConstructor = hasOwn.call(obj, 'constructor');
		var hasIsPrototypeOf = obj.constructor && obj.constructor.prototype && hasOwn.call(obj.constructor.prototype, 'isPrototypeOf');
		// Not own constructor property must be Object
		if (obj.constructor && !hasOwnConstructor && !hasIsPrototypeOf) {
			return false;
		}
	
		// Own properties are enumerated firstly, so to speed up,
		// if last one is own, then all properties are own.
		var key;
		for (key in obj) { /**/ }
	
		return typeof key === 'undefined' || hasOwn.call(obj, key);
	};
	
	module.exports = function extend() {
		var options, name, src, copy, copyIsArray, clone;
		var target = arguments[0];
		var i = 1;
		var length = arguments.length;
		var deep = false;
	
		// Handle a deep copy situation
		if (typeof target === 'boolean') {
			deep = target;
			target = arguments[1] || {};
			// skip the boolean and the target
			i = 2;
		} else if ((typeof target !== 'object' && typeof target !== 'function') || target == null) {
			target = {};
		}
	
		for (; i < length; ++i) {
			options = arguments[i];
			// Only deal with non-null/undefined values
			if (options != null) {
				// Extend the base object
				for (name in options) {
					src = target[name];
					copy = options[name];
	
					// Prevent never-ending loop
					if (target !== copy) {
						// Recurse if we're merging plain objects or arrays
						if (deep && copy && (isPlainObject(copy) || (copyIsArray = isArray(copy)))) {
							if (copyIsArray) {
								copyIsArray = false;
								clone = src && isArray(src) ? src : [];
							} else {
								clone = src && isPlainObject(src) ? src : {};
							}
	
							// Never move original objects, clone them
							target[name] = extend(deep, clone, copy);
	
						// Don't bring in undefined values
						} else if (typeof copy !== 'undefined') {
							target[name] = copy;
						}
					}
				}
			}
		}
	
		// Return the modified object
		return target;
	};

/***/ },
/* 7 */
/***/ function(module, exports) {

	/**
	 * 默认主题
	 */
	
	var defaultopions = {
		defaulttheme:{
			spacing:0.4, //K线柱体的间距比例，取值范围[0,1]
			padding_left:30,//画布的左内边距
			k_v_away:30,//K线图表和成交量之间的间距
			canvas_offset_top:40,//画布的上内边距
			point_width:2,
			font_size:12,//默认字体大小
			point_color:"#8f8f8f",//鼠标指示线交点颜色
			up_color:"#ff0000",
			down_color:"#17b03e"
		},
		// 分时线图表配置参数
		chartTime:{
			crossline:true
		},
		// K线图表配置参数
		chartK:{
			crossline:false
		},
		// 折线图表配置参数
		chartLine:{
	        showPoint:false,	//是否显示折线图上的节点
	        canvasPaddingTop:10, //画布的上内边距
	        canvasPaddingLeft:20, //画布的左内边距
	        pointRadius:10,
	        lineMarkWidth:15
		},
		// 坐标轴配置参数
		draw_xy:{
	        axis_color:"#fff", //坐标轴颜色
	        y_max:100,//纵坐标最小值
	        y_min:0,//纵坐标最小值
	        sepe_num:5, 	//沿Y轴平均分割线的个数
	        y_padding_per:0.05, //画布上线内间距占(y_max - y_min)的比例
	        date_offset_top:15//横坐标轴上的日期刻度
		},
		// web的坐标轴配置参数
		draw_xy_web:{
			spacing:0.4, //K线柱体的间距比例，取值范围[0,1]
			padding_left:30,//画布的左内边距
			k_v_away:30,//K线图表和成交量之间的间距
			canvas_offset_top:40,//画布的上内边距
			point_width:5,
			font_size:12,//默认字体大小
			point_color:"#8f8f8f",//鼠标指示线交点颜色
			up_color:"#ff0000",
			down_color:"#17b03e",
	        axis_color:"#fff", //坐标轴颜色
	        y_max:100,//纵坐标最小值
	        y_min:0,//纵坐标最小值
	        sepe_num:9, 	//沿Y轴平均分割线的个数
	        y_padding_per:0.05, //画布上线内间距占(y_max - y_min)的比例
	        date_offset_top:15,//横坐标轴上的日期刻度
	        crossline:true
		},
		// 分时图配置参数
		draw_line:{
	     	avg_cost_color:"#f1ca15"   //平均线的颜色
		},
		draw_k:{
	        
		},
		draw_ma:{
	        
		},
		// 成交量配置参数
		draw_v:{
	        
		},
		// 图表交互
		interactive:{
	
		}
	};
	
	module.exports = defaultopions;

/***/ },
/* 8 */
/***/ function(module, exports) {

	var common = {
	    // 由股票代码判断股票上市场所，1(沪市)或2(深市)或5(港股)
	    getMktByCode: function(code) {
	        if (code.Length < 3)
	            return code + "1";
	        var one = code.substr(0, 1);
	        var three = code.substr(0, 3);
	        if (one == "5" || one == "6" || one == "9") {
	            return code + "1";
	        } else {
	            if (three == "009" || three == "126" || three == "110" || three == "201" || three == "202" || three == "203" || three == "204") {
	                return code + "1";
	            } else {
	                return code + "2";
	            }
	        }   
	    },
	    // 数字标准化，字符串输出，例如：9----->09
	    fixed: function(str, len) {
	        var i = 0;
	        str = str.toString();
	        var result = str;
	        for (i = 0; i < len - str.length; i++) {
	            result = '0' + result;
	        }
	
	        return result;
	    },
	    // 日期标准化，字符串输出，例如: 20121112---->2012-11-12
	    transform: function(str) {
	        return str.replace(/(\d{4})(\d{2})(\d{2})/g, function(whole, a, b, c) {
	            return a + "-" + b + "-" + c;
	        });
	    },
	    // 将鼠标坐标转换为Canvas坐标
	    windowToCanvas: function(canvas,x,y){
	        // var box = canvas.getBoundingClientRect();
	        return {
	            // x:(x-box.left)*(canvas.width/box.width),
	            // y:(y-box.top)*(canvas.height/box.height)
	
	            x: x*this.options.dpr,
	            y: y*this.options.dpr
	        };
	    },
	    // 将Canvas坐标转换为鼠标坐标
	    canvasToWindow: function(canvas,x,y){
	        var box = canvas.getBoundingClientRect();
	        // 相对于窗口
	        // return {
	        //     x:(x *(box.width/canvas.width)+box.left),
	        //     y:(y *(box.height/canvas.height)+box.top + this.options.canvas_offset_top/this.options.dpr)
	        // };
	        return {
	            x:x/this.options.dpr,
	            // x:x * (box.width/canvas.width),
	            y:(y+this.options.canvas_offset_top) * (box.height/canvas.height)
	        };
	    },
	    // 图表y轴坐标计算
	    get_y: function(y) {
	        return this.options.c_1_height - (this.options.c_1_height * (y - this.options.data.min)/(this.options.data.max - this.options.data.min));
	    },
	    // 图表x轴坐标计算
	    get_x: function(x) {
	        var canvas = this.options.context.canvas;
	        var type = this.options.type;
	        var rect_w = this.options.rect_unit.rect_w;
	        var num = this.options.data.data.length;
	        var total = this.options.data.total;
	        var padding_left = this.options.padding_left;
	        // var dpr = this.options.dpr;
	
	        if(type == "TL"){
	            return (canvas.width-padding_left) / total * x + padding_left;
	        }else{
	            return (canvas.width-padding_left) / num * x + padding_left - (rect_w/2);
	        }
	        
	    },
	    // 图表x轴坐标计算
	    get_rect: function(canvas,num) {
	        var rect_w = (canvas.width-this.options.padding_left) / num;
	        var bar_w = rect_w * (1 - this.options.spacing);
	        return {
	            rect_w:rect_w,
	            bar_w:bar_w
	        };
	    },
	    // 格式化数据单位
	    format_unit: function(value,num){
	        num = num == undefined ? 2 : num;
	        var flag = false;
	        if(value < 0){
	            value = Math.abs(value);
	            flag = true;
	        }
	
	        if(flag){
	            if (value < 10000) {
	                return value * -1;
	            } else if (value >= 10000 && value < 100000000) {
	                return (value / 10000).toFixed(num) * -1 + "万";
	            } else if (value >= 100000000) {
	                return (value / 100000000).toFixed(num) * -1 + "亿";
	            } else {
	                return value * -1;
	            }
	
	        }else{
	            if (value < 10000) {
	                return value;
	            } else if (value >= 10000 && value < 100000000) {
	                return (value / 10000).toFixed(num) + "万";
	            } else if (value >= 100000000) {
	                return (value / 100000000).toFixed(num) + "亿";
	            } else {
	                return value;
	            }
	        }
	    },
	    /**
	     * 兼容性的事件添加
	     * @param {[type]}   obj  对哪个元素添加
	     * @param {[type]}   type 事件类型
	     * @param {Function} fn   事件触发的处理函数
	     */
	    addEvent: function(obj, type, fn) {
	        if (obj.attachEvent) {
	            obj['e' + type + fn] = fn;
	            obj[type + fn] = function() { obj['e' + type + fn](window.event); }
	            obj.attachEvent('on' + type, obj[type + fn]);
	        } else
	            obj.addEventListener(type, fn, false);
	    },
	    removeEvent: function(obj, type, fn) {
	        if (obj.detachEvent) {
	            obj.detachEvent('on' + type, obj[type + fn]);
	            obj[type + fn] = null;
	        } else
	            obj.removeEventListener(type, fn, false);
	    }
	
	};
	module.exports = common;


/***/ },
/* 9 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获取手机分时图数据
	 * 返回数据对象
	 *   result{
	 *      name://股票名字
	 *      data: [//当前各个时间点
	 *          {   //一个对象代表一个点
	 *              price:价格：45.50
	 *              time:时间: 10:00
	 *              volume:换手数 12000
	 *              percent:涨跌百分比 -8.9%
	 *              up:涨跌标志: false(跌)
	 *              isCR:false(不包含盘前数据),true(包含盘前数据)
	 *          }   
	 *      ]
	 *      v_max: //最大成交量
	 *      max://坐标最大值
	 *      min://坐标最小值
	 *      yc://昨收
	 *   }
	 */
	
	var dealdata = __webpack_require__(10); //处理数据
	var coordinate = __webpack_require__(11); //处理数据
	var fix = __webpack_require__(8).fixed;
	
	var jsonp = __webpack_require__(12);
	
	
	function getdata(id, callback, interactive) {
	
	    var url = 'http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js';
	    var callbackstring = 'fsdata';
	    var urldata = {
	        id: id,
	        TYPE: 'R',
	        js: callbackstring + '((x))',
	        'rtntype': 5,
	        isCR :false
	    };
	    jsonp(url, urldata, callbackstring, function(json) {
	        try{
	            if (!json) {
	                callback(null);
	            } else {
	                //拿到股票的数据
	                var info = json.info;
	                // var dataArray = json.data;
	                var ticks = info.ticks.split('|');
	
	                // 保留小数位
	                if(info.pricedigit.split(".").length > 1){
	                    window.pricedigit = info.pricedigit.split(".")[1].length == 0 ? 2 : info.pricedigit.split(".")[1].length;
	                }else{
	                    window.pricedigit = 0;
	                }
	
	                var result = {};
	
	                //股票名称
	                result.name = json.name;
	                //总比数
	                result.total = info.total;
	
	                var returnData = dealdata(json, info.yc)
	                //股票数据
	                result.data = returnData[0];
	
	                //最下面的时间
	                result.timeStrs = [];
	                var morning_start_hour = Math.floor(ticks[0] / 3600) > 24 ? (Math.floor(ticks[0] / 3600) - 24) : Math.floor(ticks[0] / 3600);
	
	                result.timeStrs.push(fix(morning_start_hour, 2) + ":" + fix((ticks[0] / 60) % 60, 2));
	
	                var morning_end_hour = Math.floor(ticks[4] / 3600) > 24 ? (Math.floor(ticks[4] / 3600) - 24) : Math.floor(ticks[4] / 3600);
	
	                if(ticks.length <= 5){
	                    result.timeStrs.push("");
	                }else{
	                    var afternoon_start_hour = Math.floor(ticks[5] / 3600) > 24 ? (Math.floor(ticks[5] / 3600) - 24) : Math.floor(ticks[5] / 3600);
	                    result.timeStrs.push(fix(morning_end_hour, 2) + ":" + fix((ticks[4] / 60) % 60, 2) + " / " + fix(afternoon_start_hour) + ":" + fix((ticks[5] / 60) % 60, 2));
	                }
	                
	                var afternoon_end_hour = Math.floor(ticks[1] / 3600) > 24 ? (Math.floor(ticks[1] / 3600) - 24) : Math.floor(ticks[1] / 3600);
	                result.timeStrs.push(fix(afternoon_end_hour, 2) + ":" + fix((ticks[1] / 60) % 60, 2));
	                //坐标的最大最小值
	                result.max = coordinate(returnData[1], returnData[2], info.yc).max;
	                //坐标的最小值
	                result.min = coordinate(returnData[1], returnData[2], info.yc).min;
	                //昨收
	                result.yc = info.yc;
	
	                // 保留小数位
	                result.pricedigit = window.pricedigit;
	
	                callback(result);
	            }
	
	        }catch(e){
	            // 暂无数据
	            interactive.showNoData();
	            // 隐藏loading效果
	            interactive.hideLoading();
	        }
	
	    });
	}
	
	module.exports = getdata;


/***/ },
/* 10 */
/***/ function(module, exports) {

	/**
	 * [dealData description]
	 * @return [
	 *         data1:{
	 *         		价格：price
	 *         		时间:time
	 *         		换手数:volume
	 *         		涨跌百分比: percent
	 *         		涨跌标志:up?
	 *              平均成本：avg_cost
	 *              成交量最大值：v_max
	 *         }]
	 * 
	 */
	var dealData = function(json, yc) {
	    // var info = json.info;
	    var arryData = json.data;
		var result = [];
	    var v_max = 0;
	    var max = 0;
	    var min = 0;
	    var total_cost = 0;//成交总额
	    var total_num = 0;//成交总量
	
	    for (var i = 0; i < arryData.length; i++) {
	        var items = arryData[i].split(",");
	        v_max = v_max > Number(items[2])? v_max: Number(items[2]);
	
	        if(i == 0){
	            max = min = Number(items[1]);
	        }
	
	        // if(items[1] >= items[3]){
	        //     var _max = items[1];
	        //     var _min = items[3];
	        // }else{
	        //     var _min = items[1];
	        //     var _max = items[3];
	        // }
	        
	        max = Math.max(max,items[1]);
	        min = Math.min(min,items[1]);
	
	        var point = {};
	        point.time = items[0].split(" ")[1];
	        point.price = items[1];
	      
	        point.volume = Number((Number(items[2])).toFixed(0));
	        //计算平均成本
	        // total_num += Number(items[2]);
	        // total_cost += Number(items[2])*parseFloat(items[1]);
	        // point.avg_cost = parseFloat((total_cost/total_num).toFixed(pricedigit));
	        point.avg_cost = items[3];
	
	        if (i != 0) {
	            // point.percent = ((items[1] - arryData[i - 1].split(',')[1]) / items[1] * 100).toFixed(2);
	            point.percent = ((items[1] - yc) / yc * 100).toFixed(2);
	            // point.up = items[1] - arryData[i - 1].split(',')[1] > 0 ? true : false;
	            point.up = items[1] - yc > 0 ? true : false;
	        }else{
	        	point.percent = ((items[1] - yc) / yc * 100).toFixed(2);
	        	point.up = items[1] - yc > 0 ? true : false;
	        }
	        result.push(point);
	    }
	    result.v_max = Number((v_max).toFixed(0));
	
	    return [result, max, min];
	};
	
	module.exports = dealData;


/***/ },
/* 11 */
/***/ function(module, exports) {

	/**
	 * 分时图坐标上下限算法
	 */
	
	/*
	1.遍历出当前价的最高(high),最低点(low)
	2.和昨收(pre)价进行比较
		Math.Abs(pre-high)   
		Math.Abs(pre-low)  
			取两个中比较大的值 设为offset
				top=pre+offset*1.05;
				fall=pre-offset*1.05;
		
		同时满足如果fall<=0则为fall=0
		如果high==low==pre则
			top=pre*1.08
			fall=pre*0.92
	
		如果pre==0 则top==fall==0
	 */
	
	/**
	 * 分时图坐标上下限
	 * @param  {[type]} high 最高
	 * @param  {[type]} low 最低
	 * @param  {[type]} pre  昨收
	 */
	function coordinate(high, low, pre) {
		var top = 0;
		var fall = 0;
		var offset = Math.max(Math.abs(pre - high), Math.abs(pre - low));
	
		top = Number(pre) + offset * 1.05;
		fall = Number(pre) - offset * 1.05;
		if ( fall <= 0 ) {
			fall = 0;
		}
		if ( high == low && low == pre ) {
			top = pre * 1.08;
			fall = pre * 0.92;
		}
		if ( pre == 0 ) {
			top = 0;
			fall = 0;
		}
	
		return { max: top, min: fall };
	}
	
	module.exports = coordinate;

/***/ },
/* 12 */
/***/ function(module, exports) {

	/**
	 * jsonp
	 * 使用说明 jsonp([uri], [data], [custom_method_name], [callback(json)])
	 */
	
	/**
	 * JSONP sets up and allows you to execute a JSONP request
	 * @param {String} url  The URL you are requesting with the JSON data
	 * @param {Object} data The Data object you want to generate the URL params from
	 * @param {String} method  The method name for the callback function. Defaults to callback (for example, flickr's is "jsoncallback")
	 * @param {Function} callback  The callback you want to execute as an anonymous function. The first parameter of the anonymous callback function is the JSON
	 *
	 * @example
	 * JSONP('http://twitter.com/users/oscargodson.json',function(json){
	 *  document.getElementById('avatar').innerHTML = '<p>Twitter Pic:</p><img src="'+json.profile_image_url+'">';
	 * });
	 *
	 * @example
	 * JSONP('http://api.flickr.com/services/feeds/photos_public.gne',{'id':'12389944@N03','format':'json'},'jsoncallback',function(json){
	 *  document.getElementById('flickrPic').innerHTML = '<p>Flickr Pic:</p><img src="'+json.items[0].media.m+'">';
	 * });
	 *
	 * @example
	 * JSONP('http://graph.facebook.com/FacebookDevelopers', 'callback', function(json){
	 *  document.getElementById('facebook').innerHTML = json.about;
	 * });
	 */
	
	  var JSONP = function(url,data,method,callback){
	    //Set the defaults
	    url = url || '';
	    data = data || {};
	    method = method || '';
	    callback = callback || function(){};
	    
	    //Gets all the keys that belong
	    //to an object
	    var getKeys = function(obj){
	      var keys = [];
	      for(var key in obj){
	        if (obj.hasOwnProperty(key)) {
	          keys.push(key);
	        }
	        
	      }
	      return keys;
	    }
	
	    //Turn the data object into a query string.
	    //Add check to see if the second parameter is indeed
	    //a data object. If not, keep the default behaviour
	    if(typeof data == 'object'){
	      var queryString = '';
	      var keys = getKeys(data);
	      for(var i = 0; i < keys.length; i++){
	        queryString += encodeURIComponent(keys[i]) + '=' + encodeURIComponent(data[keys[i]])
	        if(i != keys.length - 1){ 
	          queryString += '&';
	        }
	      }
	      url += '?' + queryString;
	    } else if(typeof data == 'function'){
	      method = data;
	      callback = method;
	    }
	
	    //If no method was set and they used the callback param in place of
	    //the method param instead, we say method is callback and set a
	    //default method of "callback"
	    if(typeof method == 'function'){
	      callback = method;
	      method = 'callback';
	    }
	  
	    //Check to see if we have Date.now available, if not shim it for older browsers
	    if(!Date.now){
	      Date.now = function() { return new Date().getTime(); };
	    }
	
	    //Use timestamp + a random factor to account for a lot of requests in a short time
	    //e.g. jsonp1394571775161 
	    var timestamp = Date.now();
	    var generatedFunction = 'jsonp'+Math.round(timestamp+Math.random()*1000001);
	    if (typeof method == 'string') {
	    	generatedFunction = method;
	    }
	
	    //Generate the temp JSONP function using the name above
	    //First, call the function the user defined in the callback param [callback(json)]
	    //Then delete the generated function from the window [delete window[generatedFunction]]
	    window[generatedFunction] = function(json){
	      callback(json);
	
	      // IE8 throws an exception when you try to delete a property on window
	      // http://stackoverflow.com/a/1824228/751089
	      try {
	        document.getElementsByTagName("head")[0].removeChild(jsonpScript);
	        delete window[generatedFunction];
	      } catch(e) {
	        window[generatedFunction] = undefined;
	      }
	
	    };
	
	    //Check if the user set their own params, and if not add a ? to start a list of params
	    //If in fact they did we add a & to add onto the params
	    //example1: url = http://url.com THEN http://url.com?callback=X
	    //example2: url = http://url.com?example=param THEN http://url.com?example=param&callback=X
	    if(url.indexOf('?') === -1){ url = url+'?'; }
	    else{ url = url+'&'; }
	  
	    //This generates the <script> tag
	    var jsonpScript = document.createElement('script');
	    jsonpScript.setAttribute("src", url+method+'='+generatedFunction);
	    document.getElementsByTagName("head")[0].appendChild(jsonpScript)
	  }
	 module.exports = JSONP;


/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制K线
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	/*继承*/
	var extend = __webpack_require__(6);
	/*主题*/
	var theme = __webpack_require__(7);
	/*工具*/
	var common = __webpack_require__(8);
	var DrawLine = (function(){
		function DrawLine(options){
			/*设置默认参数*/
	        this.defaultoptions = theme.draw_line;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
		};
		
		/*绘图*/
		DrawLine.prototype.draw = function(){
	
			var ctx = this.options.context;
			var data = this.options.data;
			var data_arr = data.data;
			
			drawStroke.apply(this,[ctx,data_arr]);
			drawFill.apply(this,[ctx,data_arr]);
		};
		/*绘制分时线*/
		function drawStroke(ctx,data_arr){
			ctx.beginPath();
		 	
			// ctx.strokeStyle = "rgba(0,0,0,0)";
			ctx.strokeStyle = "#3f88e5";
			
			// var data_arr_length = data_arr.length;
			for(var i = 0,item;item = data_arr[i]; i++){
				 var x = common.get_x.call(this,i + 1);
				 var y = common.get_y.call(this,item.price);
			 	 ctx.lineTo(x,y);
				 item.cross_x = x;
				 item.cross_y = y;
			}
			ctx.stroke();
		}
		/*分时线填充渐变色*/
		function drawFill(ctx,data_arr){
			var y_min = common.get_y.call(this,this.options.data.min);
			/* 指定渐变区域 */
	        var grad  = ctx.createLinearGradient(0,0,0,ctx.canvas.height);
	        /* 指定几个颜色 */
	        grad.addColorStop(0,'rgba(221,234,250,0.7)');
	        grad.addColorStop(1,'rgba(255,255,255,0)');
	        var data_arr_length = data_arr.length;
	
			ctx.beginPath();
			ctx.fillStyle = grad;
			ctx.moveTo(this.options.padding_left,y_min);
	
			for(var i = 0,item;item = data_arr[i]; i++){
				 var x = common.get_x.call(this,i + 1);
				 var y = common.get_y.call(this,item.price);
				 if(i == data_arr_length - 1){
				 	ctx.lineTo(x,y_min);
				 }else{
				 	ctx.lineTo(x,y);
				 }
			}
			ctx.fill();
		}
		return DrawLine;
	})();
	
	module.exports = DrawLine;

/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制分时图平均成本线
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 主题
	var theme = __webpack_require__(7);
	// 工具
	var common = __webpack_require__(8);
	var Draw_Avg_Cost = (function () {
		function Draw_Avg_Cost(options){
			// 设置默认参数
	        this.defaultoptions = theme.draw_line;
	        this.options = {};
	        extend(true,this.options,this.defaultoptions, options);
	        // 绘图
	        this.draw();
		}
	
		Draw_Avg_Cost.prototype.draw = function() {
			var ctx = this.options.context;
			var data = this.options.data;
			this.options.height = ctx.canvas.height * theme.defaulttheme.c_h_percent;
			// 绘制平均线
			this.draw_k(ctx,data);
		};
		// 绘制平均线
		Draw_Avg_Cost.prototype.draw_k = function(ctx,data) {
			var color = this.options.avg_cost_color;
			var data_arr = data.data;
			// var w = this.options.width - 30;
			ctx.beginPath();
			ctx.lineWidth = 1;
			ctx.strokeStyle = color;
			ctx.fillStyle = '';
			for(var i = 0;i<data_arr.length;i++) {
				var x = common.get_x.call(this,i+1);
				var y = common.get_y.call(this,data_arr[i].avg_cost);
				if(i == 0){
					ctx.moveTo(x,y);
				}
				else {
					ctx.lineTo(x,y);
				}
				
			}
			ctx.stroke();
			
		};
	
		return Draw_Avg_Cost
	})()
	
	module.exports = Draw_Avg_Cost;

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	/*继承*/
	var extend = __webpack_require__(6);
	/*工具*/
	var common = __webpack_require__(8);
	/*主题*/
	var theme = __webpack_require__(7);
	var DrawV = (function(){
		function DrawV(options){
			/*设置默认参数*/
			this.defaultoptions = theme.draw_v;
			this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
			/*绘图*/
			this.draw();
		};
		
		/*绘图*/
		DrawV.prototype.draw = function(){
			if(this.options.type == "TL") {
				/*绘制分时图成交量*/
				drawVTime.call(this);
			}else{
				/*绘制K线图成交量*/
				drawVK.call(this);
			}
			
		};
		/*绘制分时图成交量*/
		function drawVTime(){
			var ctx = this.options.context;
			var data = this.options.data;
			/*成交量数组*/
			var data_arr = data.data;
			var v_height = ctx.canvas.height / 4;
			var v_base_height = v_height * 0.9;
			var y_v_bottom = ctx.canvas.height - this.options.canvas_offset_top;
			var y_v_top = y_v_bottom - v_height;
	
			if(!data_arr || data_arr.length == 0){
				ctx.beginPath();
				ctx.fillStyle = '#999';
				ctx.strokeStyle = 'rgba(230,230,230, 1)';
				ctx.fillText(0,0,y_v_top + 10);
				ctx.rect(this.options.padding_left,y_v_top,ctx.canvas.width - this.options.padding_left -2,v_height);
				ctx.stroke();
				return;
			}
	
			if(this.options.type == "TL") {
				this.options.data.v_max = getVMax(this.options.data);
			}
	
			/*Y轴上的最大值*/
			// var y_max = data.max;
			/*Y轴上的最小值*/
			// var y_min = data.min;
			/*最大成交量*/
			var v_max = (data.v_max).toFixed(0);
			
			/*K线图表的高度*/
			// var c_1_height = this.options.c_1_height;
			//成交量图表的高度
			// var v_height = ctx.canvas.height - c_1_height - this.options.k_v_away - this.options.canvas_offset_top;
			
			/*获取单位矩形对象*/
			var rect_unit = this.options.rect_unit;
			/*单位绘图矩形画布的宽度*/
			// var rect_w = rect_unit.rect_w;
			/*K线柱体的宽度*/
			var bar_w = rect_unit.bar_w;
			/*K线柱体的颜色*/
			var up_color = this.options.up_color;
			var down_color =this.options.down_color
	
			//标识最大成交量
			markVMax.apply(this,[ctx,v_max,y_v_top]);
	
			ctx.strokeStyle = 'rgba(230,230,230, 1)';
			ctx.lineWidth = this.options.dpr;
			ctx.rect(this.options.padding_left,y_v_top,ctx.canvas.width - this.options.padding_left -2,v_height);
			ctx.stroke();
	
			ctx.lineWidth = 1;
			for(var i = 0,item; item = data_arr[i]; i++){
	
				var volume = item.volume;
				var is_up = item.up;
				var bar_height = volume/v_max * v_base_height;
				var x = common.get_x.call(this,i + 1);
				var y = y_v_bottom - bar_height;
	
				ctx.beginPath();
				ctx.moveTo(x,y);
	
				if(i == 0){
					if(is_up){
						ctx.fillStyle = up_color;
						ctx.strokeStyle = up_color;
					}else{
						ctx.fillStyle = down_color;
						ctx.strokeStyle = down_color;
					}
				}else{
					if(item.price >= data_arr[i - 1].price){
						ctx.fillStyle = up_color;
						ctx.strokeStyle = up_color;
					}else{
						ctx.fillStyle = down_color;
						ctx.strokeStyle = down_color;
					}
				}
	
				ctx.rect(x - bar_w/2,y,bar_w,bar_height);
				ctx.stroke();
				ctx.fill();
			}
	
		}
		/*绘制K线图成交量*/
		function drawVK(){
			var ctx = this.options.context;
			var data = this.options.data;
			/*成交量数组*/
			var data_arr = data.data;
			var v_height = ctx.canvas.height / 4;
			var v_base_height = v_height * 0.9;
			var y_v_bottom = ctx.canvas.height - this.options.canvas_offset_top;
			var y_v_top = y_v_bottom - v_height;
			if(!data_arr || data_arr.length == 0){
				ctx.beginPath();
				ctx.fillStyle = '#999';
				ctx.strokeStyle = 'rgba(230,230,230, 1)';
				ctx.fillText(0,0,y_v_top + 10);
				ctx.rect(this.options.padding_left,y_v_top,ctx.canvas.width - this.options.padding_left -2,v_height);
				ctx.stroke();
				return;
			}
	
	
			/*Y轴上的最大值*/
			// var y_max = data.max;
			/*Y轴上的最小值*/
			// var y_min = data.min;
			/*最大成交量*/
			var v_max = (data.v_max).toFixed(0);
			
			/*K线图表的高度*/
			// var c_1_height = this.options.c_1_height;
			//成交量图表的高度
			// var v_height = ctx.canvas.height - c_1_height - this.options.k_v_away - this.options.canvas_offset_top;
			
			/*获取单位矩形对象*/
			var rect_unit = this.options.rect_unit;
			/*单位绘图矩形画布的宽度*/
			// var rect_w = rect_unit.rect_w;
			/*K线柱体的宽度*/
			var bar_w = rect_unit.bar_w;
			/*K线柱体的颜色*/
			var up_color = this.options.up_color;
			var down_color =this.options.down_color
	
			//标识最大成交量
			markVMax.apply(this,[ctx,v_max,y_v_top]);
	
			ctx.strokeStyle = 'rgba(230,230,230, 1)';
			ctx.lineWidth = this.options.dpr;
			ctx.rect(this.options.padding_left,y_v_top,ctx.canvas.width - this.options.padding_left -2,v_height);
			ctx.stroke();
	
			ctx.lineWidth = 1;
			for(var i = 0,item; item = data_arr[i]; i++){
	
				var volume = item.volume;
				var is_up = item.up;
				var bar_height = volume/v_max * v_base_height;
				var x = common.get_x.call(this,i + 1);
				var y = y_v_bottom - bar_height;
	
				ctx.beginPath();
				ctx.moveTo(x,y);
	
				if(is_up){
					ctx.fillStyle = up_color;
					ctx.strokeStyle = up_color;
				}else{
					ctx.fillStyle = down_color;
					ctx.strokeStyle = down_color;
				}
	
				ctx.rect(x - bar_w/2,y,bar_w,bar_height);
				ctx.stroke();
				ctx.fill();
			}
	
		}
		// 标识最大成交量
		function markVMax(ctx,v_max,y_v_end){
			ctx.beginPath();
			ctx.fillStyle = '#999';
			ctx.fillText(common.format_unit(v_max),0,y_v_end + 10);
			ctx.stroke();
		}
		// 获取最大成交量
		function getVMax(data){
			if(data.data[0]){
				var max = data.data[0].volume;
			}else{
				var max = 0;
			}
			
			for(var i = 0,item = data.data;i<data.data.length;i++) {
				if(max<item[i].volume)
				{
					max=item[i].volume;
				}
			}
			return max
		}
	
		return DrawV;
	})();
	
	module.exports = DrawV;

/***/ },
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 图表交互
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 *
	 * 	   cross: 	十字指示线dom对象
	 * 	   mark_ma: 	均线标识dom对象
	 * 	   scale: 	缩放dom对象
	 * }
	 *
	 */
	
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 工具模块
	var common = __webpack_require__(8); 
	// 主题
	var theme = __webpack_require__(7);
	
	var Interactive = (function() {
	
		// 构造函数
	    function Interactive(options) {
	        this.defaultoptions = theme.interactive;
	        this.options = {};
	        this.options = extend(true,this.options,this.defaultoptions, options);
	    }
	
	  	// 鼠标十字标识线
		Interactive.prototype.cross = function(canvas,w_x,w_y){
		    var c_box = canvas.getBoundingClientRect();
		    var dpr = this.options.dpr;
	
			if(!this.options.cross){
		        this.options.cross = {};
				/*Y轴标识线*/
		        var y_line = document.createElement("div");
		        y_line.className = "cross-y";
		        y_line.style.height = c_box.height + "px";
		        y_line.style.top = "0px";
		        this.options.cross.y_line = y_line;
	
		        /*X轴标识线*/
		        var x_line = document.createElement("div");
		        x_line.className = "cross-x";
		        x_line.style.width = canvas.width/dpr + "px";
		        this.options.cross.x_line = x_line;
	
		        /*X轴和Y轴标示线相交点*/
		        var point = document.createElement("div");
		        point.className = "cross-p";
		        point.style.width = point.style.height = this.options.point_width + "px";
		        point.style.borderRadius = point.style.width;
		        point.style.backgroundColor = this.options.point_color;
		        this.options.cross.point = point;
		        /*创建文档碎片*/
		        var frag = document.createDocumentFragment();
		        
		        // if(this.options.type == "TL"){
		        if(this.options.crossline){
		        	frag.appendChild(x_line);
		        	frag.appendChild(y_line);
		        	frag.appendChild(point);
		        }else{
		        	frag.appendChild(y_line);
		        }
		     	document.getElementById(this.options.container).appendChild(frag);
		     }
		     	var y_line = this.options.cross.y_line;
			 	if(y_line){
			 		y_line.style.left = w_x + "px";
			 	}
			 	var x_line = this.options.cross.x_line;
			 	if(x_line){
			 		x_line.style.top = w_y + "px";
			 	}
			 	var point = this.options.cross.point;
			 	if(point){
			 		var p_w = this.options.point_width;
			 		point.style.left = w_x - p_w/2 + "px";
			 		point.style.top = w_y - p_w/2 + "px";
			 	}
		}
	
		// 绘制移动平均线标识
		Interactive.prototype.markMA = function (canvas,obj_5,obj_10,obj_20){
		    // var c_box = canvas.getBoundingClientRect();
		    // var dpr = this.options.dpr;
		    if(!this.options.mark_ma){
		        this.options.mark_ma = {};
		        var div_mark = document.createElement("div"); 
		        div_mark.className = "mark-ma";
		        div_mark.style.top = "5px";
		        this.options.mark_ma.mark_ma = div_mark;
		        
		        /*创建文档碎片*/
		        var frag = document.createDocumentFragment();
	
		        /*5日均线*/
		        var ma_5_data = document.createElement('span');
		        ma_5_data.className = "span-m5";
		        if(obj_5){
		            ma_5_data.innerText = "MA5: " + obj_5.value;
		        }else{
		        	if(this.default_m5){
		        		ma_5_data.innerText = "MA5: " + this.default_m5.value;
		        	}else{
		        		ma_5_data.innerText = "MA5: -";
		        	}
		        }
		        this.options.mark_ma.ma_5_data = ma_5_data;
		       
		        /*10日均线*/
		        var ma_10_data = document.createElement('span');
		        ma_10_data.id = "ma_10_data";
		        ma_10_data.className = "span-m10";
		        if(obj_10){
		            ma_10_data.innerText = "MA10: " + obj_10.value;
		        }else{
		        	if(this.default_m10){
						ma_10_data.innerText = "MA10: " + this.default_m10.value;
		        	}else{
		        		ma_10_data.innerText = "MA10: -";
		        	}
		        }
		        this.options.mark_ma.ma_10_data = ma_10_data;
	
		        /*20日均线*/
		        var ma_20_data = document.createElement('span');
		        ma_20_data.id = "ma_20_data";
		        ma_20_data.className = "span-m20";
		        if(obj_20){
		            ma_20_data.innerText = "MA20: " + obj_20.value;
		        }else{
		        	if(this.default_m20){
		        		ma_20_data.innerText = "MA20: " + this.default_m20.value;
		        	}else{
		        		ma_20_data.innerText = "MA20: -";
		        	}
		        }
		        this.options.mark_ma.ma_20_data = ma_20_data;
	
		        frag.appendChild(ma_5_data);
		        frag.appendChild(ma_10_data);
		        frag.appendChild(ma_20_data);
		        div_mark.appendChild(frag);
		        document.getElementById(this.options.container).appendChild(div_mark);
		        // div_tip.style.left = w_pos.x - 300 + "px";
		    }else{
		        var div_mark = this.options.mark_ma.mark_ma; 
		        if(obj_5){
		           this.options.mark_ma.ma_5_data.innerText = "MA5: " + obj_5.value;
		        }else{
		        	if(this.default_m5){
		        		this.options.mark_ma.ma_5_data.innerText = "MA5: " + this.default_m5.value;
		        	}else{
		        		this.options.mark_ma.ma_5_data.innerText = "MA5: -";
		        	}
		        }
	
		        if(obj_10){
		            this.options.mark_ma.ma_10_data.innerText = "MA10: " + obj_10.value;
		        }else{
		        	if(this.default_m10){
						this.options.mark_ma.ma_10_data.innerText = "MA10: " + this.default_m10.value;
		        	}else{
		        		this.options.mark_ma.ma_10_data.innerText = "MA10: -";
		        	}
		        }
	
		        if(obj_20){
		            this.options.mark_ma.ma_20_data.innerText = "MA20: " + obj_20.value;
		        }else{
		        	if(this.default_m20){
		        		this.options.mark_ma.ma_20_data.innerText = "MA20: " + this.default_m20.value;
		        	}else{
		        		this.options.mark_ma.ma_20_data.innerText = "MA20: -";
		        	}
		        }
		        
		    }
		    
		}
		// 缩放
		Interactive.prototype.scale = function(canvas){
			/*K线图表右下角相对于父容器的位置*/
		    var w_pos = common.canvasToWindow.apply(this,[canvas,canvas.width,this.options.c_1_height]);
			if(!this.options.scale){
				this.options.scale = {};
				/*创建外部包裹元素*/
				var scale_div = document.createElement("div"); 
				scale_div.className = "scale-div";
				scale_div.style.right = "20px";
				scale_div.style.top = w_pos.y - 40 + "px";
				this.options.scale.scale = scale_div;
	
				/*创建文档碎片*/
				var frag = document.createDocumentFragment();
	
				/*创建减号*/
				var minus_button = document.createElement('span');
				minus_button.className = "span-minus";
				this.options.scale.minus = minus_button;
	
				/*创建加号*/
				var plus_button = document.createElement('span');
				plus_button.className = "span-plus";
				this.options.scale.plus = plus_button;
	
				frag.appendChild(minus_button);
				frag.appendChild(plus_button);
				scale_div.appendChild(frag);
				document.getElementById(this.options.container).appendChild(scale_div);
			}
		}
	
		// Tip显示行情数据
		Interactive.prototype.showTip = function(canvas,x,obj){
			// var c_box = canvas.getBoundingClientRect();
		    var type = this.options.type;
		    if(!this.options.tip){
		        this.options.tip = {};
		        // 创建外部包裹元素
		        var div_tip = document.createElement("div"); 
		        div_tip.className = "show-tip";
	
		        this.options.tip.tip = div_tip;
		        
		        // 创建文档碎片
		        var frag = document.createDocumentFragment();
	
		        // 创建收盘价格
		        var close_data = document.createElement('span');
		        close_data.className = "span-price";
		        this.options.tip.close = close_data;
		       
		        // 创建百分比
		        var percent = document.createElement('span');
		        this.options.tip.percent = percent;
		        
		        // 创建股数
		        var count = document.createElement('span');
		        this.options.tip.count = count;
		        
		        // 创建时间
		        var time = document.createElement('span');
		        this.options.tip.time = time;
	
		        var tip_line_1 = document.createElement("div");
		        tip_line_1.className = "tip-line-1";
		        tip_line_1.appendChild(close_data);
		        tip_line_1.appendChild(percent);
	
		        var tip_line_2 = document.createElement("div");
		        tip_line_2.className = "tip-line-2";
		        tip_line_2.appendChild(count);
		        tip_line_2.appendChild(time);
		        
		        frag.appendChild(tip_line_1);
		        frag.appendChild(tip_line_2);
		        div_tip.appendChild(frag);
		        document.getElementById(this.options.container).appendChild(div_tip);
	
		        var volume = obj.volume;
		        if(type == "DK" || type == "WK" || type == "MK"){
		            close_data.innerText = obj.close;
		            percent.innerText = obj.percent+'%';
	            	count.innerText = common.format_unit(volume);
		            time.innerText = obj.data_time;
		            div_tip.style.top = - div_tip.clientHeight + "px";
	
		            var c1 = "span-k-c1";
		            var c2 = "span-k-c2";
		        }else if(type == "TL"){
		            close_data.innerText = obj.price;
		            percent.innerText = obj.percent+'%';
	            	count.innerText = common.format_unit(volume);
		            time.innerText = obj.time;
		            div_tip.style.top = - div_tip.clientHeight + "px";
		            div_tip.className = div_tip.className + " " + "time-tip" 
	
		            var c1 = "span-time-c1";
		            var c2 = "span-time-c2";
		        }
	
		        close_data.className = close_data.className + " " + c1;
	            percent.className = percent.className + " " + c2;
	            count.className = count.className + " " + c1;
	            time.className = time.className + " " + c2;
	
		    }else{
		        var tip_obj = this.options.tip;
		        var div_tip = this.options.tip.tip;
		        var volume = obj.volume;
		       
		        if(type == "DK" || type == "WK" || type == "MK"){
		            tip_obj.close.innerText = obj.close;
		            tip_obj.percent.innerText = obj.percent+'%';
		            tip_obj.count.innerText = common.format_unit(volume);
		            tip_obj.time.innerText = obj.data_time.replace(/-/g,"/");
		        }else if(type == "TL"){
		            tip_obj.close.innerText = obj.price;
		            tip_obj.percent.innerText = obj.percent+'%';
	
		            tip_obj.count.innerText = common.format_unit(volume);
		            tip_obj.time.innerText = obj.time;
		        }
		    }
	
		    if(obj && obj.up){
		        div_tip.style.backgroundColor = this.options.up_color;
		    }else if(obj && !obj.up){
		        div_tip.style.backgroundColor = this.options.down_color;
		    }
	
		    // if((c_box.left + div_tip.clientWidth/2) >= x){
		    if(x <= (div_tip.clientWidth/2 + this.options.padding_left/this.options.dpr)){
		        div_tip.style.left = this.options.padding_left/this.options.dpr + "px";
		    }else if(x >= (canvas.width/this.options.dpr - div_tip.clientWidth/2)){
		        div_tip.style.left = canvas.width/this.options.dpr - div_tip.clientWidth + "px";
		    }else{
		        div_tip.style.left = x - div_tip.clientWidth/2 + "px";
		    }
		}
	
		// 标记上榜日
		Interactive.prototype.markPoint = function(x,date,canvas,scale_count){
			if(scale_count >= 0){
				// K线图表右下角相对于父容器的位置
			    var c1_pos = common.canvasToWindow.apply(this,[canvas,canvas.width,this.options.c_1_height]);
			    // 上榜日标记的横坐标
			   	var p_pos = common.canvasToWindow.apply(this,[canvas,x,this.options.c_1_height]);
	
				// 创建外部包裹元素
				var markPoint = document.createElement("div"); 
	
				markPoint.className = "mark-point";
				var imgUrl = this.options.markPoint.imgUrl;
				// 上榜日标识宽度
				var imgWidth = this.options.markPoint.width == undefined ? 15 : this.options.markPoint.width + "px";
				// 上榜日标识高度
				var imgHeight = this.options.markPoint.height == undefined ? 15 : this.options.markPoint.height + "px";
				if(imgUrl){
					markPoint.style.background = "url(" + imgUrl + ") no-repeat center center/" + imgWidth + " " + imgHeight + " #cccccc";
					markPoint.style.background = "url(" + imgUrl + ") no-repeat center center/" + imgWidth + " " + imgHeight + " #cccccc";
				}
	
				if(this.options.markPoint.width && this.options.markPoint.height){
					markPoint.style.width = imgWidth;
					markPoint.style.height = imgHeight;
				}else{
					markPoint.style.width = imgWidth;
					markPoint.style.height = imgHeight;
					// markPoint.style.borderRadius = "5px";
				}
				markPoint.setAttribute("data-point",date);
				if(!this.options.pointsContainer){
					var pointsContainer = document.createElement("div");
					this.options.pointsContainer = pointsContainer;
					document.getElementById(this.options.container).appendChild(this.options.pointsContainer);
				}
				this.options.pointsContainer.appendChild(markPoint);
				// 定位上榜日标识点的位置
				markPoint.style.left = p_pos.x - markPoint.clientWidth/2 + "px";
				markPoint.style.top = c1_pos.y - 30 + "px";
	
			}
			
		}
	
		// 显示交互效果
		Interactive.prototype.show = function(){
			
			if(this.options.cross){
	            var x_line = this.options.cross.x_line;
	            if(x_line){
	            	x_line.style.display = "block";
	            }
	            var y_line = this.options.cross.y_line;
	            if(y_line){
	            	y_line.style.display = "block";
	            }
	            var point = this.options.cross.point;
	            if(point){
	            	point.style.display = "block";
	            }
	        }
	
	        if(this.options.tip){
	            var tip = this.options.tip.tip;
	            if(tip){
	            	tip.style.display = "block";
	            }
	            
	        }
	        
		}
	
		// 隐藏交互效果
		Interactive.prototype.hide = function(){
			if(this.options.cross){
	            var x_line = this.options.cross.x_line;
	            if(x_line){
	            	x_line.style.display = "none";
	            }
	            var y_line = this.options.cross.y_line;
	            if(y_line){
	            	y_line.style.display = "none";
	            }
	            var point = this.options.cross.point;
	            if(point){
	            	point.style.display = "none";
	            }
	        }
	
	        if(this.options.mark_ma){
	            var ma_5_data = this.options.mark_ma.ma_5_data;
	            if(ma_5_data){
	            	if(this.default_m5){
		        		ma_5_data.innerText = "MA5: " + this.default_m5.value;
		        	}else{
		        		ma_5_data.innerText = "MA5: -";
		        	}
	            }
	            var ma_10_data = this.options.mark_ma.ma_10_data;
	            if(ma_10_data){
	            	if(this.default_m10){
		        		ma_10_data.innerText = "MA10: " + this.default_m10.value;
		        	}else{
		        		ma_10_data.innerText = "MA10: -";
		        	}
	            }
	            var ma_20_data = this.options.mark_ma.ma_20_data;
	            if(ma_20_data){
	            	if(this.default_m20){
		        		ma_20_data.innerText = "MA20: " + this.default_m20.value;
		        	}else{
		        		ma_20_data.innerText = "MA20: -";
		        	}
	            }
	
	        }
	
	        if(this.options.tip){
	            var tip = this.options.tip.tip;
	            if(tip){
	            	tip.style.display = "none";
	            }
	            
	        }
	
		}
	
		// 显示loading效果
		Interactive.prototype.showLoading = function(){
	
			if(this.options.loading){
				this.options.loading.style.display = "block";
			}else{
				// 获取图表容器
		        var chart_container = document.getElementById(this.options.container);
		        // var chart_container_height = chart_container.offsetHeight;
		        // loading提示信息
		        var loading_notice = document.createElement("div");
		        loading_notice.className = "loading-chart";
		        loading_notice.innerText = "加载中...";
		        loading_notice.style.height = this.options.height - 100 + "px";
		        loading_notice.style.width = this.options.width + "px";
		        // loading_notice.style.paddingTop = chart_container_height / 2 + "px";
		        loading_notice.style.paddingTop = "100px";
		        // 把提示信息添加到图表容器中
		        this.options.loading = loading_notice;
		        chart_container.appendChild(loading_notice);
			}
			
		}
	
		// 隐藏loading效果
		Interactive.prototype.hideLoading = function(){
			this.options.loading.style.display = "none";
		}
	
		// 暂无数据
		Interactive.prototype.showNoData = function(){
	
			if(this.options.noData){
				this.options.noData.style.display = "block";
			}else{
				//获取图表容器
		        var noData_container = document.getElementById(this.options.container);
		        // var noData_container_height = noData_container.offsetHeight;
		        //无数据时提示信息
		        var noData_notice = document.createElement("div");
		        noData_notice.className = "loading-chart";
		        noData_notice.innerText = "暂无数据";
		        noData_notice.style.height = this.options.height - 100 + "px";
		        noData_notice.style.width = this.options.width + "px";
	
		        noData_notice.style.paddingTop = "100px";
		        //把提示信息添加到图表容器中
		        this.options.noData = noData_notice;
		        noData_container.appendChild(noData_notice);
			}
			
		}
	
	    return Interactive;
	})();
	
	module.exports = Interactive;


/***/ },
/* 17 */
/***/ function(module, exports) {

	/*加水印*/
	function addWatermark(ctx,right,top,width,height) {
	    var _this = this;
		var canvas = ctx.canvas;
		var img = new Image();
	    width = width == undefined ? 164 : width;
	    height = height == undefined ? 41 : height;
	    img.width = 0;
	    img.height = 0;
	    //img.src = require("../images/water_mark.png");
	
	    img.onload = function(){
	        //console.info(111);
	        setTimeout(function() {
	            ctx.drawImage(img, canvas.width - right, top, width, height);	
	        }, 0);
	        
	    }
	
	    img.src = 'http://g1.dfcfw.com/g1/201607/20160727150611.png'
	
	    
	
	
	    //ctx.drawImage(img, canvas.width - right, top, 164, 41);	
	}
	
	module.exports = addWatermark;

/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制手机K线图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	 
	// 绘制坐标轴
	var DrawXY = __webpack_require__(5);
	// 主题
	var theme = __webpack_require__(7);
	// 获取K线图数据
	var GetDataDay = __webpack_require__(19); 
	var GetDataWeek = __webpack_require__(22); 
	var GetDataMonth = __webpack_require__(23); 
	// 绘制K线图
	var DrawK = __webpack_require__(24); 
	// 绘制均线图
	var DrawMA = __webpack_require__(25); 
	// 绘制成交量图
	var DrawV = __webpack_require__(15); 
	// 工具
	var common = __webpack_require__(8); 
	// 交互效果
	var Interactive = __webpack_require__(16); 
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 水印
	var watermark = __webpack_require__(17);
	
	var ChartK = (function() {
	
	    function ChartK(options) {
	        this.defaultoptions = theme.chartK;
	        this.options = {};
	        extend(true, this.options, theme.defaulttheme, this.defaultoptions, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.options.onChartLoaded = options.onChartLoaded == undefined ? function(op){
	
	        }:options.onChartLoaded;
	    }
	
	    /*初始化*/
	    ChartK.prototype.init = function() {
	        this.options.type = this.options.type == undefined ? "DK" : this.options.type;
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        // this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable","on");
	        this.container.style.position = "relative";
	        //画布
	        var ctx = canvas.getContext('2d');
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr;
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / 8;
	        // 画布内容向坐偏移的距离
	        this.options.padding_left = theme.defaulttheme.padding_left * dpr;
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / 8;
	        // 缩放默认值
	        this.options.scale_count = this.options.scale_count == undefined ? 0 : this.options.scale_count;
	        // 画布上第一个图表的高度
	        this.options.c_1_height = canvas.height * 0.5;
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0",this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr + 0.5;
	       
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	       
	    };
	
	    // 绘图
	    ChartK.prototype.draw = function(callback) {
	        var _this = this;
	        // 删除canvas画布
	        _this.clear();
	        // 初始化
	        _this.init();
	
	        // 初始化交互
	        var inter = _this.options.interactive = new Interactive(_this.options);
	        // 显示loading效果
	        inter.showLoading();
	
	        var type = _this.options.type;
	        try{
	            if(type == "DK"){
	                GetDataDay(getParamsObj.call(_this),function(data){
	                    var flag = dataCallback.apply(_this,[data]);
	                    // 均线数据标识
	                    inter.markMA(_this.options.canvas);
	                    // 缩放
	                    inter.scale(_this.options.canvas);
	                    if(flag){
	                        // 绑定事件
	                        bindEvent.call(_this,_this.options.context);
	                    }
	                    // 传入的回调函数
	                    if(callback){
	                        callback(_this.options);
	                    }
	
	                    
	                },inter);
	            }else if(type == "WK"){
	                GetDataWeek(getParamsObj.call(_this),function(data){
	                    var flag = dataCallback.apply(_this,[data]);
	                    // 均线数据标识
	                    inter.markMA(_this.options.canvas);
	                    // 缩放
	                    inter.scale(_this.options.canvas);
	                    if(flag){
	                        // 绑定事件
	                        bindEvent.call(_this,_this.options.context);
	                    }
	                    // 传入的回调函数
	                    if(callback){
	                        callback(_this.options);
	                    }
	
	                },inter);
	            }else if(type == "MK"){
	                GetDataMonth(getParamsObj.call(_this),function(data){
	                    var flag = dataCallback.apply(_this,[data]);
	                    // 均线数据标识
	                    inter.markMA(_this.options.canvas);
	                    // 缩放
	                    inter.scale(_this.options.canvas);
	                    if(flag){
	                        // 绑定事件
	                        bindEvent.call(_this,_this.options.context);
	                    }
	                    // 传入的回调函数
	                    if(callback){
	                        callback(_this.options);
	                    }
	
	                },inter);
	            }
	
	        }catch(e){
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	
	    };
	    // 重绘
	    ChartK.prototype.reDraw = function() {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        dataCallback.call(this);
	    }
	    // 删除canvas画布
	    ChartK.prototype.clear = function(cb) {
	        if(this.container){
	            this.container.innerHTML = "";
	        }else{
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	
	    // 获取上榜日标识dom
	    ChartK.prototype.getMarkPointsDom = function(cb) {
	        var points =  this.options.interactive.options.pointsContainer.children;
	        return points;
	    }
	
	    // 缩放图表
	    function scaleClick() {
	      
	        var _this = this;
	        var type = _this.options.type;
	        // 初始化交互
	        var inter = _this.options.interactive
	        // 显示loading效果
	        this.options.interactive.showLoading();
	
	        try{
	            if(type == "DK"){
	                GetDataDay(getParamsObj.call(_this),function(data){
	                    if(data){
	                        dataCallback.apply(_this,[data]);
	                        // 缩放按钮点击有效
	                        _this.options.clickable = true;
	                    }
	
	                },inter);
	            }else if(type == "WK"){
	                GetDataWeek(getParamsObj.call(_this),function(data){
	                    if(data){
	                        dataCallback.apply(_this,[data]);
	                        // 缩放按钮点击有效
	                        _this.options.clickable = true;
	                    }
	
	                },inter);
	            }else if(type == "MK"){
	                GetDataMonth(getParamsObj.call(_this),function(data){
	                    if(data){
	                        dataCallback.apply(_this,[data]);
	                        // 缩放按钮点击有效
	                        _this.options.clickable = true;
	                    }
	
	                },inter);
	            }
	
	        }catch(e){
	            // 缩放按钮点击有效
	            _this.options.clickable = true;
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	        
	    };
	
	    // 获取参数对象
	    function getParamsObj(){
	        var obj = {};
	        obj.code = this.options.code;
	        obj.count = this.options.scale_count;
	        return obj;
	    }
	    // 回调函数
	    function dataCallback(data){
	        var ctx = this.options.context;
	        var canvas = ctx.canvas;
	        this.options.data = data == null ? this.options.data : data;
	        data = this.options.data;
	
	        // 图表交互
	        var inter = this.options.interactive;
	
	        try{
	            if(!data || !data.data || data.data.length == 0){
	                this.options.data = {};
	                // 绘制坐标轴
	                new DrawXY(this.options);
	                // 绘制成交量图
	                new DrawV(this.options);
	                inter.hideLoading();
	                return;
	            }
	
	            // 保留的小数位
	            this.options.pricedigit = data.pricedigit || 2;
	
	            // 默认显示均线数据
	            var five_average = data.five_average;
	            var ten_average = data.ten_average;
	            var twenty_average = data.twenty_average;
	            inter.default_m5 = five_average[five_average.length - 1];
	            inter.default_m10 = ten_average[ten_average.length - 1];
	            inter.default_m20 = twenty_average[twenty_average.length - 1];
	
	            // 获取单位绘制区域
	            var rect_unit = common.get_rect.apply(this,[canvas,data.data.length]);
	            this.options.rect_unit = rect_unit;
	
	            // 绘制坐标轴
	            new DrawXY(this.options);
	
	            if(data && data.data && data.data.length > 0){
	                // 绘制K线图
	                new DrawK(this.options);
	                // 绘制均线图
	                new DrawMA(this.options);
	            }
	            // 绘制成交量图
	            new DrawV(this.options);
	
	            // 上榜日标识点
	            if(this.options.interactive.options.pointsContainer){
	                var points =  this.options.interactive.options.pointsContainer.children;
	                this.markPointsDom = points;
	            }
	
	            // 隐藏loading效果
	            inter.hideLoading();
	            
	            // 图表加载完成时间
	            this.options.onChartLoaded(this);
	
	        }catch(e){
	            // 缩放按钮点击有效
	            _this.options.clickable = true;
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	       // 加水印
	       watermark.apply(this,[this.options.context,170,20]);
	
	       return true;
	    }
	    // 绑定事件
	    function bindEvent(ctx){
	        var _this = this;
	        var timer_s,timer_m,timer_e;
	        var canvas = ctx.canvas;
	        var inter = _this.options.interactive;
	        //缩放按钮是否可点击
	        this.options.clickable = true;
	
	        var delayed = false;
	        var delaytouch = this.options.delaytouch = true;
	
	        // if(delaytouch){
	        //     var chart_container = document.getElementById(_this.options.container);
	        //     var delay = document.createElement("div");
	        //     delay.className = "delay-div";
	        //     delay.style.height = _this.options.height + "px";
	        //     delay.style.width = _this.options.width + "px";
	        //     delay.style.display = "none";
	        //     chart_container.appendChild(delay);
	
	        // }
	
	        // 触摸事件
	        canvas.addEventListener("touchstart",function(event){
	            // 显示交互效果
	            if(delaytouch){
	                delayed = false;
	                timer_s = setTimeout(function(){
	                    delayed = true;
	                    inter.show();
	                    dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	                    event.preventDefault();
	                },200);
	            }else{
	                inter.show();
	                dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	            }
	            
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	        });
	        
	        // 手指滑动事件
	        canvas.addEventListener("touchmove",function(event){
	            // dealEvent.apply(_this,[inter,event]);
	            if(delaytouch){
	                clearTimeout(timer_s);
	                if(delayed){
	                    dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	                    event.preventDefault();
	                }
	            }else{
	                dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	            }
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	           
	        });
	
	        // 手指离开事件
	        canvas.addEventListener("touchend",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	            }
	            // 隐藏交互效果
	            inter.hide();
	            //event.preventDefault();
	        });
	
	        canvas.addEventListener("touchcancel",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	            }
	            // 隐藏交互效果
	            inter.hide();
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	        });
	        
	
	        // if(!delaytouch){
	            canvas.addEventListener("mousemove",function(event){
	                //console.info(event);
	                dealEvent.apply(_this,[inter,event]);
	                event.preventDefault();
	            });
	
	            canvas.addEventListener("mouseleave",function(event){
	                //console.info(event);
	                inter.hide();
	                event.preventDefault();
	            });
	
	            canvas.addEventListener("mouseenter",function(event){
	                //console.info(event);
	                inter.show();
	                event.preventDefault();
	            });
	        // }
	        
	        // 放大按钮
	        var scale_plus = inter.options.scale.plus;
	        // 缩小按钮
	        var scale_minus = inter.options.scale.minus;
	
	        // 点击放大
	        scale_plus.addEventListener("click",function(event){
	            var scale_count = _this.options.scale_count;
	            if(scale_count < 2 && _this.options.clickable){
	                // 缩放按钮点击无效
	                _this.options.clickable = false;
	                scale_minus.style.opacity = "1";
	                _this.options.scale_count = scale_count + 1;
	
	                // 清除上榜日标识
	                if(_this.options.interactive.options.pointsContainer){
	                    _this.options.interactive.options.pointsContainer.innerHTML = "";
	                }
	                // 清空画布
	                ctx.clearRect(0,-_this.options.canvas_offset_top,canvas.width,canvas.height);
	                scaleClick.apply(_this);
	            }
	
	            if(_this.options.scale_count >= 2){
	                scale_plus.style.opacity = "0.5";
	            }
	            
	        });
	
	        // 点击缩小
	        scale_minus.addEventListener("click",function(event){
	            var scale_count = _this.options.scale_count;
	            if(scale_count > -2 && _this.options.clickable){
	                // 缩放按钮点击无效
	                _this.options.clickable = false;
	                scale_plus.style.opacity = "1";
	                _this.options.scale_count = scale_count - 1;
	
	                // 清除上榜日标识
	                if(_this.options.interactive.options.pointsContainer){
	                    _this.options.interactive.options.pointsContainer.innerHTML = "";
	                }
	                // 清空画布
	                ctx.clearRect(0,-_this.options.canvas_offset_top,canvas.width,canvas.height);
	                scaleClick.apply(_this);
	            }
	
	            if(_this.options.scale_count <= -2){
	                scale_minus.style.opacity = "0.5";
	            }
	            
	        });
	
	    }
	    // 图表交互
	    function dealEvent(inter,eventposition){
	
	        var canvas = this.options.canvas;
	
	        var k_data = this.options.data.data;
	        var ma_5_data = this.options.data.five_average;
	        var ma_10_data = this.options.data.ten_average;
	        var ma_20_data = this.options.data.twenty_average;
	
	        // 单位绘制区域
	        var rect_unit = this.options.rect_unit;
	        // 单位绘制区域的宽度
	        var rect_w = rect_unit.rect_w;
	        // K线柱体的宽度
	        // var bar_w = rect_unit.bar_w;
	
	        // 鼠标事件位置
	        // var w_x = eventposition.clientX;
	        // var w_y = eventposition.clientY;
	
	        var w_x = eventposition.offsetX || (eventposition.clientX - this.container.getBoundingClientRect().left);
	        var w_y = eventposition.offsetY || (eventposition.clientY - this.container.getBoundingClientRect().top);
	
	        // 鼠标在画布中的坐标
	        var c_pos = common.windowToCanvas.apply(this,[canvas,w_x,w_y]);
	        var c_x = (c_pos.x).toFixed(0);
	        // var c_y = (c_pos.y).toFixed(0);
	
	        // 当前K线在数组中的下标
	        var index = Math.floor((c_x - this.options.padding_left)/rect_w);
	
	        if(k_data[index]){
	            // 显示行情数据
	            inter.showTip(canvas,w_x,k_data[index]);
	            
	            // 显示十字指示线的
	            var cross = common.canvasToWindow.apply(this,[canvas,k_data[index].cross_x,k_data[index].cross_y]);
	            var cross_w_x = cross.x;
	            var cross_w_y = cross.y;
	            inter.cross(canvas,cross_w_x,cross_w_y);
	        }
	
	        if(ma_5_data[index]){
	             // 标识均线数据
	             inter.markMA(canvas,ma_5_data[index],ma_10_data[index],ma_20_data[index]);
	        }
	
	    }
	
	    return ChartK;
	})();
	
	module.exports = ChartK;


/***/ },
/* 19 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获取手机分日K数据
	 * 传入option:{code:股票代码, count: 点击加减按钮的参数}
	 *     option.count取值对应的情况
	 *     0 ： 默认60根
	 *     1 ： 点击了一次放大， 显示45根
	 *     2 ： 点击了两次放大，显示36根
	 *     -1 ： 点击了一次缩小， 显示105根
	 *     -2 ： 点击了两次缩小，显示205根
	 *
	 * 返回result{
	 *     max: 坐标最大值
	 *     min: 坐标最小值
	 *     v_max:最大成交量
	 *     rect:[//每天天的情况
	 *         {
	 *              date_time：2015-11-12//日期
	 *              open : 64.50//开盘价 
	 *              close:  64.10 //收市价格
	 *              percent: 百分比 -8.1
	 *              height : 最高 65.4
	 *              low : 最低 63.10
	 *              volume: 换手数 10200
	 *              up: 涨跌标志 true(涨)
	 *         }，.....
	 *     ]
	 *     five_average:[{data:2016-02-11, value:63.41}] //五日均线
	 *     ten_average:[{data:2016-02-11, value:63.41}] //十日均线
	 *     twenty_average:[{data:2016-02-11, value:63.41}] //二十日均线
	 *     
	 * }
	 */
	
	// var transform = require('common').transform;
	var jsonp = __webpack_require__(12);
	var dealData = __webpack_require__(20);
	var fixed = __webpack_require__(8).fixed;
	
	
	//传入参数取数据
	function getdata(option, callback, interactive) {
	
	    var url = 'http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js';
	    var callbackstring = 'fsdata' + (new Date()).getTime().toString().substring(0, 10);
	    var id = option.code || option; //如果只传入了一个参数，就把那个参数当股票代码；如果传入两个，则id代表股票代码
	    var count = 0 | option.count;
	    var num = 60;
	    //判断count进行相应的根数变化
	    switch(count){
	        case 0: num = 60; break;
	        case 1: num = 45; break;
	        case 2: num = 36; break;
	        case -1: num = 105; break;
	        case -2: num = 205; break;
	    }
	    var today = new Date();
	    //获取当天的时间，成为 20160426 格式,查询从当天开始，往前的80天的数据
	    var today_number_str = today.getFullYear().toString() + fixed((today.getMonth() + 1).toString(), 2) + fixed(today.getDate(), 2);
	    var QuerySpan = today_number_str + ','+(num+20);
	    var urldata = {
	        id: id,
	        TYPE: 'K',
	        js: callbackstring + '((x))',
	        'rtntype': 5,
	        "QueryStyle": "2.2",
	        'QuerySpan': QuerySpan,
	        'extend':"ma",
	        isCR :false
	    };
	
	    jsonp(url, urldata, callbackstring, function(json) {
	        try{    
	            if (!json) {
	                callback(null);
	            } else {
	                var info = json.info;
	                // var data = json.data;
	
	                // 保留小数位
	                if(info.pricedigit.split(".").length > 1){
	                    window.pricedigit = info.pricedigit.split(".")[1].length == 0 ? 2 : info.pricedigit.split(".")[1].length;
	                }else{
	                    window.pricedigit = 0;
	                }
	
	                //获取数据处理后的结果
	                if(info.total < num){
	                    var result = dealData(json,info.total);
	                }else{
	                    var result = dealData(json,num);
	                }
	                
	                result.name = json.name;
	                result.total = info.total;
	                result.count = num-20;
	
	                // 保留小数位
	                result.pricedigit = window.pricedigit;
	
	                callback(result);
	            }
	
	        }catch(e){
	            // 暂无数据
	            interactive.showNoData();
	            // 隐藏loading效果
	            interactive.hideLoading();
	        }
	    });
	}
	
	module.exports = getdata;


/***/ },
/* 20 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 进行日K各个柱体的计算
	 *
	 * return {
	 *     max,//所有柱体中的最大值
	 *     min,//所有柱体中的最小值
	 *     fiv_average //五日均线
	 *     ten_average //十日均线
	 *     twenty_average //二十日均线
	 *     timeStrs //三个时间点日期字符串
	 *     data[ //所有的柱体
	 *          date_time： 日期
	 *          open : 开盘价
	 *          close: 收市价格
	 *          percent: 百分比
	 *          highest : 最高
	 *          lowest : 最低
	 *          volume: 换手数
	 *          up:涨跌标志
	 *     ]
	 * }
	 *     
	 */
	
	//转换日期（20121112 -> 2012-11-12）
	var transform = __webpack_require__(8).transform;
	var coordinate = __webpack_require__(21);
	// var fixed = require('common').fixed;
	function dealData(json, num) {
	    // var info = json.info;
	    var arr = json.data;
	    var result = {};
	    var max = 0;
	    var min = 100000;
	    var maxVolume = 0;
	    var i = 0;
	    result.data = [];
	    //昨日收盘价
	    var yes_clo_price = 0;
	    var len = arr.length;
	    var start = (len - num) > 0 ? (len - num) : 0;
	    for (i = start; i < len; i++) {
	        try {
	            var item = arr[i].split(/\[|\]/);
	            var itemBase = arr[i].split(/\[|\]/)[0].split(",");
	        } catch (e) {
	
	        }
	
	        var rect = {};
	
	        //进行各个柱体的计算
	        rect.data_time = itemBase[0];
	        rect.open = itemBase[1];
	        rect.close = itemBase[2];
	        rect.highest = itemBase[3];
	        rect.lowest = itemBase[4];
	
	        if (i > 0) {
	            rect.percent = (Math.abs(rect.close * 1.0 - rect.open * 1.0) / rect.open * 1.0).toFixed(2);
	        } else {
	            rect.percent = 0;
	            max = min = rect.open;
	        }
	        rect.volume = itemBase[5];
	
	        yes_clo_price = close;
	        rect.up = (rect.close * 1.0 - rect.open * 1.0) > 0 ? true : false;
	
	        var mas = item[1].split(",");
	        intoArr.call(result, "five_average", mas[0], rect.data_time);
	        intoArr.call(result, "ten_average", mas[1], rect.data_time);
	        intoArr.call(result, "twenty_average", mas[2], rect.data_time);
	        intoArr.call(result, "thirty_average", mas[3], rect.data_time);
	
	        //进行最大最小值计算
	        // max = getMax([max, rect.lowest, rect.highest*1.0]);
	        // min = getMin([min, rect.lowest, rect.highest*1.0]);
	        max = Math.max(max,rect.highest);
	        min = Math.min(min,rect.lowest);
	        maxVolume = maxVolume > rect.volume*1.0 ? maxVolume : rect.volume*1.0;
	
	        result.data.push(rect);
	
	    }
	
	
	    //日期字符串
	    result.timeStrs = [];
	
	    result.timeStrs[0] = transform(arr[start].split(',')[0]);
	    result.timeStrs[1] = transform(arr[Math.floor((len + start) / 2)].split(',')[0]);
	    result.timeStrs[2] = transform(arr[len - 1].split(',')[0]);
	
	    //坐标最大价格
	    result.max = parseFloat(coordinate(max, min).max);
	
	    //坐标最小价格
	    result.min = parseFloat(coordinate(max, min).min);
	
	    //最大成交量
	    result.v_max = Number((maxVolume).toFixed(2));
	
	    return result;
	}
	
	//创建一个数组，并且push值
	function intoArr(name, value, date) {
	    
	    if (this[name] === undefined) {
	        this[name] = [{ value: value, date: date }];
	    } else {
	        this[name].push({ value: value, date: date });
	    }
	}
	
	//数组冒泡得到最大值
	function getMax(arr) {
	    var max = 0;
	    for (var i = 0; i < arr.length; i++) {
	        max = max > arr[i] * 1.0 ? max : arr[i] * 1.0;
	    }
	    return max;
	}
	//数组冒泡得到最小值
	function getMin(arr) {
	    var min = 100000;
	    for (var i = 0; i < arr.length; i++) {
	        min = min < arr[i] * 1.0 ? min : arr[i] * 1.0;
	    }
	    return min;
	}
	
	
	module.exports = dealData;


/***/ },
/* 21 */
/***/ function(module, exports) {

	/**
	 * 分时图坐标上下限算法
	 */
	
	/*
	1.遍历出当前价的最高(high),最低点(low)
	2.取最高和最低的平均值
	3.(最高-平均)/2*1.05 得到偏移
	4.最高+偏移得最高， 最低加偏移得最低
	 */
	
	/**
	 * 分时图坐标上下限
	 * @param  {[type]} high 最高
	 * @param  {[type]} low 最低
	 */
	function coordinate(high, low) {
		var top = 0;
		// var fall = 0;
		var offset = (high-low)/2*0.05;
	
		top = high+offset;
		low = low-offset;
	
		return { max: top, min: low };
	}
	
	module.exports = coordinate;

/***/ },
/* 22 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获取手机分日K数据
	 * 传入option:{code:股票代码, count: 点击加减按钮的参数}
	 *     option.count取值对应的情况
	 *     0 ： 默认60根
	 *     1 ： 点击了一次放大， 显示45根
	 *     2 ： 点击了两次放大，显示36根
	 *     -1 ： 点击了一次缩小， 显示105根
	 *     -2 ： 点击了两次缩小，显示205根
	 *
	 * 返回result{
	 *     max: 坐标最大值
	 *     min: 坐标最小值
	 *     v_max:最大成交量
	 *     rect:[//每天天的情况
	 *         {
	 *              date_time：2015-11-12//日期
	 *              open : 64.50//开盘价 
	 *              close:  64.10 //收市价格
	 *              percent: 百分比 -8.1
	 *              height : 最高 65.4
	 *              low : 最低 63.10
	 *              volume: 换手数 10200
	 *              up: 涨跌标志 true(涨)
	 *         }，.....
	 *     ]
	 *     five_average:[{data:2016-02-11, value:63.41}] //五日均线
	 *     ten_average:[{data:2016-02-11, value:63.41}] //十日均线
	 *     twenty_average:[{data:2016-02-11, value:63.41}] //二十日均线
	 *     
	 * }
	 */
	
	// var transform = require('common').transform;
	var jsonp = __webpack_require__(12);
	var dealData = __webpack_require__(20);
	var fixed = __webpack_require__(8).fixed;
	
	
	//传入参数取数据
	function getdata(option, callback, interactive) {
	
	    var url = 'http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js';
	    var callbackstring = 'fsdata' + (new Date()).getTime().toString().substring(0, 10);
	    var id = option.code || option; //如果只传入了一个参数，就把那个参数当股票代码；如果传入两个，则id代表股票代码
	    var count = 0 | option.count;
	    var num = 60;
	    //判断count进行相应的根数变化
	    switch(count){
	        case 0: num = 60; break;
	        case 1: num = 45; break;
	        case 2: num = 36; break;
	        case -1: num = 105; break;
	        case -2: num = 205; break;
	    }
	    var today = new Date();
	    //获取当天的时间，成为 20160426 格式,查询从当天开始，往前的80天的数据
	    var today_number_str = today.getFullYear().toString() + fixed((today.getMonth() + 1).toString(), 2) + fixed(today.getDate(), 2);
	    var QuerySpan = today_number_str + ','+(num+20);
	    var urldata = {
	        id: id,
	        TYPE: 'WK',
	        js: callbackstring + '((x))',
	        'rtntype': 5,
	        "QueryStyle": "2.2",
	        'QuerySpan': QuerySpan,
	        'extend':"ma",
	        isCR :false
	    };
	
	    jsonp(url, urldata, callbackstring, function(json) {
	        try{
	            if (!json) {
	                callback(null);
	            } else {
	                var info = json.info;
	                // var data = json.data;
	
	                // 保留小数位
	                if(info.pricedigit.split(".").length > 1){
	                    window.pricedigit = info.pricedigit.split(".")[1].length == 0 ? 2 : info.pricedigit.split(".")[1].length;
	                }else{
	                    window.pricedigit = 0;
	                }
	                //获取数据处理后的结果
	                if(info.total < num){
	                    var result = dealData(json,info.total);
	                }else{
	                    var result = dealData(json,num);
	                }
	                result.name = json.name;
	                result.count = num-20;
	                // 保留小数位
	                result.pricedigit = window.pricedigit;
	
	                callback(result);
	            }
	
	        }catch(e){
	            // 暂无数据
	            interactive.showNoData();
	            // 隐藏loading效果
	            interactive.hideLoading();
	        }
	        
	    });
	}
	
	module.exports = getdata;


/***/ },
/* 23 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获取手机分日K数据
	 * 传入option:{code:股票代码, count: 点击加减按钮的参数}
	 *     option.count取值对应的情况
	 *     0 ： 默认60根
	 *     1 ： 点击了一次放大， 显示45根
	 *     2 ： 点击了两次放大，显示36根
	 *     -1 ： 点击了一次缩小， 显示105根
	 *     -2 ： 点击了两次缩小，显示205根
	 *
	 * 返回result{
	 *     max: 坐标最大值
	 *     min: 坐标最小值
	 *     v_max:最大成交量
	 *     rect:[//每天天的情况
	 *         {
	 *              date_time：2015-11-12//日期
	 *              open : 64.50//开盘价 
	 *              close:  64.10 //收市价格
	 *              percent: 百分比 -8.1
	 *              height : 最高 65.4
	 *              low : 最低 63.10
	 *              volume: 换手数 10200
	 *              up: 涨跌标志 true(涨)
	 *         }，.....
	 *     ]
	 *     five_average:[{data:2016-02-11, value:63.41}] //五日均线
	 *     ten_average:[{data:2016-02-11, value:63.41}] //十日均线
	 *     twenty_average:[{data:2016-02-11, value:63.41}] //二十日均线
	 *     
	 * }
	 */
	
	// var transform = require('common').transform;
	var jsonp = __webpack_require__(12);
	var dealData = __webpack_require__(20);
	var fixed = __webpack_require__(8).fixed;
	
	
	//传入参数取数据
	function getdata(option, callback, interactive) {
	
	    var url = 'http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js';
	    var callbackstring = 'fsdata' + (new Date()).getTime().toString().substring(0, 10);
	    var id = option.code || option; //如果只传入了一个参数，就把那个参数当股票代码；如果传入两个，则id代表股票代码
	    var count = 0 | option.count;
	    var num = 60;
	    //判断count进行相应的根数变化
	    switch(count){
	        case 0: num = 60; break;
	        case 1: num = 45; break;
	        case 2: num = 36; break;
	        case -1: num = 105; break;
	        case -2: num = 205; break;
	    }
	    var today = new Date();
	    //获取当天的时间，成为 20160426 格式,查询从当天开始，往前的80天的数据
	    var today_number_str = today.getFullYear().toString() + fixed((today.getMonth() + 1).toString(), 2) + fixed(today.getDate(), 2);
	    var QuerySpan = today_number_str + ','+(num+20);
	    var urldata = {
	        id: id,
	        TYPE: 'MK',
	        js: callbackstring + '((x))',
	        'rtntype': 5,
	        "QueryStyle": "2.2",
	        'QuerySpan': QuerySpan,
	        'extend':"ma",
	        isCR :false
	    };
	
	    jsonp(url, urldata, callbackstring, function(json) {
	
	        try{
	            if (!json) {
	                callback(null);
	            } else {
	                var info = json.info;
	                // var data = json.data;
	
	                // 保留小数位
	                if(info.pricedigit.split(".").length > 1){
	                    window.pricedigit = info.pricedigit.split(".")[1].length == 0 ? 2 : info.pricedigit.split(".")[1].length;
	                }else{
	                    window.pricedigit = 0;
	                }
	                //获取数据处理后的结果
	                if(info.total < num){
	                    var result = dealData(json,info.total);
	                }else{
	                    var result = dealData(json,num);
	                }
	                result.name = json.name;
	                result.count = num-20;
	
	                // 保留小数位
	                result.pricedigit = window.pricedigit;
	
	                callback(result);
	            }
	
	        }catch(e){
	            // 暂无数据
	            interactive.showNoData();
	            // 隐藏loading效果
	            interactive.hideLoading();
	        }
	        
	    });
	}
	
	module.exports = getdata;


/***/ },
/* 24 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制K线
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 工具
	var common = __webpack_require__(8);
	// 主题
	var theme = __webpack_require__(7);
	var DrawK = (function(){
		function DrawK(options){
			// 设置默认参数
	        this.defaultoptions = theme.draw_k;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        // 绘图
	        this.draw();
		};
	
		// 绘图
		DrawK.prototype.draw = function(){
			var ctx = this.options.context;
			var data = this.options.data;
			var data_arr = data.data;
	
			// 绘制K线图
			this.drawK(ctx,data_arr);
		};
		
		// 绘制K线图
		DrawK.prototype.drawK = function(ctx,data_arr){
			
			// 获取单位绘制区域
			var rect_unit = this.options.rect_unit;
			// 单位绘制区域的宽度
			// var rect_w = rect_unit.rect_w;
			// K线柱体的宽度
			var bar_w = rect_unit.bar_w;
			// K线柱体的颜色
			var up_color = this.options.up_color;
			var down_color =this.options.down_color
			// 图表交互
	        var inter = this.options.interactive;
	        // 上榜日数组
	        var pointObj = {};
	        if(this.options.markPoint && this.options.markPoint.show){
	        	var array = this.options.markPoint.dateList;
	        	for(var index in array){
	        		pointObj[array[index]] = array[index];
	        	}
	        }
	
			for(var i = 0,item; item = data_arr[i]; i++){
				// 是否上涨
				var is_up = item.up;
	
				ctx.beginPath();
				ctx.lineWidth = 1;
	
				if(is_up){
				 	ctx.fillStyle = up_color;
	                ctx.strokeStyle = up_color
				}else{
					ctx.fillStyle = down_color
	                ctx.strokeStyle = down_color
				}
	
				var x = common.get_x.call(this,i + 1);
			 	var y_open = common.get_y.call(this,item.open);
			 	var y_close = common.get_y.call(this,item.close);
			 	var y_highest = common.get_y.call(this,item.highest);
			 	var y_lowest = common.get_y.call(this,item.lowest);
			 	item.cross_x = x;
			 	item.cross_y = y_close;
			 	// console.log(x.toFixed(2).toString());
	
			 	//标识上榜日
			 	if(pointObj[item.data_time]){
			 		inter.markPoint(x,item.data_time,this.options.context.canvas,this.options.scale_count);
			 	}
	
			 	ctx.moveTo(x,y_lowest);
			 	ctx.lineTo(x,y_highest);
			 	ctx.stroke();
	
			 	ctx.beginPath();
	
				// ctx.lineWidth = w * (1 - this.options.spacing);
			 	// ctx.moveTo(x,y_open);
			 	// ctx.lineTo(x,y_close);
			 	
			 	if(y_close >= y_open){
			 		ctx.rect(x - bar_w/2,y_open,bar_w,y_close - y_open);
			 	}else{
			 		ctx.rect(x - bar_w/2,y_close,bar_w,y_open - y_close);
			 	}
	
			 	ctx.stroke();
			 	ctx.fill();
			}
		};
	
		return DrawK;
	})();
	
	module.exports = DrawK;

/***/ },
/* 25 */
/***/ function(module, exports, __webpack_require__) {

	/*继承*/
	var extend = __webpack_require__(6);
	/*工具*/
	var common = __webpack_require__(8);
	/*主题*/
	var theme = __webpack_require__(7);
	var DrawMA = (function(){
		function DrawMA(options){
			/*设置默认参数*/
	        this.defaultoptions = theme.drawMA;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
		};
		
		/*绘图*/
		DrawMA.prototype.draw = function(){
			var ctx = this.options.context;
			var data = this.options.data;
			/*5日均线数据*/
			var five_average = data.five_average;
			/*10日均线数据*/
			var ten_average = data.ten_average;
			/*20日均线数据*/
			var twenty_average = data.twenty_average;
	
			this.options.ma_5_data = drawMA.apply(this,[ctx,five_average,"#f4cb15"]);
			this.options.ma_10_data = drawMA.apply(this,[ctx,ten_average,"#ff5b10"]);
			this.options.ma_20_data = drawMA.apply(this,[ctx,twenty_average,"#488ee6"]);
		};
		/**
	     * 绘制均线图
	     */
	    function drawMA(ctx,data_arr,color) {
	    	var ma_data = [];
	    	ctx.beginPath();
			ctx.strokeStyle = color;
			for(var i = 0;i < data_arr.length; i++){
				var item = data_arr[i];
				if(item && item.value){
					 var x = common.get_x.call(this,i + 1);
					 var y = common.get_y.call(this,item.value);
					 //横坐标和均线数据
					 ma_data.push(item);
	
					 if(i == 0 || y > (this.options.c_1_height - ctx.canvas.height/8/2)  || y < 0){
					 	ctx.moveTo(x,y);
					 }else{
					 	ctx.lineTo(x,y);
					 }
				}
				 
			}
			ctx.stroke();
			return ma_data;
	    }
	    
		return DrawMA;
	})();
	
	module.exports = DrawMA;

/***/ },
/* 26 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制手机分时图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	// 绘制坐标轴
	var DrawXY = __webpack_require__(27);
	// 主题
	var theme = __webpack_require__(7);
	// 绘制分时折线图
	var DrawLine = __webpack_require__(28); 
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 交互效果
	var Interactive = __webpack_require__(16); 
	// 水印
	var watermark = __webpack_require__(17);
	
	var ChartLine = (function() {
	
	    // 构造函数
	    function ChartLine(options) {
	        this.defaultoptions = theme.chartLine;
	        this.options = {};
	        extend(true, this.options, theme.defaulttheme, this.defaultoptions, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.onChartLoaded = options.onChartLoaded == undefined ? function(op){
	
	        }:options.onChartLoaded;
	        
	    }
	
	    // 初始化
	    ChartLine.prototype.init = function() {
	
	        this.options.type = "line";
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        // this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable","on");
	        this.container.style.position = "relative";
	        // 画布
	        var ctx = canvas.getContext('2d');
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr;
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / (9 * 2);
	        // 画布内容向坐偏移的距离
	        this.options.padding_left = canvas.width / 6;
	
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / (9 * 2);
	        // 缩放默认值
	        this.options.scale_count = 0;
	        // 画布上第一个图表的高度
	        if(this.options.showflag){
	            this.options.c_1_height = canvas.height * (5/9);
	        }else{
	            this.options.c_1_height = canvas.height * (7/9);
	        }
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0",this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr + 0.5;
	        // 加水印
	        watermark.apply(this,[ctx,190,20]);
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	    };
	
	    // 绘图
	    ChartLine.prototype.draw = function(callback) {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        // 初始化交互
	        this.options.interactive = new Interactive(this.options);
	        // 显示loading效果
	        // inter.showLoading();
	        // var _this = this;
	
	        // 折线数据
	        var series = this.options.series;
	        this.options.data = {};
	        var maxAndMin = getMaxMark(series);
	        this.options.data.max = maxAndMin.max;
	        this.options.data.min = maxAndMin.min;
	        this.options.padding_left = this.options.context.measureText("-1000万").width + 20;
	
	        // 绘制坐标轴
	        new DrawXY(this.options);
	        // 绘制分时折线图
	        new DrawLine(this.options);
	
	    };
	    // 重绘
	    ChartLine.prototype.reDraw = function() {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        this.draw();
	    }
	    // 删除canvas画布
	    ChartLine.prototype.clear = function(cb) {
	        if(this.container){
	            this.container.innerHTML = "";
	        }else{
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	
	    // 获取数组中的最大值
	    function getMaxMark(data) {
	        var max = 0, min = 0,count=[];
	        for(var i = 0;i<data.length;i++){
	            count = count.concat(data[i].data);
	        }
	        max = count[0];
	
	        for(var i =1;i<count.length;i++) {
	            max = Math.max(max,count[i]);
	            min = Math.min(min,count[i]);
	        }
	        var step = Math.ceil((max * 1.1) / 5);
	        if(step <= 10){
	            step = Math.ceil(step);
	        }else if(step > 10 && step < 100){
	            if(step % 10 > 0){
	                step = Math.ceil(step/10) * 10;
	            }
	        }
	
	        else{
	            var num = step.toString().length;
	            var base_step = Math.floor(step/Math.pow(10,(num - 1))) * Math.pow(10,(num - 1));
	            var middle_step = base_step + Math.pow(10,(num - 1))/2;
	            var next_step = base_step + Math.pow(10,(num - 1));
	
	            if(step == base_step){
	                step = base_step;
	            }else if(step > base_step && step <= middle_step){
	                step = middle_step;
	            }else if(step > middle_step && step <= next_step){
	                step = next_step;
	            }
	        }
	
	        // else{
	        //     var num = step.toString().length;
	        //     var base_step = Math.ceil(step/Math.pow(10,(num - 2))) * Math.pow(10,(num - 2));
	        //     step = base_step;
	        // }
	        max = step * 5;
	        return {
	            max:max,
	            min:min
	        };
	     }
	
	    return ChartLine;
	})();
	
	module.exports = ChartLine;


/***/ },
/* 27 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制直角坐标系
	 */
	 var extend = __webpack_require__(6);
	 /*主题*/
	 var theme = __webpack_require__(7);
	 var common = __webpack_require__(8);
	 var DrawXY = (function(){
	    //构造方法
	    function DrawXY(options){
	        /*设置默认参数*/
	        this.defaultoptions = theme.draw_xy;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
	    };
	    /*绘图*/
	    DrawXY.prototype.draw = function(){
	        // var xAxisData = this.options.xaxis;
	        // var yAxisData = this.options.series;
	        // var type = this.options.type;
	        // var dpr = this.options.dpr;
	        var ctx = this.options.context;
	
	        /*Y轴上的最大值*/
	        var y_max = this.options.data.max;
	        /*Y轴上的最小值*/
	        var y_min = this.options.data.min;
	
	        /*Y轴上分隔线数量*/
	        var sepe_num = this.options.sepenum || 6;
	        /*开盘收盘时间数组*/
	        var oc_time_arr = this.options.xaxis;
	
	        /*K线图的高度*/
	        var k_height = this.options.c_1_height;
	        /*Y轴标识线列表*/
	        var line_list_array = getLineList(y_max, y_min, sepe_num, k_height);
	
	        drawXYLine.call(this,ctx,y_max,y_min,line_list_array);
	
	        // 绘制横坐标刻度
	        drawXMark.apply(this,[ctx,k_height,oc_time_arr]);
	    };
	    // 绘制分时图坐标轴最左边刻度
	    function drawXYLine(ctx,y_max,y_min,line_list_array){
	        // var sepe_num = line_list_array.length;
	        ctx.fillStyle = '#b1b1b1';
	        ctx.strokeStyle = '#ccc';
	        ctx.textAlign = 'right';
	
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	            ctx.moveTo(this.options.padding_left, Math.round(item.y));
	            ctx.lineTo(ctx.canvas.width, Math.round(item.y));
	            // 绘制纵坐标刻度
	            ctx.fillText(common.format_unit(item.num/1,2), this.options.padding_left-20, item.y +10);
	            ctx.stroke();
	        }
	
	    }
	
	    /*绘制横坐标刻度值*/
	    function drawXMark(ctx,k_height,oc_time_arr){
	        // var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        ctx.beginPath();
	        ctx.textAlign = 'center';
	        ctx.fillStyle = '#b1b1b1';
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        // var y_date = this.options.c_1_height;
	        var tempDate;
	        // var timeSpacing = (this.options.width * dpr - padding_left) / oc_time_arr.length + padding_left;
	        var arr_length = oc_time_arr.length;
	        for(var i = 0;i<arr_length;i++) {
	            tempDate = oc_time_arr[i];
	            if(tempDate.show == undefined ? true : tempDate.show){
	                if(i < arr_length - 1){
	                    ctx.fillText(tempDate.value, i * (k_width - padding_left) / (arr_length-1) + padding_left, this.options.c_1_height+40);
	                }else
	
	                if(i * (k_width - padding_left) / (arr_length-1) + padding_left + ctx.measureText(tempDate.value).width > ctx.canvas.width){
	                    ctx.fillText(tempDate.value, ctx.canvas.width - ctx.measureText(tempDate.value).width/2, this.options.c_1_height+40);
	                }
	            }
	
	            if(tempDate.showline == undefined ? true : tempDate.showline){
	                ctx.strokeStyle = '#ccc';
	                ctx.moveTo(i * (k_width - padding_left) / (arr_length-1) + padding_left,0);
	                ctx.lineTo(i * (k_width - padding_left) / (arr_length-1) + padding_left,this.options.c_1_height);
	            }
	
	        }
	
	
	        // var x = ((ctx.canvas.width - this.options.padding_left)/(arr_length-1)) * (i) + this.options.padding_left;
	
	            // 绘制坐标刻度
	            ctx.stroke();
	
	
	        // ctx.moveTo(0,k_height + 10);
	    }
	    
	    /*Y轴标识线列表*/
	    function getLineList(y_max, y_min, sepe_num, k_height) {
	        var ratio = (y_max - y_min) / (sepe_num-1);
	        var result = [];
	        for (var i = 0; i < sepe_num; i++) {
	            result.push({
	                num:  (y_min + i * ratio),
	                x: 0,
	                y: k_height - (i / (sepe_num-1)) * k_height
	            });
	        }
	        return result;
	    }
	
	    return DrawXY;
	})();
	
	module.exports = DrawXY;

/***/ },
/* 28 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制折线图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	/*继承*/
	var extend = __webpack_require__(6);
	/*主题*/
	var theme = __webpack_require__(7);
	/*工具*/
	var common = __webpack_require__(8);
	var DrawLine = (function(){
		function DrawLine(options){
			// 设置默认参数
	        this.defaultoptions = theme.drawLine;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        // 绘图
	        this.draw();
		};
		
		// 绘图
		DrawLine.prototype.draw = function(){
	
			var ctx = this.options.context;
			ctx.lineWidth = 1 * this.options.dpr + 1;
			// 折线数据
			var series = this.options.series;
			// 横坐标数据
			// var xaxis = this.options.xaxis;
			for(var i = 0,line;line = series[i]; i++){
				// 填充颜色
				ctx.fillStyle = line.color == undefined ? "#333" : line.color;
				// 画笔颜色
		        ctx.strokeStyle = line.color == undefined ? "#333" : line.color;
	        	drawLine.apply(this,[ctx,line]);
		        			
				if(line.showpoint){
					drawPoint.apply(this,[ctx,line]);
				}
				
			}
			if(this.options.showflag){
				drawLineMark.apply(this,[ctx,series]);
			}
		};
		
		// 绘制折线
		function drawLine(ctx,line){
			// 保存画笔状态
			ctx.save();
	
			var arr = line.data;
	        var arr_length = arr.length;
	
			ctx.beginPath();
	
			for(var i = 0;i < arr_length; i++){
				var item = arr[i];
				if(item){
					 var x = ((ctx.canvas.width - this.options.padding_left)/(arr_length-1)) * (i) + this.options.padding_left;
					 var y = common.get_y.call(this,item);
					 if(i == 0){
					 	ctx.moveTo(this.options.padding_left,y);
					 }else if(i == arr_length - 1){
					 	ctx.lineTo(x,y);
					 }else{
					 	ctx.lineTo(x,y);
					 }
				}else{
					 continue;
				}
				 
			}
			
			// ctx.fill();
			ctx.stroke();
			// 恢复画笔状态
			ctx.restore();
		}
	
		// 绘制折线节点（连接点）
		function drawPoint(ctx,line){
			// 保存画笔状态
			ctx.save();
	
			var arr = line.data;
	        var arr_length = arr.length;
	
	        // 节点（折线连接点半径）
	        var pointRadius = this.options.pointRadius;
	
			for(var i = 0,item;item = arr[i]; i++){
				 ctx.beginPath();
	        	 var x = ((ctx.canvas.width - this.options.padding_left)/(arr_length-1)) * (i) + this.options.padding_left;
				 var y = common.get_y.call(this,item);
				 if(i == 0){
				 	ctx.arc(x, y, pointRadius, 0, Math.PI * 2, true); 
				 	ctx.fill();
				 }else if(i == arr_length - 1){
				 	
				 }else{
				 	ctx.arc(x, y, pointRadius, 0, Math.PI * 2, true); 
				 	ctx.fill();
				 }
			 	 
			}
			// 恢复画笔状态
			ctx.restore();
		}
	
	
	    // 绘制折线标识
	    function drawLineMark(ctx,series){
	    	// 保存画笔状态
			ctx.save();
			var dpr = this.options.dpr;
			var x_middle = ctx.canvas.width/2;
			var wh = this.options.lineMarkWidth * dpr;
			var x_start = 0;
			var y_start = ctx.canvas.height * (7/9 - 1/18);
	
			for(var i = 0,line;line = series[i]; i++){
				ctx.beginPath();
				
				// 画笔颜色
		        ctx.strokeStyle = '#cadef8';
		        var mark_offset = (Math.floor(i/2)) * (wh + 7 * dpr);
		        var text_offset = this.options.font_size * this.options.dpr + (wh-this.options.font_size * this.options.dpr)/2;
				if(i == 0){
					// 填充颜色
					ctx.fillStyle = line.color;
					ctx.rect(x_start + 20,y_start,wh,wh);
					ctx.fill();
					// 填充颜色
					ctx.fillStyle = '#333';
					ctx.fillText(line.name, x_start + wh + 80, y_start + text_offset);
				}else if((i + 1) % 2 == 0){
					// 填充颜色
					ctx.fillStyle = line.color;
			 		ctx.rect(x_middle,y_start + mark_offset,wh,wh);
			 		ctx.fill();
			 		// 填充颜色
					ctx.fillStyle = '#333';
	        		ctx.fillText(line.name, x_middle + wh + 60, y_start + mark_offset + text_offset);
		    	}else{
		    		// 填充颜色
					ctx.fillStyle = line.color;
		    		ctx.rect(x_start + 20,y_start + mark_offset,wh,wh);
		    		ctx.fill();
		    		ctx.fillStyle = '#333';
		    		ctx.fillText(line.name, x_start + wh + 80, y_start + mark_offset + text_offset);
		    	}
			}
			// 恢复画笔状态
			ctx.restore();
	    }
	
		return DrawLine;
	})();
	
	module.exports = DrawLine;

/***/ },
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */,
/* 33 */,
/* 34 */,
/* 35 */,
/* 36 */,
/* 37 */,
/* 38 */,
/* 39 */,
/* 40 */,
/* 41 */,
/* 42 */,
/* 43 */,
/* 44 */,
/* 45 */,
/* 46 */,
/* 47 */,
/* 48 */,
/* 49 */,
/* 50 */,
/* 51 */,
/* 52 */,
/* 53 */,
/* 54 */,
/* 55 */,
/* 56 */,
/* 57 */,
/* 58 */,
/* 59 */,
/* 60 */,
/* 61 */,
/* 62 */,
/* 63 */,
/* 64 */,
/* 65 */,
/* 66 */,
/* 67 */
/***/ function(module, exports, __webpack_require__) {

	// style-loader: Adds some css to the DOM by adding a <style> tag
	
	// load the styles
	var content = __webpack_require__(68);
	if(typeof content === 'string') content = [[module.id, content, '']];
	// add the styles to the DOM
	var update = __webpack_require__(73)(content, {});
	if(content.locals) module.exports = content.locals;
	// Hot Module Replacement
	if(false) {
		// When the styles change, update the <style> tags
		if(!content.locals) {
			module.hot.accept("!!./../../node_modules/css-loader/index.js!./style.css", function() {
				var newContent = require("!!./../../node_modules/css-loader/index.js!./style.css");
				if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
				update(newContent);
			});
		}
		// When the module is disposed, remove the <style> tags
		module.hot.dispose(function() { update(); });
	}

/***/ },
/* 68 */
/***/ function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(69)();
	// imports
	
	
	// module
	exports.push([module.id, "/*手机版图表样式*/\r\n.show-tip {\r\n    position: absolute;\r\n    top: 0px;\r\n    background-color: red;\r\n    z-index: 999;\r\n    border: 0;\r\n    padding: 10px;\r\n    border-radius: 7px;\r\n    background-color: #17b03e;\r\n    color: #fff;\r\n    font-size: 16px;\r\n    font-weight: lighter;\r\n    font-family: 'Microsoft Yahei';\r\n   \r\n}\r\n.show-tip .span-price{\r\n\tfont-size: 22px;\r\n}\r\n.show-tip span{\r\n\tfont-size: 14px;height:25px;line-height:25px;\r\n    white-space: nowrap;\r\n}\r\n\r\n.tip-line-1,.tip-line-2{\r\n\theight:25px;\r\n\tline-height:25px;\r\n}\r\n.time-tip{\r\n\r\n}\r\n.show-tip .span-time-c1{\r\n\ttext-align: left;\r\n\tmargin-right: 10px;\r\n}\r\n.show-tip .span-time-c2{\r\n\ttext-align: right;\r\n}\r\n\r\n.show-tip .span-k-c1{\r\n\ttext-align: left;\r\n\tmargin-right: 10px;\r\n}\r\n.show-tip .span-k-c2{\r\n\ttext-align: right;\r\n}\r\n\r\n\r\n.cross-y{\r\n\tposition:absolute;top:0px;z-index:98;border-left:1px dashed #8f8f8f;width:0px;background-color:#fff;\r\n}\r\n.cross-x{\r\n\tposition:absolute;left:0px;z-index:98;border-top:1px dashed #8f8f8f;height:0px;\r\n}\r\n.cross-p{\r\n\tposition:absolute;z-index:100;\r\n}\r\n.mark-ma{\r\n\tposition:absolute;top:0px;right:0px;z-index:97;border:0;height:30px;line-height:30px;font-family:Microsoft Yahei;font-weight:lighter;\r\n}\r\n.mark-ma span {\r\n\tdisplay:inline-block;padding-right:10px;font-size:14px;text-align:left;color:#ffba42;\r\n}\r\n\r\n.mark-ma .span-m5{\r\n\tcolor:#f4cb15;\r\n}\r\n.mark-ma .span-m10{\r\n\tcolor:#ff5b10;\r\n}\r\n.mark-ma .span-m20{\r\n\tcolor:#488ee6;\r\n}\r\n.mark-ma .span-m30{\r\n\tcolor:#fe59fe;\r\n}\r\n.scale-div{\r\n\tposition:absolute;z-index:99;border:0px;width:90px;height:45px;\r\n\topacity:0.7;\r\n}\r\n.scale-div .span-minus{\r\n\twidth: 30px;height: 30px;float: left;border-radius: 6px;\r\n\tbackground: url(" + __webpack_require__(70) + ") no-repeat center center #cccccc;\r\n}\r\n.scale-div .span-plus{\r\n\twidth: 30px;height: 30px;float: right;border-radius: 6px;\r\n\tbackground: url(" + __webpack_require__(71) + ") no-repeat center center #cccccc;\r\n}\r\n.scale-opacity{\r\n\topacity:0.3;\r\n}\r\n\r\n.header .tool-bar{\r\n    background: -webkit-linear-gradient(top, #4d74ae, #2e5186); /* Safari 5.1 - 6.0 */\r\n    background: -o-linear-gradient(bottom, #4d74ae, #2e5186); /* Opera 11.1 - 12.0 */\r\n    background: -moz-linear-gradient(bottom, #4d74ae, #2e5186); /* Firefox 3.6 - 15 */\r\n    background: linear-gradient(to bottom, #4d74ae, #2e5186); /* 标准的语法 */\r\n\tbackground:#2e5186;\r\n\theight:70px;\r\n}\r\n.header .sepe{\r\n\theight:50px;\r\n\tbackground-color: #d1e1f9;\r\n}\r\n.content{\r\n\tbackground-color: #f2f2f2;\r\n}\r\n\r\n.content .emchart{\r\n\tbackground-color: #fff;\r\n\tpadding:0px 10px;\r\n}\r\n\r\n.tabs{\r\n\tbackground-color: #fff;\r\n\theight:50px;\r\n\tfont-size: 18px;\r\n\tcolor:#000;\r\n\tborder-bottom: 1px solid #ccc;\r\n\tmargin-bottom: 15px;\r\n}\r\n.tabs .tab{\r\n\tfloat:left;\r\n\twidth: 25%;\r\n\theight: 47px;\r\n\tline-height: 47px;\r\n\ttext-align: center;\r\n}\r\n.tabs .tab.current{\r\n\tcolor: #2f5895;\r\n\tborder-bottom: 3px solid #2f5895;\r\n}\r\n\r\n.loading-chart {\r\n\tposition: absolute;\r\n\tleft:0;\r\n\ttop:0;\r\n\tz-index: 100;\r\n\twidth: 100%;\r\n\theight: 100%;\r\n\tbackground-color: #fff;\r\n\ttext-align: center;\r\n\r\n    opacity: 0.7;\r\n    font-size: 20px;\r\n}\r\n\r\n.delay-div{\r\n\tposition: absolute;\r\n\tleft:0;\r\n\ttop:0;\r\n\tz-index: 10000;\r\n\twidth: 100%;\r\n\theight: 100%;\r\n\tbackground-color: #fff;\r\n    opacity: 0;\r\n}\r\n\r\n.mark-point{\r\n\tposition: absolute;\r\n\tz-index: 97;\r\n\tmin-width: 15px;\r\n\tmin-height: 15px;\r\n\tborder-radius: 10px;\r\n\tbackground: url(" + __webpack_require__(72) + ") no-repeat center center/15px 15px #fff;\r\n\topacity: 1;\r\n}\r\n\r\n\r\n/*web港股的样式*/\r\n.web-tips{\r\n\tdisplay: none;\r\n\tleft: -10000px;\r\n\ttop: -10000px;\r\n\tposition: absolute;\r\n\ttext-align: left;\r\n\tbackground-color: #898989;\r\n\tborder-radius: 2px;\r\n\tz-index: 10000;\r\n\tdisplay: inline-block;\r\n\tcolor: white;\r\n\tfont-size: 12px;\r\n\ttext-align: center;\r\n\tpadding: 2px;\r\n\twhite-space:nowrap;\r\n}\r\n.web-middleLine{\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\twidth: 0px;\r\n\tborder-right: dashed 1px #898989;\r\n}\r\n\r\n.tech-index{\r\n\tposition:absolute;\r\n\tz-index: 99;\r\n}\r\n\r\n.tech-index-item{\r\n\tbackground-color: #707070;\r\n\tfloat:left;\r\n\ttext-align: center;\r\n\tcolor:#fff;\r\n\tcursor: pointer;\r\n}\r\n\r\n.tech-index .current{\r\n\tbackground-color: #c2c2c2;\r\n\tcolor:#707070;\r\n}\r\n\r\n\r\n/*web版图表样式*/\r\n.web-show-tip {\r\n\tposition: absolute;\r\n\ttop: 0px;\r\n\tbackground-color: red;\r\n\tz-index: 999;\r\n\tborder: 1px solid #97c8ff;\r\n\t/*padding: 8px;*/\r\n\tbox-shadow: 2px 2px 2px rgba(0,0,0,0.1);\r\n\tbackground-color: #fff;\r\n\tcolor: #666;\r\n\twidth: 120px;\r\n\tfont-size: 12px;\r\n\tfont-weight: lighter;\r\n\tfont-family: 'arial';\r\n\r\n\t/*white-space: nowrap;*/\r\n}\r\n\r\n.web-tip-line-left{\r\n\tfloat: left;\r\n\twidth:50%;\r\n\ttext-align: left;\r\n\theight:20px;\r\n\tline-height: 20px;\r\n\r\n\t*height:15px;\r\n\t*line-height: 15px;\r\n}\r\n\r\n.web-tip-line-right{\r\n\tfloat: left;\r\n\twidth:50%;\r\n\ttext-align: right;\r\n\theight:20px;\r\n\tline-height: 20px;\r\n\t\r\n\t*height:15px;\r\n\t*line-height: 15px;\r\n}\r\n\r\n.web-tip-first-line{\r\n\twidth:100%;\r\n\tbackground: #edf5ff;\r\n\theight:30px;\r\n\tline-height: 30px;\r\n\ttext-align: center;\r\n}\r\n\r\n.web-tip-line-container{\r\n\tpadding:8px;\r\n\t*margin-bottom: 8px;\r\n}\r\n\r\n.time-tips-coordinate{\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\tpadding: 0px 3px;\r\n\tfont-size: 14px;\r\n\tbackground-color: #aaa;\r\n\tcolor: white;\r\n\tz-index: 1000;\r\n}\r\n.time-tips-top{\r\n\tdisplay: none;\r\n\tfont-size: 14px;\r\n\tcolor: #888;\r\n\tposition: absolute;\r\n\ttop: 0px;\r\n}\r\n\r\n/* web版 k线图指标样式 */\r\n\r\n.kt-pad {\r\n    position: absolute;\r\n    color: #5F5F5F;\r\n    margin-left: 15px;\r\n    min-width: 70px;\r\n}\r\n\r\n.kt-title {\r\n    margin-bottom: 5px;\r\n    font-size: 14px;\r\n}\r\n\r\n.kt-line {\r\n    background-color: white; position: relative; margin: 10px 0px;\r\n}\r\n\r\n.kt-line:hover{\r\n    cursor: pointer;\r\n}\r\n\r\n.kt-radio-wrap{\r\n\tposition: relative; display: inline-block; *zoom:1;*display:inline; border: solid 1px #305896;height: 10px; width: 10px;background-color: white;\r\n}\r\n\r\n.kt-radio {\r\n    position:absolute; margin: 2px; width: 6px; height: 6px; background-color: #305896;display: none;\r\n}\r\n\r\n.kt-name {\r\n    color: #555;line-height: 10px;display: inline-block; height: 10px;padding-left: 5px;position: absolute; top: 3px; left: 15px;\r\n}\r\n\r\n.kt-radio-choose {\r\n    display: block;\r\n}\r\n\r\n/* web k 线的滑动 */\r\n.slideBarCVS{\r\n\tbackground-color: white;\r\n\toutline: solid 1px #E9E9E9;\r\n\r\n}\r\n\r\n.leftDrag{\r\n\tbackground-color: white;\r\n\topacity: 2;\r\n\tfilter: alpha(opacity=200);\r\n}\r\n.leftDrag:hover{\r\n\tcursor: w-resize;\r\n}\r\n\r\n.rightDrag{\r\n\tbackground-color: white;\r\n}\r\n.rightDrag:hover{cursor: e-resize;}\r\n.containerBar{\r\n\tbackground-color: #e0e0e0;\r\n\topacity: 0.5;\r\n\tfilter: alpha(opacity=50);\r\n\tborder:solid 1px #35709C;\r\n}\r\n.containerBar:hover{cursor: move;}", ""]);
	
	// exports


/***/ },
/* 69 */
/***/ function(module, exports) {

	/*
		MIT License http://www.opensource.org/licenses/mit-license.php
		Author Tobias Koppers @sokra
	*/
	// css base code, injected by the css-loader
	module.exports = function() {
		var list = [];
	
		// return the list of modules as css string
		list.toString = function toString() {
			var result = [];
			for(var i = 0; i < this.length; i++) {
				var item = this[i];
				if(item[2]) {
					result.push("@media " + item[2] + "{" + item[1] + "}");
				} else {
					result.push(item[1]);
				}
			}
			return result.join("");
		};
	
		// import a list of modules into the list
		list.i = function(modules, mediaQuery) {
			if(typeof modules === "string")
				modules = [[null, modules, ""]];
			var alreadyImportedModules = {};
			for(var i = 0; i < this.length; i++) {
				var id = this[i][0];
				if(typeof id === "number")
					alreadyImportedModules[id] = true;
			}
			for(i = 0; i < modules.length; i++) {
				var item = modules[i];
				// skip already imported module
				// this implementation is not 100% perfect for weird media query combinations
				//  when a module is imported multiple times with different media queries.
				//  I hope this will never occur (Hey this way we have smaller bundles)
				if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
					if(mediaQuery && !item[2]) {
						item[2] = mediaQuery;
					} else if(mediaQuery) {
						item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
					}
					list.push(item);
				}
			}
		};
		return list;
	};


/***/ },
/* 70 */
/***/ function(module, exports) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAADCAYAAAB4bZQtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAdSURBVHjaYvz///9/BhoBJgYaApoaDgAAAP//AwBSRgQCNPlECAAAAABJRU5ErkJggg=="

/***/ },
/* 71 */
/***/ function(module, exports) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAXCAYAAADgKtSgAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAABFSURBVHjaYjxz5gwDMcDY2Pg/jH327FlGYvQwMdAQjBo+avhIMJzx/////0eDBR2wEFsIjRZco4aPGj4AhgMAAAD//wMAq70Q99ei408AAAAASUVORK5CYII="

/***/ },
/* 72 */
/***/ function(module, exports) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoxQjBBMjM2MjI2REMxMUU2QURERTg3REFCOEYzQUQzNiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoxQjBBMjM2MzI2REMxMUU2QURERTg3REFCOEYzQUQzNiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjFCMEEyMzYwMjZEQzExRTZBRERFODdEQUI4RjNBRDM2IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjFCMEEyMzYxMjZEQzExRTZBRERFODdEQUI4RjNBRDM2Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+FqRI6gAAAypJREFUeNqsVktIlFEUPhND6DRgOfSCCFs0jQYNWTaJ1qRGjQxhRNKDFi2KJCOoyFVFJgQ9XAQtkhRclVCJFoa5GJUpQQrCFmkygdAsejCZYSO1mb7Dvf/8j7nzAg98zP3Pvfd8cx733GtLHKRs4gZ41T6gDHBJfQz4CAwBfcB0JiO2DER+oA3YRblJGLgKjKomlyh0BcADYDgPEpJrh+XegmxExUAIOMPeUv5ik3tD0paSyAG8BCqTmtsTRCvcapOH24kuD6YjrJS2HJrCbpi8B/hMy11riIrWEc3KPJfU6nPTb4kO4c8HkJapN7p+Lqqt90mbp43F4JfxNYer6xvK4RjRTEh4djcs9IXLiBb+6Ov4m4V14RdE3ae0mQRQwwWiEbGF6uS/3h4Uy+pPiI3zc0RPL+le3XxO1Fyue3odHs1MGgmM8poLhXPkTZKweKoEAaN4FZYcEGMtV+xd9DNRQ4v4Zr0bJiLv0+WLbXvZo1YMrqVMbzlK1PqY6EKdOnRaqKyhfHKfaLDNau2GPe1ZKd8rfvccR0hCoijYw/4uEUoWZ5E+ZtmBPc7lKmu7mcijJCqrIPr5nWgbchlpRrgmhX7kkfCwGrqzt8y5cnaC+JfK2ia7oXeZw1boFOOBbqIjFxHceqL2c3pBMDGHqw4l/m5A/xNc3qni4hz9xWCpSc0H8UdUFAKXdyMSH/+NcPrNJW0scU1iX4lavFbtP7vswmtN3ni2EnWeF0QsdwLmbScRopJSlHVVrq0pxkRTJiIuAj47sxm6/koUhsMp2pBRuFt86FHt+GSXh7UmqdKSnUnY4y8Rog2bdd36jeJbTRRmol7TOcpGwl7E51PDpuVVLc+4M0zINpFduNq4kY72pc6xR8YzZW5BE1r3vqJsqkbhLt2I8h7q0fseF467Qhxc12qRI7Mk5K2bvI/4+n2oLFXtXOwMWDuzKBzug3y4eztU+WGbI9Y3g0PejD5aHBkH+AKLW29YVgTlgsUgCWokqjdDTJZ6h4xvvpKQe2ulrYyvoAWgSRKO5UEyJgmajJ7k8q5LHk+gAdgPlFoekNzSXwH9ssOklf8CDADTqe/lOuA5/wAAAABJRU5ErkJggg=="

/***/ },
/* 73 */
/***/ function(module, exports, __webpack_require__) {

	/*
		MIT License http://www.opensource.org/licenses/mit-license.php
		Author Tobias Koppers @sokra
	*/
	var stylesInDom = {},
		memoize = function(fn) {
			var memo;
			return function () {
				if (typeof memo === "undefined") memo = fn.apply(this, arguments);
				return memo;
			};
		},
		isOldIE = memoize(function() {
			return /msie [6-9]\b/.test(window.navigator.userAgent.toLowerCase());
		}),
		getHeadElement = memoize(function () {
			return document.head || document.getElementsByTagName("head")[0];
		}),
		singletonElement = null,
		singletonCounter = 0,
		styleElementsInsertedAtTop = [];
	
	module.exports = function(list, options) {
		if(false) {
			if(typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
		}
	
		options = options || {};
		// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
		// tags it will allow on a page
		if (typeof options.singleton === "undefined") options.singleton = isOldIE();
	
		// By default, add <style> tags to the bottom of <head>.
		if (typeof options.insertAt === "undefined") options.insertAt = "bottom";
	
		var styles = listToStyles(list);
		addStylesToDom(styles, options);
	
		return function update(newList) {
			var mayRemove = [];
			for(var i = 0; i < styles.length; i++) {
				var item = styles[i];
				var domStyle = stylesInDom[item.id];
				domStyle.refs--;
				mayRemove.push(domStyle);
			}
			if(newList) {
				var newStyles = listToStyles(newList);
				addStylesToDom(newStyles, options);
			}
			for(var i = 0; i < mayRemove.length; i++) {
				var domStyle = mayRemove[i];
				if(domStyle.refs === 0) {
					for(var j = 0; j < domStyle.parts.length; j++)
						domStyle.parts[j]();
					delete stylesInDom[domStyle.id];
				}
			}
		};
	}
	
	function addStylesToDom(styles, options) {
		for(var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];
			if(domStyle) {
				domStyle.refs++;
				for(var j = 0; j < domStyle.parts.length; j++) {
					domStyle.parts[j](item.parts[j]);
				}
				for(; j < item.parts.length; j++) {
					domStyle.parts.push(addStyle(item.parts[j], options));
				}
			} else {
				var parts = [];
				for(var j = 0; j < item.parts.length; j++) {
					parts.push(addStyle(item.parts[j], options));
				}
				stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
			}
		}
	}
	
	function listToStyles(list) {
		var styles = [];
		var newStyles = {};
		for(var i = 0; i < list.length; i++) {
			var item = list[i];
			var id = item[0];
			var css = item[1];
			var media = item[2];
			var sourceMap = item[3];
			var part = {css: css, media: media, sourceMap: sourceMap};
			if(!newStyles[id])
				styles.push(newStyles[id] = {id: id, parts: [part]});
			else
				newStyles[id].parts.push(part);
		}
		return styles;
	}
	
	function insertStyleElement(options, styleElement) {
		var head = getHeadElement();
		var lastStyleElementInsertedAtTop = styleElementsInsertedAtTop[styleElementsInsertedAtTop.length - 1];
		if (options.insertAt === "top") {
			if(!lastStyleElementInsertedAtTop) {
				head.insertBefore(styleElement, head.firstChild);
			} else if(lastStyleElementInsertedAtTop.nextSibling) {
				head.insertBefore(styleElement, lastStyleElementInsertedAtTop.nextSibling);
			} else {
				head.appendChild(styleElement);
			}
			styleElementsInsertedAtTop.push(styleElement);
		} else if (options.insertAt === "bottom") {
			head.appendChild(styleElement);
		} else {
			throw new Error("Invalid value for parameter 'insertAt'. Must be 'top' or 'bottom'.");
		}
	}
	
	function removeStyleElement(styleElement) {
		styleElement.parentNode.removeChild(styleElement);
		var idx = styleElementsInsertedAtTop.indexOf(styleElement);
		if(idx >= 0) {
			styleElementsInsertedAtTop.splice(idx, 1);
		}
	}
	
	function createStyleElement(options) {
		var styleElement = document.createElement("style");
		styleElement.type = "text/css";
		insertStyleElement(options, styleElement);
		return styleElement;
	}
	
	function createLinkElement(options) {
		var linkElement = document.createElement("link");
		linkElement.rel = "stylesheet";
		insertStyleElement(options, linkElement);
		return linkElement;
	}
	
	function addStyle(obj, options) {
		var styleElement, update, remove;
	
		if (options.singleton) {
			var styleIndex = singletonCounter++;
			styleElement = singletonElement || (singletonElement = createStyleElement(options));
			update = applyToSingletonTag.bind(null, styleElement, styleIndex, false);
			remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true);
		} else if(obj.sourceMap &&
			typeof URL === "function" &&
			typeof URL.createObjectURL === "function" &&
			typeof URL.revokeObjectURL === "function" &&
			typeof Blob === "function" &&
			typeof btoa === "function") {
			styleElement = createLinkElement(options);
			update = updateLink.bind(null, styleElement);
			remove = function() {
				removeStyleElement(styleElement);
				if(styleElement.href)
					URL.revokeObjectURL(styleElement.href);
			};
		} else {
			styleElement = createStyleElement(options);
			update = applyToTag.bind(null, styleElement);
			remove = function() {
				removeStyleElement(styleElement);
			};
		}
	
		update(obj);
	
		return function updateStyle(newObj) {
			if(newObj) {
				if(newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap)
					return;
				update(obj = newObj);
			} else {
				remove();
			}
		};
	}
	
	var replaceText = (function () {
		var textStore = [];
	
		return function (index, replacement) {
			textStore[index] = replacement;
			return textStore.filter(Boolean).join('\n');
		};
	})();
	
	function applyToSingletonTag(styleElement, index, remove, obj) {
		var css = remove ? "" : obj.css;
	
		if (styleElement.styleSheet) {
			styleElement.styleSheet.cssText = replaceText(index, css);
		} else {
			var cssNode = document.createTextNode(css);
			var childNodes = styleElement.childNodes;
			if (childNodes[index]) styleElement.removeChild(childNodes[index]);
			if (childNodes.length) {
				styleElement.insertBefore(cssNode, childNodes[index]);
			} else {
				styleElement.appendChild(cssNode);
			}
		}
	}
	
	function applyToTag(styleElement, obj) {
		var css = obj.css;
		var media = obj.media;
	
		if(media) {
			styleElement.setAttribute("media", media)
		}
	
		if(styleElement.styleSheet) {
			styleElement.styleSheet.cssText = css;
		} else {
			while(styleElement.firstChild) {
				styleElement.removeChild(styleElement.firstChild);
			}
			styleElement.appendChild(document.createTextNode(css));
		}
	}
	
	function updateLink(linkElement, obj) {
		var css = obj.css;
		var sourceMap = obj.sourceMap;
	
		if(sourceMap) {
			// http://stackoverflow.com/a/26603875
			css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
		}
	
		var blob = new Blob([css], { type: "text/css" });
	
		var oldSrc = linkElement.href;
	
		linkElement.href = URL.createObjectURL(blob);
	
		if(oldSrc)
			URL.revokeObjectURL(oldSrc);
	}


/***/ }
/******/ ]);
//# sourceMappingURL=mobile_emcharts.js.map