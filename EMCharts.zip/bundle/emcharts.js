/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(1);
	__webpack_require__(2);
	module.exports = __webpack_require__(3);


/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
	 * https://github.com/es-shims/es5-shim
	 * @license es5-shim Copyright 2009-2015 by contributors, MIT License
	 * see https://github.com/es-shims/es5-shim/blob/master/LICENSE
	 */
	
	// vim: ts=4 sts=4 sw=4 expandtab
	
	// Add semicolon to prevent IIFE from being passed as argument to concatenated code.
	;
	
	// UMD (Universal Module Definition)
	// see https://github.com/umdjs/umd/blob/master/templates/returnExports.js
	(function (root, factory) {
	    'use strict';
	
	    /* global define, exports, module */
	    if (true) {
	        // AMD. Register as an anonymous module.
	        !(__WEBPACK_AMD_DEFINE_FACTORY__ = (factory), __WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module)) : __WEBPACK_AMD_DEFINE_FACTORY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	    } else if (typeof exports === 'object') {
	        // Node. Does not work with strict CommonJS, but
	        // only CommonJS-like enviroments that support module.exports,
	        // like Node.
	        module.exports = factory();
	    } else {
	        // Browser globals (root is window)
	        root.returnExports = factory();
	    }
	}(this, function () {
	    /**
	     * Brings an environment as close to ECMAScript 5 compliance
	     * as is possible with the facilities of erstwhile engines.
	     *
	     * Annotated ES5: http://es5.github.com/ (specific links below)
	     * ES5 Spec: http://www.ecma-international.org/publications/files/ECMA-ST/Ecma-262.pdf
	     * Required reading: http://javascriptweblog.wordpress.com/2011/12/05/extending-javascript-natives/
	     */
	
	    // Shortcut to an often accessed properties, in order to avoid multiple
	    // dereference that costs universally. This also holds a reference to known-good
	    // functions.
	    var $Array = Array;
	    var ArrayPrototype = $Array.prototype;
	    var $Object = Object;
	    var ObjectPrototype = $Object.prototype;
	    var $Function = Function;
	    var FunctionPrototype = $Function.prototype;
	    var $String = String;
	    var StringPrototype = $String.prototype;
	    var $Number = Number;
	    var NumberPrototype = $Number.prototype;
	    var array_slice = ArrayPrototype.slice;
	    var array_splice = ArrayPrototype.splice;
	    var array_push = ArrayPrototype.push;
	    var array_unshift = ArrayPrototype.unshift;
	    var array_concat = ArrayPrototype.concat;
	    var array_join = ArrayPrototype.join;
	    var call = FunctionPrototype.call;
	    var apply = FunctionPrototype.apply;
	    var max = Math.max;
	    var min = Math.min;
	
	    // Having a toString local variable name breaks in Opera so use to_string.
	    var to_string = ObjectPrototype.toString;
	
	    /* global Symbol */
	    /* eslint-disable one-var-declaration-per-line, no-redeclare, max-statements-per-line */
	    var hasToStringTag = typeof Symbol === 'function' && typeof Symbol.toStringTag === 'symbol';
	    var isCallable; /* inlined from https://npmjs.com/is-callable */ var fnToStr = Function.prototype.toString, constructorRegex = /^\s*class /, isES6ClassFn = function isES6ClassFn(value) { try { var fnStr = fnToStr.call(value); var singleStripped = fnStr.replace(/\/\/.*\n/g, ''); var multiStripped = singleStripped.replace(/\/\*[.\s\S]*\*\//g, ''); var spaceStripped = multiStripped.replace(/\n/mg, ' ').replace(/ {2}/g, ' '); return constructorRegex.test(spaceStripped); } catch (e) { return false; /* not a function */ } }, tryFunctionObject = function tryFunctionObject(value) { try { if (isES6ClassFn(value)) { return false; } fnToStr.call(value); return true; } catch (e) { return false; } }, fnClass = '[object Function]', genClass = '[object GeneratorFunction]', isCallable = function isCallable(value) { if (!value) { return false; } if (typeof value !== 'function' && typeof value !== 'object') { return false; } if (hasToStringTag) { return tryFunctionObject(value); } if (isES6ClassFn(value)) { return false; } var strClass = to_string.call(value); return strClass === fnClass || strClass === genClass; };
	
	    var isRegex; /* inlined from https://npmjs.com/is-regex */ var regexExec = RegExp.prototype.exec, tryRegexExec = function tryRegexExec(value) { try { regexExec.call(value); return true; } catch (e) { return false; } }, regexClass = '[object RegExp]'; isRegex = function isRegex(value) { if (typeof value !== 'object') { return false; } return hasToStringTag ? tryRegexExec(value) : to_string.call(value) === regexClass; };
	    var isString; /* inlined from https://npmjs.com/is-string */ var strValue = String.prototype.valueOf, tryStringObject = function tryStringObject(value) { try { strValue.call(value); return true; } catch (e) { return false; } }, stringClass = '[object String]'; isString = function isString(value) { if (typeof value === 'string') { return true; } if (typeof value !== 'object') { return false; } return hasToStringTag ? tryStringObject(value) : to_string.call(value) === stringClass; };
	    /* eslint-enable one-var-declaration-per-line, no-redeclare, max-statements-per-line */
	
	    /* inlined from http://npmjs.com/define-properties */
	    var supportsDescriptors = $Object.defineProperty && (function () {
	        try {
	            var obj = {};
	            $Object.defineProperty(obj, 'x', { enumerable: false, value: obj });
	            for (var _ in obj) { // jscs:ignore disallowUnusedVariables
	                return false;
	            }
	            return obj.x === obj;
	        } catch (e) { /* this is ES3 */
	            return false;
	        }
	    }());
	    var defineProperties = (function (has) {
	        // Define configurable, writable, and non-enumerable props
	        // if they don't exist.
	        var defineProperty;
	        if (supportsDescriptors) {
	            defineProperty = function (object, name, method, forceAssign) {
	                if (!forceAssign && (name in object)) {
	                    return;
	                }
	                $Object.defineProperty(object, name, {
	                    configurable: true,
	                    enumerable: false,
	                    writable: true,
	                    value: method
	                });
	            };
	        } else {
	            defineProperty = function (object, name, method, forceAssign) {
	                if (!forceAssign && (name in object)) {
	                    return;
	                }
	                object[name] = method;
	            };
	        }
	        return function defineProperties(object, map, forceAssign) {
	            for (var name in map) {
	                if (has.call(map, name)) {
	                    defineProperty(object, name, map[name], forceAssign);
	                }
	            }
	        };
	    }(ObjectPrototype.hasOwnProperty));
	
	    //
	    // Util
	    // ======
	    //
	
	    /* replaceable with https://npmjs.com/package/es-abstract /helpers/isPrimitive */
	    var isPrimitive = function isPrimitive(input) {
	        var type = typeof input;
	        return input === null || (type !== 'object' && type !== 'function');
	    };
	
	    var isActualNaN = $Number.isNaN || function isActualNaN(x) {
	        return x !== x;
	    };
	
	    var ES = {
	        // ES5 9.4
	        // http://es5.github.com/#x9.4
	        // http://jsperf.com/to-integer
	        /* replaceable with https://npmjs.com/package/es-abstract ES5.ToInteger */
	        ToInteger: function ToInteger(num) {
	            var n = +num;
	            if (isActualNaN(n)) {
	                n = 0;
	            } else if (n !== 0 && n !== (1 / 0) && n !== -(1 / 0)) {
	                n = (n > 0 || -1) * Math.floor(Math.abs(n));
	            }
	            return n;
	        },
	
	        /* replaceable with https://npmjs.com/package/es-abstract ES5.ToPrimitive */
	        ToPrimitive: function ToPrimitive(input) {
	            var val, valueOf, toStr;
	            if (isPrimitive(input)) {
	                return input;
	            }
	            valueOf = input.valueOf;
	            if (isCallable(valueOf)) {
	                val = valueOf.call(input);
	                if (isPrimitive(val)) {
	                    return val;
	                }
	            }
	            toStr = input.toString;
	            if (isCallable(toStr)) {
	                val = toStr.call(input);
	                if (isPrimitive(val)) {
	                    return val;
	                }
	            }
	            throw new TypeError();
	        },
	
	        // ES5 9.9
	        // http://es5.github.com/#x9.9
	        /* replaceable with https://npmjs.com/package/es-abstract ES5.ToObject */
	        ToObject: function (o) {
	            if (o == null) { // this matches both null and undefined
	                throw new TypeError("can't convert " + o + ' to object');
	            }
	            return $Object(o);
	        },
	
	        /* replaceable with https://npmjs.com/package/es-abstract ES5.ToUint32 */
	        ToUint32: function ToUint32(x) {
	            return x >>> 0;
	        }
	    };
	
	    //
	    // Function
	    // ========
	    //
	
	    // ES-5 15.3.4.5
	    // http://es5.github.com/#x15.3.4.5
	
	    var Empty = function Empty() {};
	
	    defineProperties(FunctionPrototype, {
	        bind: function bind(that) { // .length is 1
	            // 1. Let Target be the this value.
	            var target = this;
	            // 2. If IsCallable(Target) is false, throw a TypeError exception.
	            if (!isCallable(target)) {
	                throw new TypeError('Function.prototype.bind called on incompatible ' + target);
	            }
	            // 3. Let A be a new (possibly empty) internal list of all of the
	            //   argument values provided after thisArg (arg1, arg2 etc), in order.
	            // XXX slicedArgs will stand in for "A" if used
	            var args = array_slice.call(arguments, 1); // for normal call
	            // 4. Let F be a new native ECMAScript object.
	            // 11. Set the [[Prototype]] internal property of F to the standard
	            //   built-in Function prototype object as specified in 15.3.3.1.
	            // 12. Set the [[Call]] internal property of F as described in
	            //   15.3.4.5.1.
	            // 13. Set the [[Construct]] internal property of F as described in
	            //   15.3.4.5.2.
	            // 14. Set the [[HasInstance]] internal property of F as described in
	            //   15.3.4.5.3.
	            var bound;
	            var binder = function () {
	
	                if (this instanceof bound) {
	                    // 15.3.4.5.2 [[Construct]]
	                    // When the [[Construct]] internal method of a function object,
	                    // F that was created using the bind function is called with a
	                    // list of arguments ExtraArgs, the following steps are taken:
	                    // 1. Let target be the value of F's [[TargetFunction]]
	                    //   internal property.
	                    // 2. If target has no [[Construct]] internal method, a
	                    //   TypeError exception is thrown.
	                    // 3. Let boundArgs be the value of F's [[BoundArgs]] internal
	                    //   property.
	                    // 4. Let args be a new list containing the same values as the
	                    //   list boundArgs in the same order followed by the same
	                    //   values as the list ExtraArgs in the same order.
	                    // 5. Return the result of calling the [[Construct]] internal
	                    //   method of target providing args as the arguments.
	
	                    var result = apply.call(
	                        target,
	                        this,
	                        array_concat.call(args, array_slice.call(arguments))
	                    );
	                    if ($Object(result) === result) {
	                        return result;
	                    }
	                    return this;
	
	                } else {
	                    // 15.3.4.5.1 [[Call]]
	                    // When the [[Call]] internal method of a function object, F,
	                    // which was created using the bind function is called with a
	                    // this value and a list of arguments ExtraArgs, the following
	                    // steps are taken:
	                    // 1. Let boundArgs be the value of F's [[BoundArgs]] internal
	                    //   property.
	                    // 2. Let boundThis be the value of F's [[BoundThis]] internal
	                    //   property.
	                    // 3. Let target be the value of F's [[TargetFunction]] internal
	                    //   property.
	                    // 4. Let args be a new list containing the same values as the
	                    //   list boundArgs in the same order followed by the same
	                    //   values as the list ExtraArgs in the same order.
	                    // 5. Return the result of calling the [[Call]] internal method
	                    //   of target providing boundThis as the this value and
	                    //   providing args as the arguments.
	
	                    // equiv: target.call(this, ...boundArgs, ...args)
	                    return apply.call(
	                        target,
	                        that,
	                        array_concat.call(args, array_slice.call(arguments))
	                    );
	
	                }
	
	            };
	
	            // 15. If the [[Class]] internal property of Target is "Function", then
	            //     a. Let L be the length property of Target minus the length of A.
	            //     b. Set the length own property of F to either 0 or L, whichever is
	            //       larger.
	            // 16. Else set the length own property of F to 0.
	
	            var boundLength = max(0, target.length - args.length);
	
	            // 17. Set the attributes of the length own property of F to the values
	            //   specified in 15.3.5.1.
	            var boundArgs = [];
	            for (var i = 0; i < boundLength; i++) {
	                array_push.call(boundArgs, '$' + i);
	            }
	
	            // XXX Build a dynamic function with desired amount of arguments is the only
	            // way to set the length property of a function.
	            // In environments where Content Security Policies enabled (Chrome extensions,
	            // for ex.) all use of eval or Function costructor throws an exception.
	            // However in all of these environments Function.prototype.bind exists
	            // and so this code will never be executed.
	            bound = $Function('binder', 'return function (' + array_join.call(boundArgs, ',') + '){ return binder.apply(this, arguments); }')(binder);
	
	            if (target.prototype) {
	                Empty.prototype = target.prototype;
	                bound.prototype = new Empty();
	                // Clean up dangling references.
	                Empty.prototype = null;
	            }
	
	            // TODO
	            // 18. Set the [[Extensible]] internal property of F to true.
	
	            // TODO
	            // 19. Let thrower be the [[ThrowTypeError]] function Object (13.2.3).
	            // 20. Call the [[DefineOwnProperty]] internal method of F with
	            //   arguments "caller", PropertyDescriptor {[[Get]]: thrower, [[Set]]:
	            //   thrower, [[Enumerable]]: false, [[Configurable]]: false}, and
	            //   false.
	            // 21. Call the [[DefineOwnProperty]] internal method of F with
	            //   arguments "arguments", PropertyDescriptor {[[Get]]: thrower,
	            //   [[Set]]: thrower, [[Enumerable]]: false, [[Configurable]]: false},
	            //   and false.
	
	            // TODO
	            // NOTE Function objects created using Function.prototype.bind do not
	            // have a prototype property or the [[Code]], [[FormalParameters]], and
	            // [[Scope]] internal properties.
	            // XXX can't delete prototype in pure-js.
	
	            // 22. Return F.
	            return bound;
	        }
	    });
	
	    // _Please note: Shortcuts are defined after `Function.prototype.bind` as we
	    // use it in defining shortcuts.
	    var owns = call.bind(ObjectPrototype.hasOwnProperty);
	    var toStr = call.bind(ObjectPrototype.toString);
	    var arraySlice = call.bind(array_slice);
	    var arraySliceApply = apply.bind(array_slice);
	    var strSlice = call.bind(StringPrototype.slice);
	    var strSplit = call.bind(StringPrototype.split);
	    var strIndexOf = call.bind(StringPrototype.indexOf);
	    var pushCall = call.bind(array_push);
	    var isEnum = call.bind(ObjectPrototype.propertyIsEnumerable);
	    var arraySort = call.bind(ArrayPrototype.sort);
	
	    //
	    // Array
	    // =====
	    //
	
	    var isArray = $Array.isArray || function isArray(obj) {
	        return toStr(obj) === '[object Array]';
	    };
	
	    // ES5 15.4.4.12
	    // http://es5.github.com/#x15.4.4.13
	    // Return len+argCount.
	    // [bugfix, ielt8]
	    // IE < 8 bug: [].unshift(0) === undefined but should be "1"
	    var hasUnshiftReturnValueBug = [].unshift(0) !== 1;
	    defineProperties(ArrayPrototype, {
	        unshift: function () {
	            array_unshift.apply(this, arguments);
	            return this.length;
	        }
	    }, hasUnshiftReturnValueBug);
	
	    // ES5 15.4.3.2
	    // http://es5.github.com/#x15.4.3.2
	    // https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/isArray
	    defineProperties($Array, { isArray: isArray });
	
	    // The IsCallable() check in the Array functions
	    // has been replaced with a strict check on the
	    // internal class of the object to trap cases where
	    // the provided function was actually a regular
	    // expression literal, which in V8 and
	    // JavaScriptCore is a typeof "function".  Only in
	    // V8 are regular expression literals permitted as
	    // reduce parameters, so it is desirable in the
	    // general case for the shim to match the more
	    // strict and common behavior of rejecting regular
	    // expressions.
	
	    // ES5 15.4.4.18
	    // http://es5.github.com/#x15.4.4.18
	    // https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/array/forEach
	
	    // Check failure of by-index access of string characters (IE < 9)
	    // and failure of `0 in boxedString` (Rhino)
	    var boxedString = $Object('a');
	    var splitString = boxedString[0] !== 'a' || !(0 in boxedString);
	
	    var properlyBoxesContext = function properlyBoxed(method) {
	        // Check node 0.6.21 bug where third parameter is not boxed
	        var properlyBoxesNonStrict = true;
	        var properlyBoxesStrict = true;
	        var threwException = false;
	        if (method) {
	            try {
	                method.call('foo', function (_, __, context) {
	                    if (typeof context !== 'object') {
	                        properlyBoxesNonStrict = false;
	                    }
	                });
	
	                method.call([1], function () {
	                    'use strict';
	
	                    properlyBoxesStrict = typeof this === 'string';
	                }, 'x');
	            } catch (e) {
	                threwException = true;
	            }
	        }
	        return !!method && !threwException && properlyBoxesNonStrict && properlyBoxesStrict;
	    };
	
	    defineProperties(ArrayPrototype, {
	        forEach: function forEach(callbackfn/*, thisArg*/) {
	            var object = ES.ToObject(this);
	            var self = splitString && isString(this) ? strSplit(this, '') : object;
	            var i = -1;
	            var length = ES.ToUint32(self.length);
	            var T;
	            if (arguments.length > 1) {
	                T = arguments[1];
	            }
	
	            // If no callback function or if callback is not a callable function
	            if (!isCallable(callbackfn)) {
	                throw new TypeError('Array.prototype.forEach callback must be a function');
	            }
	
	            while (++i < length) {
	                if (i in self) {
	                    // Invoke the callback function with call, passing arguments:
	                    // context, property value, property key, thisArg object
	                    if (typeof T === 'undefined') {
	                        callbackfn(self[i], i, object);
	                    } else {
	                        callbackfn.call(T, self[i], i, object);
	                    }
	                }
	            }
	        }
	    }, !properlyBoxesContext(ArrayPrototype.forEach));
	
	    // ES5 15.4.4.19
	    // http://es5.github.com/#x15.4.4.19
	    // https://developer.mozilla.org/en/Core_JavaScript_1.5_Reference/Objects/Array/map
	    defineProperties(ArrayPrototype, {
	        map: function map(callbackfn/*, thisArg*/) {
	            var object = ES.ToObject(this);
	            var self = splitString && isString(this) ? strSplit(this, '') : object;
	            var length = ES.ToUint32(self.length);
	            var result = $Array(length);
	            var T;
	            if (arguments.length > 1) {
	                T = arguments[1];
	            }
	
	            // If no callback function or if callback is not a callable function
	            if (!isCallable(callbackfn)) {
	                throw new TypeError('Array.prototype.map callback must be a function');
	            }
	
	            for (var i = 0; i < length; i++) {
	                if (i in self) {
	                    if (typeof T === 'undefined') {
	                        result[i] = callbackfn(self[i], i, object);
	                    } else {
	                        result[i] = callbackfn.call(T, self[i], i, object);
	                    }
	                }
	            }
	            return result;
	        }
	    }, !properlyBoxesContext(ArrayPrototype.map));
	
	    // ES5 15.4.4.20
	    // http://es5.github.com/#x15.4.4.20
	    // https://developer.mozilla.org/en/Core_JavaScript_1.5_Reference/Objects/Array/filter
	    defineProperties(ArrayPrototype, {
	        filter: function filter(callbackfn/*, thisArg*/) {
	            var object = ES.ToObject(this);
	            var self = splitString && isString(this) ? strSplit(this, '') : object;
	            var length = ES.ToUint32(self.length);
	            var result = [];
	            var value;
	            var T;
	            if (arguments.length > 1) {
	                T = arguments[1];
	            }
	
	            // If no callback function or if callback is not a callable function
	            if (!isCallable(callbackfn)) {
	                throw new TypeError('Array.prototype.filter callback must be a function');
	            }
	
	            for (var i = 0; i < length; i++) {
	                if (i in self) {
	                    value = self[i];
	                    if (typeof T === 'undefined' ? callbackfn(value, i, object) : callbackfn.call(T, value, i, object)) {
	                        pushCall(result, value);
	                    }
	                }
	            }
	            return result;
	        }
	    }, !properlyBoxesContext(ArrayPrototype.filter));
	
	    // ES5 15.4.4.16
	    // http://es5.github.com/#x15.4.4.16
	    // https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/every
	    defineProperties(ArrayPrototype, {
	        every: function every(callbackfn/*, thisArg*/) {
	            var object = ES.ToObject(this);
	            var self = splitString && isString(this) ? strSplit(this, '') : object;
	            var length = ES.ToUint32(self.length);
	            var T;
	            if (arguments.length > 1) {
	                T = arguments[1];
	            }
	
	            // If no callback function or if callback is not a callable function
	            if (!isCallable(callbackfn)) {
	                throw new TypeError('Array.prototype.every callback must be a function');
	            }
	
	            for (var i = 0; i < length; i++) {
	                if (i in self && !(typeof T === 'undefined' ? callbackfn(self[i], i, object) : callbackfn.call(T, self[i], i, object))) {
	                    return false;
	                }
	            }
	            return true;
	        }
	    }, !properlyBoxesContext(ArrayPrototype.every));
	
	    // ES5 15.4.4.17
	    // http://es5.github.com/#x15.4.4.17
	    // https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/some
	    defineProperties(ArrayPrototype, {
	        some: function some(callbackfn/*, thisArg */) {
	            var object = ES.ToObject(this);
	            var self = splitString && isString(this) ? strSplit(this, '') : object;
	            var length = ES.ToUint32(self.length);
	            var T;
	            if (arguments.length > 1) {
	                T = arguments[1];
	            }
	
	            // If no callback function or if callback is not a callable function
	            if (!isCallable(callbackfn)) {
	                throw new TypeError('Array.prototype.some callback must be a function');
	            }
	
	            for (var i = 0; i < length; i++) {
	                if (i in self && (typeof T === 'undefined' ? callbackfn(self[i], i, object) : callbackfn.call(T, self[i], i, object))) {
	                    return true;
	                }
	            }
	            return false;
	        }
	    }, !properlyBoxesContext(ArrayPrototype.some));
	
	    // ES5 15.4.4.21
	    // http://es5.github.com/#x15.4.4.21
	    // https://developer.mozilla.org/en/Core_JavaScript_1.5_Reference/Objects/Array/reduce
	    var reduceCoercesToObject = false;
	    if (ArrayPrototype.reduce) {
	        reduceCoercesToObject = typeof ArrayPrototype.reduce.call('es5', function (_, __, ___, list) {
	            return list;
	        }) === 'object';
	    }
	    defineProperties(ArrayPrototype, {
	        reduce: function reduce(callbackfn/*, initialValue*/) {
	            var object = ES.ToObject(this);
	            var self = splitString && isString(this) ? strSplit(this, '') : object;
	            var length = ES.ToUint32(self.length);
	
	            // If no callback function or if callback is not a callable function
	            if (!isCallable(callbackfn)) {
	                throw new TypeError('Array.prototype.reduce callback must be a function');
	            }
	
	            // no value to return if no initial value and an empty array
	            if (length === 0 && arguments.length === 1) {
	                throw new TypeError('reduce of empty array with no initial value');
	            }
	
	            var i = 0;
	            var result;
	            if (arguments.length >= 2) {
	                result = arguments[1];
	            } else {
	                do {
	                    if (i in self) {
	                        result = self[i++];
	                        break;
	                    }
	
	                    // if array contains no values, no initial value to return
	                    if (++i >= length) {
	                        throw new TypeError('reduce of empty array with no initial value');
	                    }
	                } while (true);
	            }
	
	            for (; i < length; i++) {
	                if (i in self) {
	                    result = callbackfn(result, self[i], i, object);
	                }
	            }
	
	            return result;
	        }
	    }, !reduceCoercesToObject);
	
	    // ES5 15.4.4.22
	    // http://es5.github.com/#x15.4.4.22
	    // https://developer.mozilla.org/en/Core_JavaScript_1.5_Reference/Objects/Array/reduceRight
	    var reduceRightCoercesToObject = false;
	    if (ArrayPrototype.reduceRight) {
	        reduceRightCoercesToObject = typeof ArrayPrototype.reduceRight.call('es5', function (_, __, ___, list) {
	            return list;
	        }) === 'object';
	    }
	    defineProperties(ArrayPrototype, {
	        reduceRight: function reduceRight(callbackfn/*, initial*/) {
	            var object = ES.ToObject(this);
	            var self = splitString && isString(this) ? strSplit(this, '') : object;
	            var length = ES.ToUint32(self.length);
	
	            // If no callback function or if callback is not a callable function
	            if (!isCallable(callbackfn)) {
	                throw new TypeError('Array.prototype.reduceRight callback must be a function');
	            }
	
	            // no value to return if no initial value, empty array
	            if (length === 0 && arguments.length === 1) {
	                throw new TypeError('reduceRight of empty array with no initial value');
	            }
	
	            var result;
	            var i = length - 1;
	            if (arguments.length >= 2) {
	                result = arguments[1];
	            } else {
	                do {
	                    if (i in self) {
	                        result = self[i--];
	                        break;
	                    }
	
	                    // if array contains no values, no initial value to return
	                    if (--i < 0) {
	                        throw new TypeError('reduceRight of empty array with no initial value');
	                    }
	                } while (true);
	            }
	
	            if (i < 0) {
	                return result;
	            }
	
	            do {
	                if (i in self) {
	                    result = callbackfn(result, self[i], i, object);
	                }
	            } while (i--);
	
	            return result;
	        }
	    }, !reduceRightCoercesToObject);
	
	    // ES5 15.4.4.14
	    // http://es5.github.com/#x15.4.4.14
	    // https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/indexOf
	    var hasFirefox2IndexOfBug = ArrayPrototype.indexOf && [0, 1].indexOf(1, 2) !== -1;
	    defineProperties(ArrayPrototype, {
	        indexOf: function indexOf(searchElement/*, fromIndex */) {
	            var self = splitString && isString(this) ? strSplit(this, '') : ES.ToObject(this);
	            var length = ES.ToUint32(self.length);
	
	            if (length === 0) {
	                return -1;
	            }
	
	            var i = 0;
	            if (arguments.length > 1) {
	                i = ES.ToInteger(arguments[1]);
	            }
	
	            // handle negative indices
	            i = i >= 0 ? i : max(0, length + i);
	            for (; i < length; i++) {
	                if (i in self && self[i] === searchElement) {
	                    return i;
	                }
	            }
	            return -1;
	        }
	    }, hasFirefox2IndexOfBug);
	
	    // ES5 15.4.4.15
	    // http://es5.github.com/#x15.4.4.15
	    // https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/lastIndexOf
	    var hasFirefox2LastIndexOfBug = ArrayPrototype.lastIndexOf && [0, 1].lastIndexOf(0, -3) !== -1;
	    defineProperties(ArrayPrototype, {
	        lastIndexOf: function lastIndexOf(searchElement/*, fromIndex */) {
	            var self = splitString && isString(this) ? strSplit(this, '') : ES.ToObject(this);
	            var length = ES.ToUint32(self.length);
	
	            if (length === 0) {
	                return -1;
	            }
	            var i = length - 1;
	            if (arguments.length > 1) {
	                i = min(i, ES.ToInteger(arguments[1]));
	            }
	            // handle negative indices
	            i = i >= 0 ? i : length - Math.abs(i);
	            for (; i >= 0; i--) {
	                if (i in self && searchElement === self[i]) {
	                    return i;
	                }
	            }
	            return -1;
	        }
	    }, hasFirefox2LastIndexOfBug);
	
	    // ES5 15.4.4.12
	    // http://es5.github.com/#x15.4.4.12
	    var spliceNoopReturnsEmptyArray = (function () {
	        var a = [1, 2];
	        var result = a.splice();
	        return a.length === 2 && isArray(result) && result.length === 0;
	    }());
	    defineProperties(ArrayPrototype, {
	        // Safari 5.0 bug where .splice() returns undefined
	        splice: function splice(start, deleteCount) {
	            if (arguments.length === 0) {
	                return [];
	            } else {
	                return array_splice.apply(this, arguments);
	            }
	        }
	    }, !spliceNoopReturnsEmptyArray);
	
	    var spliceWorksWithEmptyObject = (function () {
	        var obj = {};
	        ArrayPrototype.splice.call(obj, 0, 0, 1);
	        return obj.length === 1;
	    }());
	    defineProperties(ArrayPrototype, {
	        splice: function splice(start, deleteCount) {
	            if (arguments.length === 0) {
	                return [];
	            }
	            var args = arguments;
	            this.length = max(ES.ToInteger(this.length), 0);
	            if (arguments.length > 0 && typeof deleteCount !== 'number') {
	                args = arraySlice(arguments);
	                if (args.length < 2) {
	                    pushCall(args, this.length - start);
	                } else {
	                    args[1] = ES.ToInteger(deleteCount);
	                }
	            }
	            return array_splice.apply(this, args);
	        }
	    }, !spliceWorksWithEmptyObject);
	    var spliceWorksWithLargeSparseArrays = (function () {
	        // Per https://github.com/es-shims/es5-shim/issues/295
	        // Safari 7/8 breaks with sparse arrays of size 1e5 or greater
	        var arr = new $Array(1e5);
	        // note: the index MUST be 8 or larger or the test will false pass
	        arr[8] = 'x';
	        arr.splice(1, 1);
	        // note: this test must be defined *after* the indexOf shim
	        // per https://github.com/es-shims/es5-shim/issues/313
	        return arr.indexOf('x') === 7;
	    }());
	    var spliceWorksWithSmallSparseArrays = (function () {
	        // Per https://github.com/es-shims/es5-shim/issues/295
	        // Opera 12.15 breaks on this, no idea why.
	        var n = 256;
	        var arr = [];
	        arr[n] = 'a';
	        arr.splice(n + 1, 0, 'b');
	        return arr[n] === 'a';
	    }());
	    defineProperties(ArrayPrototype, {
	        splice: function splice(start, deleteCount) {
	            var O = ES.ToObject(this);
	            var A = [];
	            var len = ES.ToUint32(O.length);
	            var relativeStart = ES.ToInteger(start);
	            var actualStart = relativeStart < 0 ? max((len + relativeStart), 0) : min(relativeStart, len);
	            var actualDeleteCount = min(max(ES.ToInteger(deleteCount), 0), len - actualStart);
	
	            var k = 0;
	            var from;
	            while (k < actualDeleteCount) {
	                from = $String(actualStart + k);
	                if (owns(O, from)) {
	                    A[k] = O[from];
	                }
	                k += 1;
	            }
	
	            var items = arraySlice(arguments, 2);
	            var itemCount = items.length;
	            var to;
	            if (itemCount < actualDeleteCount) {
	                k = actualStart;
	                var maxK = len - actualDeleteCount;
	                while (k < maxK) {
	                    from = $String(k + actualDeleteCount);
	                    to = $String(k + itemCount);
	                    if (owns(O, from)) {
	                        O[to] = O[from];
	                    } else {
	                        delete O[to];
	                    }
	                    k += 1;
	                }
	                k = len;
	                var minK = len - actualDeleteCount + itemCount;
	                while (k > minK) {
	                    delete O[k - 1];
	                    k -= 1;
	                }
	            } else if (itemCount > actualDeleteCount) {
	                k = len - actualDeleteCount;
	                while (k > actualStart) {
	                    from = $String(k + actualDeleteCount - 1);
	                    to = $String(k + itemCount - 1);
	                    if (owns(O, from)) {
	                        O[to] = O[from];
	                    } else {
	                        delete O[to];
	                    }
	                    k -= 1;
	                }
	            }
	            k = actualStart;
	            for (var i = 0; i < items.length; ++i) {
	                O[k] = items[i];
	                k += 1;
	            }
	            O.length = len - actualDeleteCount + itemCount;
	
	            return A;
	        }
	    }, !spliceWorksWithLargeSparseArrays || !spliceWorksWithSmallSparseArrays);
	
	    var originalJoin = ArrayPrototype.join;
	    var hasStringJoinBug;
	    try {
	        hasStringJoinBug = Array.prototype.join.call('123', ',') !== '1,2,3';
	    } catch (e) {
	        hasStringJoinBug = true;
	    }
	    if (hasStringJoinBug) {
	        defineProperties(ArrayPrototype, {
	            join: function join(separator) {
	                var sep = typeof separator === 'undefined' ? ',' : separator;
	                return originalJoin.call(isString(this) ? strSplit(this, '') : this, sep);
	            }
	        }, hasStringJoinBug);
	    }
	
	    var hasJoinUndefinedBug = [1, 2].join(undefined) !== '1,2';
	    if (hasJoinUndefinedBug) {
	        defineProperties(ArrayPrototype, {
	            join: function join(separator) {
	                var sep = typeof separator === 'undefined' ? ',' : separator;
	                return originalJoin.call(this, sep);
	            }
	        }, hasJoinUndefinedBug);
	    }
	
	    var pushShim = function push(item) {
	        var O = ES.ToObject(this);
	        var n = ES.ToUint32(O.length);
	        var i = 0;
	        while (i < arguments.length) {
	            O[n + i] = arguments[i];
	            i += 1;
	        }
	        O.length = n + i;
	        return n + i;
	    };
	
	    var pushIsNotGeneric = (function () {
	        var obj = {};
	        var result = Array.prototype.push.call(obj, undefined);
	        return result !== 1 || obj.length !== 1 || typeof obj[0] !== 'undefined' || !owns(obj, 0);
	    }());
	    defineProperties(ArrayPrototype, {
	        push: function push(item) {
	            if (isArray(this)) {
	                return array_push.apply(this, arguments);
	            }
	            return pushShim.apply(this, arguments);
	        }
	    }, pushIsNotGeneric);
	
	    // This fixes a very weird bug in Opera 10.6 when pushing `undefined
	    var pushUndefinedIsWeird = (function () {
	        var arr = [];
	        var result = arr.push(undefined);
	        return result !== 1 || arr.length !== 1 || typeof arr[0] !== 'undefined' || !owns(arr, 0);
	    }());
	    defineProperties(ArrayPrototype, { push: pushShim }, pushUndefinedIsWeird);
	
	    // ES5 15.2.3.14
	    // http://es5.github.io/#x15.4.4.10
	    // Fix boxed string bug
	    defineProperties(ArrayPrototype, {
	        slice: function (start, end) {
	            var arr = isString(this) ? strSplit(this, '') : this;
	            return arraySliceApply(arr, arguments);
	        }
	    }, splitString);
	
	    var sortIgnoresNonFunctions = (function () {
	        try {
	            [1, 2].sort(null);
	            [1, 2].sort({});
	            return true;
	        } catch (e) {}
	        return false;
	    }());
	    var sortThrowsOnRegex = (function () {
	        // this is a problem in Firefox 4, in which `typeof /a/ === 'function'`
	        try {
	            [1, 2].sort(/a/);
	            return false;
	        } catch (e) {}
	        return true;
	    }());
	    var sortIgnoresUndefined = (function () {
	        // applies in IE 8, for one.
	        try {
	            [1, 2].sort(undefined);
	            return true;
	        } catch (e) {}
	        return false;
	    }());
	    defineProperties(ArrayPrototype, {
	        sort: function sort(compareFn) {
	            if (typeof compareFn === 'undefined') {
	                return arraySort(this);
	            }
	            if (!isCallable(compareFn)) {
	                throw new TypeError('Array.prototype.sort callback must be a function');
	            }
	            return arraySort(this, compareFn);
	        }
	    }, sortIgnoresNonFunctions || !sortIgnoresUndefined || !sortThrowsOnRegex);
	
	    //
	    // Object
	    // ======
	    //
	
	    // ES5 15.2.3.14
	    // http://es5.github.com/#x15.2.3.14
	
	    // http://whattheheadsaid.com/2010/10/a-safer-object-keys-compatibility-implementation
	    var hasDontEnumBug = !isEnum({ 'toString': null }, 'toString');
	    var hasProtoEnumBug = isEnum(function () {}, 'prototype');
	    var hasStringEnumBug = !owns('x', '0');
	    var equalsConstructorPrototype = function (o) {
	        var ctor = o.constructor;
	        return ctor && ctor.prototype === o;
	    };
	    var excludedKeys = {
	        $window: true,
	        $console: true,
	        $parent: true,
	        $self: true,
	        $frame: true,
	        $frames: true,
	        $frameElement: true,
	        $webkitIndexedDB: true,
	        $webkitStorageInfo: true,
	        $external: true,
	        $width: true,
	        $height: true
	    };
	    var hasAutomationEqualityBug = (function () {
	        /* globals window */
	        if (typeof window === 'undefined') {
	            return false;
	        }
	        for (var k in window) {
	            try {
	                if (!excludedKeys['$' + k] && owns(window, k) && window[k] !== null && typeof window[k] === 'object') {
	                    equalsConstructorPrototype(window[k]);
	                }
	            } catch (e) {
	                return true;
	            }
	        }
	        return false;
	    }());
	    var equalsConstructorPrototypeIfNotBuggy = function (object) {
	        if (typeof window === 'undefined' || !hasAutomationEqualityBug) {
	            return equalsConstructorPrototype(object);
	        }
	        try {
	            return equalsConstructorPrototype(object);
	        } catch (e) {
	            return false;
	        }
	    };
	    var dontEnums = [
	        'toString',
	        'toLocaleString',
	        'valueOf',
	        'hasOwnProperty',
	        'isPrototypeOf',
	        'propertyIsEnumerable',
	        'constructor'
	    ];
	    var dontEnumsLength = dontEnums.length;
	
	    // taken directly from https://github.com/ljharb/is-arguments/blob/master/index.js
	    // can be replaced with require('is-arguments') if we ever use a build process instead
	    var isStandardArguments = function isArguments(value) {
	        return toStr(value) === '[object Arguments]';
	    };
	    var isLegacyArguments = function isArguments(value) {
	        return value !== null &&
	            typeof value === 'object' &&
	            typeof value.length === 'number' &&
	            value.length >= 0 &&
	            !isArray(value) &&
	            isCallable(value.callee);
	    };
	    var isArguments = isStandardArguments(arguments) ? isStandardArguments : isLegacyArguments;
	
	    defineProperties($Object, {
	        keys: function keys(object) {
	            var isFn = isCallable(object);
	            var isArgs = isArguments(object);
	            var isObject = object !== null && typeof object === 'object';
	            var isStr = isObject && isString(object);
	
	            if (!isObject && !isFn && !isArgs) {
	                throw new TypeError('Object.keys called on a non-object');
	            }
	
	            var theKeys = [];
	            var skipProto = hasProtoEnumBug && isFn;
	            if ((isStr && hasStringEnumBug) || isArgs) {
	                for (var i = 0; i < object.length; ++i) {
	                    pushCall(theKeys, $String(i));
	                }
	            }
	
	            if (!isArgs) {
	                for (var name in object) {
	                    if (!(skipProto && name === 'prototype') && owns(object, name)) {
	                        pushCall(theKeys, $String(name));
	                    }
	                }
	            }
	
	            if (hasDontEnumBug) {
	                var skipConstructor = equalsConstructorPrototypeIfNotBuggy(object);
	                for (var j = 0; j < dontEnumsLength; j++) {
	                    var dontEnum = dontEnums[j];
	                    if (!(skipConstructor && dontEnum === 'constructor') && owns(object, dontEnum)) {
	                        pushCall(theKeys, dontEnum);
	                    }
	                }
	            }
	            return theKeys;
	        }
	    });
	
	    var keysWorksWithArguments = $Object.keys && (function () {
	        // Safari 5.0 bug
	        return $Object.keys(arguments).length === 2;
	    }(1, 2));
	    var keysHasArgumentsLengthBug = $Object.keys && (function () {
	        var argKeys = $Object.keys(arguments);
	        return arguments.length !== 1 || argKeys.length !== 1 || argKeys[0] !== 1;
	    }(1));
	    var originalKeys = $Object.keys;
	    defineProperties($Object, {
	        keys: function keys(object) {
	            if (isArguments(object)) {
	                return originalKeys(arraySlice(object));
	            } else {
	                return originalKeys(object);
	            }
	        }
	    }, !keysWorksWithArguments || keysHasArgumentsLengthBug);
	
	    //
	    // Date
	    // ====
	    //
	
	    var hasNegativeMonthYearBug = new Date(-3509827329600292).getUTCMonth() !== 0;
	    var aNegativeTestDate = new Date(-1509842289600292);
	    var aPositiveTestDate = new Date(1449662400000);
	    var hasToUTCStringFormatBug = aNegativeTestDate.toUTCString() !== 'Mon, 01 Jan -45875 11:59:59 GMT';
	    var hasToDateStringFormatBug;
	    var hasToStringFormatBug;
	    var timeZoneOffset = aNegativeTestDate.getTimezoneOffset();
	    if (timeZoneOffset < -720) {
	        hasToDateStringFormatBug = aNegativeTestDate.toDateString() !== 'Tue Jan 02 -45875';
	        hasToStringFormatBug = !(/^Thu Dec 10 2015 \d\d:\d\d:\d\d GMT[-\+]\d\d\d\d(?: |$)/).test(aPositiveTestDate.toString());
	    } else {
	        hasToDateStringFormatBug = aNegativeTestDate.toDateString() !== 'Mon Jan 01 -45875';
	        hasToStringFormatBug = !(/^Wed Dec 09 2015 \d\d:\d\d:\d\d GMT[-\+]\d\d\d\d(?: |$)/).test(aPositiveTestDate.toString());
	    }
	
	    var originalGetFullYear = call.bind(Date.prototype.getFullYear);
	    var originalGetMonth = call.bind(Date.prototype.getMonth);
	    var originalGetDate = call.bind(Date.prototype.getDate);
	    var originalGetUTCFullYear = call.bind(Date.prototype.getUTCFullYear);
	    var originalGetUTCMonth = call.bind(Date.prototype.getUTCMonth);
	    var originalGetUTCDate = call.bind(Date.prototype.getUTCDate);
	    var originalGetUTCDay = call.bind(Date.prototype.getUTCDay);
	    var originalGetUTCHours = call.bind(Date.prototype.getUTCHours);
	    var originalGetUTCMinutes = call.bind(Date.prototype.getUTCMinutes);
	    var originalGetUTCSeconds = call.bind(Date.prototype.getUTCSeconds);
	    var originalGetUTCMilliseconds = call.bind(Date.prototype.getUTCMilliseconds);
	    var dayName = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
	    var monthName = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	    var daysInMonth = function daysInMonth(month, year) {
	        return originalGetDate(new Date(year, month, 0));
	    };
	
	    defineProperties(Date.prototype, {
	        getFullYear: function getFullYear() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var year = originalGetFullYear(this);
	            if (year < 0 && originalGetMonth(this) > 11) {
	                return year + 1;
	            }
	            return year;
	        },
	        getMonth: function getMonth() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var year = originalGetFullYear(this);
	            var month = originalGetMonth(this);
	            if (year < 0 && month > 11) {
	                return 0;
	            }
	            return month;
	        },
	        getDate: function getDate() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var year = originalGetFullYear(this);
	            var month = originalGetMonth(this);
	            var date = originalGetDate(this);
	            if (year < 0 && month > 11) {
	                if (month === 12) {
	                    return date;
	                }
	                var days = daysInMonth(0, year + 1);
	                return (days - date) + 1;
	            }
	            return date;
	        },
	        getUTCFullYear: function getUTCFullYear() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var year = originalGetUTCFullYear(this);
	            if (year < 0 && originalGetUTCMonth(this) > 11) {
	                return year + 1;
	            }
	            return year;
	        },
	        getUTCMonth: function getUTCMonth() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var year = originalGetUTCFullYear(this);
	            var month = originalGetUTCMonth(this);
	            if (year < 0 && month > 11) {
	                return 0;
	            }
	            return month;
	        },
	        getUTCDate: function getUTCDate() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var year = originalGetUTCFullYear(this);
	            var month = originalGetUTCMonth(this);
	            var date = originalGetUTCDate(this);
	            if (year < 0 && month > 11) {
	                if (month === 12) {
	                    return date;
	                }
	                var days = daysInMonth(0, year + 1);
	                return (days - date) + 1;
	            }
	            return date;
	        }
	    }, hasNegativeMonthYearBug);
	
	    defineProperties(Date.prototype, {
	        toUTCString: function toUTCString() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var day = originalGetUTCDay(this);
	            var date = originalGetUTCDate(this);
	            var month = originalGetUTCMonth(this);
	            var year = originalGetUTCFullYear(this);
	            var hour = originalGetUTCHours(this);
	            var minute = originalGetUTCMinutes(this);
	            var second = originalGetUTCSeconds(this);
	            return dayName[day] + ', ' +
	                (date < 10 ? '0' + date : date) + ' ' +
	                monthName[month] + ' ' +
	                year + ' ' +
	                (hour < 10 ? '0' + hour : hour) + ':' +
	                (minute < 10 ? '0' + minute : minute) + ':' +
	                (second < 10 ? '0' + second : second) + ' GMT';
	        }
	    }, hasNegativeMonthYearBug || hasToUTCStringFormatBug);
	
	    // Opera 12 has `,`
	    defineProperties(Date.prototype, {
	        toDateString: function toDateString() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var day = this.getDay();
	            var date = this.getDate();
	            var month = this.getMonth();
	            var year = this.getFullYear();
	            return dayName[day] + ' ' +
	                monthName[month] + ' ' +
	                (date < 10 ? '0' + date : date) + ' ' +
	                year;
	        }
	    }, hasNegativeMonthYearBug || hasToDateStringFormatBug);
	
	    // can't use defineProperties here because of toString enumeration issue in IE <= 8
	    if (hasNegativeMonthYearBug || hasToStringFormatBug) {
	        Date.prototype.toString = function toString() {
	            if (!this || !(this instanceof Date)) {
	                throw new TypeError('this is not a Date object.');
	            }
	            var day = this.getDay();
	            var date = this.getDate();
	            var month = this.getMonth();
	            var year = this.getFullYear();
	            var hour = this.getHours();
	            var minute = this.getMinutes();
	            var second = this.getSeconds();
	            var timezoneOffset = this.getTimezoneOffset();
	            var hoursOffset = Math.floor(Math.abs(timezoneOffset) / 60);
	            var minutesOffset = Math.floor(Math.abs(timezoneOffset) % 60);
	            return dayName[day] + ' ' +
	                monthName[month] + ' ' +
	                (date < 10 ? '0' + date : date) + ' ' +
	                year + ' ' +
	                (hour < 10 ? '0' + hour : hour) + ':' +
	                (minute < 10 ? '0' + minute : minute) + ':' +
	                (second < 10 ? '0' + second : second) + ' GMT' +
	                (timezoneOffset > 0 ? '-' : '+') +
	                (hoursOffset < 10 ? '0' + hoursOffset : hoursOffset) +
	                (minutesOffset < 10 ? '0' + minutesOffset : minutesOffset);
	        };
	        if (supportsDescriptors) {
	            $Object.defineProperty(Date.prototype, 'toString', {
	                configurable: true,
	                enumerable: false,
	                writable: true
	            });
	        }
	    }
	
	    // ES5 15.9.5.43
	    // http://es5.github.com/#x15.9.5.43
	    // This function returns a String value represent the instance in time
	    // represented by this Date object. The format of the String is the Date Time
	    // string format defined in 15.9.1.15. All fields are present in the String.
	    // The time zone is always UTC, denoted by the suffix Z. If the time value of
	    // this object is not a finite Number a RangeError exception is thrown.
	    var negativeDate = -62198755200000;
	    var negativeYearString = '-000001';
	    var hasNegativeDateBug = Date.prototype.toISOString && new Date(negativeDate).toISOString().indexOf(negativeYearString) === -1;
	    var hasSafari51DateBug = Date.prototype.toISOString && new Date(-1).toISOString() !== '1969-12-31T23:59:59.999Z';
	
	    var getTime = call.bind(Date.prototype.getTime);
	
	    defineProperties(Date.prototype, {
	        toISOString: function toISOString() {
	            if (!isFinite(this) || !isFinite(getTime(this))) {
	                // Adope Photoshop requires the second check.
	                throw new RangeError('Date.prototype.toISOString called on non-finite value.');
	            }
	
	            var year = originalGetUTCFullYear(this);
	
	            var month = originalGetUTCMonth(this);
	            // see https://github.com/es-shims/es5-shim/issues/111
	            year += Math.floor(month / 12);
	            month = ((month % 12) + 12) % 12;
	
	            // the date time string format is specified in 15.9.1.15.
	            var result = [month + 1, originalGetUTCDate(this), originalGetUTCHours(this), originalGetUTCMinutes(this), originalGetUTCSeconds(this)];
	            year = (
	                (year < 0 ? '-' : (year > 9999 ? '+' : '')) +
	                strSlice('00000' + Math.abs(year), (0 <= year && year <= 9999) ? -4 : -6)
	            );
	
	            for (var i = 0; i < result.length; ++i) {
	                // pad months, days, hours, minutes, and seconds to have two digits.
	                result[i] = strSlice('00' + result[i], -2);
	            }
	            // pad milliseconds to have three digits.
	            return (
	                year + '-' + arraySlice(result, 0, 2).join('-') +
	                'T' + arraySlice(result, 2).join(':') + '.' +
	                strSlice('000' + originalGetUTCMilliseconds(this), -3) + 'Z'
	            );
	        }
	    }, hasNegativeDateBug || hasSafari51DateBug);
	
	    // ES5 15.9.5.44
	    // http://es5.github.com/#x15.9.5.44
	    // This function provides a String representation of a Date object for use by
	    // JSON.stringify (15.12.3).
	    var dateToJSONIsSupported = (function () {
	        try {
	            return Date.prototype.toJSON &&
	                new Date(NaN).toJSON() === null &&
	                new Date(negativeDate).toJSON().indexOf(negativeYearString) !== -1 &&
	                Date.prototype.toJSON.call({ // generic
	                    toISOString: function () { return true; }
	                });
	        } catch (e) {
	            return false;
	        }
	    }());
	    if (!dateToJSONIsSupported) {
	        Date.prototype.toJSON = function toJSON(key) {
	            // When the toJSON method is called with argument key, the following
	            // steps are taken:
	
	            // 1.  Let O be the result of calling ToObject, giving it the this
	            // value as its argument.
	            // 2. Let tv be ES.ToPrimitive(O, hint Number).
	            var O = $Object(this);
	            var tv = ES.ToPrimitive(O);
	            // 3. If tv is a Number and is not finite, return null.
	            if (typeof tv === 'number' && !isFinite(tv)) {
	                return null;
	            }
	            // 4. Let toISO be the result of calling the [[Get]] internal method of
	            // O with argument "toISOString".
	            var toISO = O.toISOString;
	            // 5. If IsCallable(toISO) is false, throw a TypeError exception.
	            if (!isCallable(toISO)) {
	                throw new TypeError('toISOString property is not callable');
	            }
	            // 6. Return the result of calling the [[Call]] internal method of
	            //  toISO with O as the this value and an empty argument list.
	            return toISO.call(O);
	
	            // NOTE 1 The argument is ignored.
	
	            // NOTE 2 The toJSON function is intentionally generic; it does not
	            // require that its this value be a Date object. Therefore, it can be
	            // transferred to other kinds of objects for use as a method. However,
	            // it does require that any such object have a toISOString method. An
	            // object is free to use the argument key to filter its
	            // stringification.
	        };
	    }
	
	    // ES5 15.9.4.2
	    // http://es5.github.com/#x15.9.4.2
	    // based on work shared by Daniel Friesen (dantman)
	    // http://gist.github.com/303249
	    var supportsExtendedYears = Date.parse('+033658-09-27T01:46:40.000Z') === 1e15;
	    var acceptsInvalidDates = !isNaN(Date.parse('2012-04-04T24:00:00.500Z')) || !isNaN(Date.parse('2012-11-31T23:59:59.000Z')) || !isNaN(Date.parse('2012-12-31T23:59:60.000Z'));
	    var doesNotParseY2KNewYear = isNaN(Date.parse('2000-01-01T00:00:00.000Z'));
	    if (doesNotParseY2KNewYear || acceptsInvalidDates || !supportsExtendedYears) {
	        // XXX global assignment won't work in embeddings that use
	        // an alternate object for the context.
	        /* global Date: true */
	        /* eslint-disable no-undef */
	        var maxSafeUnsigned32Bit = Math.pow(2, 31) - 1;
	        var hasSafariSignedIntBug = isActualNaN(new Date(1970, 0, 1, 0, 0, 0, maxSafeUnsigned32Bit + 1).getTime());
	        /* eslint-disable no-implicit-globals */
	        Date = (function (NativeDate) {
	        /* eslint-enable no-implicit-globals */
	        /* eslint-enable no-undef */
	            // Date.length === 7
	            var DateShim = function Date(Y, M, D, h, m, s, ms) {
	                var length = arguments.length;
	                var date;
	                if (this instanceof NativeDate) {
	                    var seconds = s;
	                    var millis = ms;
	                    if (hasSafariSignedIntBug && length >= 7 && ms > maxSafeUnsigned32Bit) {
	                        // work around a Safari 8/9 bug where it treats the seconds as signed
	                        var msToShift = Math.floor(ms / maxSafeUnsigned32Bit) * maxSafeUnsigned32Bit;
	                        var sToShift = Math.floor(msToShift / 1e3);
	                        seconds += sToShift;
	                        millis -= sToShift * 1e3;
	                    }
	                    date = length === 1 && $String(Y) === Y ? // isString(Y)
	                        // We explicitly pass it through parse:
	                        new NativeDate(DateShim.parse(Y)) :
	                        // We have to manually make calls depending on argument
	                        // length here
	                        length >= 7 ? new NativeDate(Y, M, D, h, m, seconds, millis) :
	                        length >= 6 ? new NativeDate(Y, M, D, h, m, seconds) :
	                        length >= 5 ? new NativeDate(Y, M, D, h, m) :
	                        length >= 4 ? new NativeDate(Y, M, D, h) :
	                        length >= 3 ? new NativeDate(Y, M, D) :
	                        length >= 2 ? new NativeDate(Y, M) :
	                        length >= 1 ? new NativeDate(Y instanceof NativeDate ? +Y : Y) :
	                                      new NativeDate();
	                } else {
	                    date = NativeDate.apply(this, arguments);
	                }
	                if (!isPrimitive(date)) {
	                    // Prevent mixups with unfixed Date object
	                    defineProperties(date, { constructor: DateShim }, true);
	                }
	                return date;
	            };
	
	            // 15.9.1.15 Date Time String Format.
	            var isoDateExpression = new RegExp('^' +
	                '(\\d{4}|[+-]\\d{6})' + // four-digit year capture or sign +
	                                          // 6-digit extended year
	                '(?:-(\\d{2})' + // optional month capture
	                '(?:-(\\d{2})' + // optional day capture
	                '(?:' + // capture hours:minutes:seconds.milliseconds
	                    'T(\\d{2})' + // hours capture
	                    ':(\\d{2})' + // minutes capture
	                    '(?:' + // optional :seconds.milliseconds
	                        ':(\\d{2})' + // seconds capture
	                        '(?:(\\.\\d{1,}))?' + // milliseconds capture
	                    ')?' +
	                '(' + // capture UTC offset component
	                    'Z|' + // UTC capture
	                    '(?:' + // offset specifier +/-hours:minutes
	                        '([-+])' + // sign capture
	                        '(\\d{2})' + // hours offset capture
	                        ':(\\d{2})' + // minutes offset capture
	                    ')' +
	                ')?)?)?)?' +
	            '$');
	
	            var months = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365];
	
	            var dayFromMonth = function dayFromMonth(year, month) {
	                var t = month > 1 ? 1 : 0;
	                return (
	                    months[month] +
	                    Math.floor((year - 1969 + t) / 4) -
	                    Math.floor((year - 1901 + t) / 100) +
	                    Math.floor((year - 1601 + t) / 400) +
	                    (365 * (year - 1970))
	                );
	            };
	
	            var toUTC = function toUTC(t) {
	                var s = 0;
	                var ms = t;
	                if (hasSafariSignedIntBug && ms > maxSafeUnsigned32Bit) {
	                    // work around a Safari 8/9 bug where it treats the seconds as signed
	                    var msToShift = Math.floor(ms / maxSafeUnsigned32Bit) * maxSafeUnsigned32Bit;
	                    var sToShift = Math.floor(msToShift / 1e3);
	                    s += sToShift;
	                    ms -= sToShift * 1e3;
	                }
	                return $Number(new NativeDate(1970, 0, 1, 0, 0, s, ms));
	            };
	
	            // Copy any custom methods a 3rd party library may have added
	            for (var key in NativeDate) {
	                if (owns(NativeDate, key)) {
	                    DateShim[key] = NativeDate[key];
	                }
	            }
	
	            // Copy "native" methods explicitly; they may be non-enumerable
	            defineProperties(DateShim, {
	                now: NativeDate.now,
	                UTC: NativeDate.UTC
	            }, true);
	            DateShim.prototype = NativeDate.prototype;
	            defineProperties(DateShim.prototype, { constructor: DateShim }, true);
	
	            // Upgrade Date.parse to handle simplified ISO 8601 strings
	            var parseShim = function parse(string) {
	                var match = isoDateExpression.exec(string);
	                if (match) {
	                    // parse months, days, hours, minutes, seconds, and milliseconds
	                    // provide default values if necessary
	                    // parse the UTC offset component
	                    var year = $Number(match[1]),
	                        month = $Number(match[2] || 1) - 1,
	                        day = $Number(match[3] || 1) - 1,
	                        hour = $Number(match[4] || 0),
	                        minute = $Number(match[5] || 0),
	                        second = $Number(match[6] || 0),
	                        millisecond = Math.floor($Number(match[7] || 0) * 1000),
	                        // When time zone is missed, local offset should be used
	                        // (ES 5.1 bug)
	                        // see https://bugs.ecmascript.org/show_bug.cgi?id=112
	                        isLocalTime = Boolean(match[4] && !match[8]),
	                        signOffset = match[9] === '-' ? 1 : -1,
	                        hourOffset = $Number(match[10] || 0),
	                        minuteOffset = $Number(match[11] || 0),
	                        result;
	                    var hasMinutesOrSecondsOrMilliseconds = minute > 0 || second > 0 || millisecond > 0;
	                    if (
	                        hour < (hasMinutesOrSecondsOrMilliseconds ? 24 : 25) &&
	                        minute < 60 && second < 60 && millisecond < 1000 &&
	                        month > -1 && month < 12 && hourOffset < 24 &&
	                        minuteOffset < 60 && // detect invalid offsets
	                        day > -1 &&
	                        day < (dayFromMonth(year, month + 1) - dayFromMonth(year, month))
	                    ) {
	                        result = (
	                            ((dayFromMonth(year, month) + day) * 24) +
	                            hour +
	                            (hourOffset * signOffset)
	                        ) * 60;
	                        result = ((
	                            ((result + minute + (minuteOffset * signOffset)) * 60) +
	                            second
	                        ) * 1000) + millisecond;
	                        if (isLocalTime) {
	                            result = toUTC(result);
	                        }
	                        if (-8.64e15 <= result && result <= 8.64e15) {
	                            return result;
	                        }
	                    }
	                    return NaN;
	                }
	                return NativeDate.parse.apply(this, arguments);
	            };
	            defineProperties(DateShim, { parse: parseShim });
	
	            return DateShim;
	        }(Date));
	        /* global Date: false */
	    }
	
	    // ES5 15.9.4.4
	    // http://es5.github.com/#x15.9.4.4
	    if (!Date.now) {
	        Date.now = function now() {
	            return new Date().getTime();
	        };
	    }
	
	    //
	    // Number
	    // ======
	    //
	
	    // ES5.1 15.7.4.5
	    // http://es5.github.com/#x15.7.4.5
	    var hasToFixedBugs = NumberPrototype.toFixed && (
	      (0.00008).toFixed(3) !== '0.000' ||
	      (0.9).toFixed(0) !== '1' ||
	      (1.255).toFixed(2) !== '1.25' ||
	      (1000000000000000128).toFixed(0) !== '1000000000000000128'
	    );
	
	    var toFixedHelpers = {
	        base: 1e7,
	        size: 6,
	        data: [0, 0, 0, 0, 0, 0],
	        multiply: function multiply(n, c) {
	            var i = -1;
	            var c2 = c;
	            while (++i < toFixedHelpers.size) {
	                c2 += n * toFixedHelpers.data[i];
	                toFixedHelpers.data[i] = c2 % toFixedHelpers.base;
	                c2 = Math.floor(c2 / toFixedHelpers.base);
	            }
	        },
	        divide: function divide(n) {
	            var i = toFixedHelpers.size;
	            var c = 0;
	            while (--i >= 0) {
	                c += toFixedHelpers.data[i];
	                toFixedHelpers.data[i] = Math.floor(c / n);
	                c = (c % n) * toFixedHelpers.base;
	            }
	        },
	        numToString: function numToString() {
	            var i = toFixedHelpers.size;
	            var s = '';
	            while (--i >= 0) {
	                if (s !== '' || i === 0 || toFixedHelpers.data[i] !== 0) {
	                    var t = $String(toFixedHelpers.data[i]);
	                    if (s === '') {
	                        s = t;
	                    } else {
	                        s += strSlice('0000000', 0, 7 - t.length) + t;
	                    }
	                }
	            }
	            return s;
	        },
	        pow: function pow(x, n, acc) {
	            return (n === 0 ? acc : (n % 2 === 1 ? pow(x, n - 1, acc * x) : pow(x * x, n / 2, acc)));
	        },
	        log: function log(x) {
	            var n = 0;
	            var x2 = x;
	            while (x2 >= 4096) {
	                n += 12;
	                x2 /= 4096;
	            }
	            while (x2 >= 2) {
	                n += 1;
	                x2 /= 2;
	            }
	            return n;
	        }
	    };
	
	    var toFixedShim = function toFixed(fractionDigits) {
	        var f, x, s, m, e, z, j, k;
	
	        // Test for NaN and round fractionDigits down
	        f = $Number(fractionDigits);
	        f = isActualNaN(f) ? 0 : Math.floor(f);
	
	        if (f < 0 || f > 20) {
	            throw new RangeError('Number.toFixed called with invalid number of decimals');
	        }
	
	        x = $Number(this);
	
	        if (isActualNaN(x)) {
	            return 'NaN';
	        }
	
	        // If it is too big or small, return the string value of the number
	        if (x <= -1e21 || x >= 1e21) {
	            return $String(x);
	        }
	
	        s = '';
	
	        if (x < 0) {
	            s = '-';
	            x = -x;
	        }
	
	        m = '0';
	
	        if (x > 1e-21) {
	            // 1e-21 < x < 1e21
	            // -70 < log2(x) < 70
	            e = toFixedHelpers.log(x * toFixedHelpers.pow(2, 69, 1)) - 69;
	            z = (e < 0 ? x * toFixedHelpers.pow(2, -e, 1) : x / toFixedHelpers.pow(2, e, 1));
	            z *= 0x10000000000000; // Math.pow(2, 52);
	            e = 52 - e;
	
	            // -18 < e < 122
	            // x = z / 2 ^ e
	            if (e > 0) {
	                toFixedHelpers.multiply(0, z);
	                j = f;
	
	                while (j >= 7) {
	                    toFixedHelpers.multiply(1e7, 0);
	                    j -= 7;
	                }
	
	                toFixedHelpers.multiply(toFixedHelpers.pow(10, j, 1), 0);
	                j = e - 1;
	
	                while (j >= 23) {
	                    toFixedHelpers.divide(1 << 23);
	                    j -= 23;
	                }
	
	                toFixedHelpers.divide(1 << j);
	                toFixedHelpers.multiply(1, 1);
	                toFixedHelpers.divide(2);
	                m = toFixedHelpers.numToString();
	            } else {
	                toFixedHelpers.multiply(0, z);
	                toFixedHelpers.multiply(1 << (-e), 0);
	                m = toFixedHelpers.numToString() + strSlice('0.00000000000000000000', 2, 2 + f);
	            }
	        }
	
	        if (f > 0) {
	            k = m.length;
	
	            if (k <= f) {
	                m = s + strSlice('0.0000000000000000000', 0, f - k + 2) + m;
	            } else {
	                m = s + strSlice(m, 0, k - f) + '.' + strSlice(m, k - f);
	            }
	        } else {
	            m = s + m;
	        }
	
	        return m;
	    };
	    defineProperties(NumberPrototype, { toFixed: toFixedShim }, hasToFixedBugs);
	
	    var hasToPrecisionUndefinedBug = (function () {
	        try {
	            return 1.0.toPrecision(undefined) === '1';
	        } catch (e) {
	            return true;
	        }
	    }());
	    var originalToPrecision = NumberPrototype.toPrecision;
	    defineProperties(NumberPrototype, {
	        toPrecision: function toPrecision(precision) {
	            return typeof precision === 'undefined' ? originalToPrecision.call(this) : originalToPrecision.call(this, precision);
	        }
	    }, hasToPrecisionUndefinedBug);
	
	    //
	    // String
	    // ======
	    //
	
	    // ES5 15.5.4.14
	    // http://es5.github.com/#x15.5.4.14
	
	    // [bugfix, IE lt 9, firefox 4, Konqueror, Opera, obscure browsers]
	    // Many browsers do not split properly with regular expressions or they
	    // do not perform the split correctly under obscure conditions.
	    // See http://blog.stevenlevithan.com/archives/cross-browser-split
	    // I've tested in many browsers and this seems to cover the deviant ones:
	    //    'ab'.split(/(?:ab)*/) should be ["", ""], not [""]
	    //    '.'.split(/(.?)(.?)/) should be ["", ".", "", ""], not ["", ""]
	    //    'tesst'.split(/(s)*/) should be ["t", undefined, "e", "s", "t"], not
	    //       [undefined, "t", undefined, "e", ...]
	    //    ''.split(/.?/) should be [], not [""]
	    //    '.'.split(/()()/) should be ["."], not ["", "", "."]
	
	    if (
	        'ab'.split(/(?:ab)*/).length !== 2 ||
	        '.'.split(/(.?)(.?)/).length !== 4 ||
	        'tesst'.split(/(s)*/)[1] === 't' ||
	        'test'.split(/(?:)/, -1).length !== 4 ||
	        ''.split(/.?/).length ||
	        '.'.split(/()()/).length > 1
	    ) {
	        (function () {
	            var compliantExecNpcg = typeof (/()??/).exec('')[1] === 'undefined'; // NPCG: nonparticipating capturing group
	            var maxSafe32BitInt = Math.pow(2, 32) - 1;
	
	            StringPrototype.split = function (separator, limit) {
	                var string = String(this);
	                if (typeof separator === 'undefined' && limit === 0) {
	                    return [];
	                }
	
	                // If `separator` is not a regex, use native split
	                if (!isRegex(separator)) {
	                    return strSplit(this, separator, limit);
	                }
	
	                var output = [];
	                var flags = (separator.ignoreCase ? 'i' : '') +
	                            (separator.multiline ? 'm' : '') +
	                            (separator.unicode ? 'u' : '') + // in ES6
	                            (separator.sticky ? 'y' : ''), // Firefox 3+ and ES6
	                    lastLastIndex = 0,
	                    // Make `global` and avoid `lastIndex` issues by working with a copy
	                    separator2, match, lastIndex, lastLength;
	                var separatorCopy = new RegExp(separator.source, flags + 'g');
	                if (!compliantExecNpcg) {
	                    // Doesn't need flags gy, but they don't hurt
	                    separator2 = new RegExp('^' + separatorCopy.source + '$(?!\\s)', flags);
	                }
	                /* Values for `limit`, per the spec:
	                 * If undefined: 4294967295 // maxSafe32BitInt
	                 * If 0, Infinity, or NaN: 0
	                 * If positive number: limit = Math.floor(limit); if (limit > 4294967295) limit -= 4294967296;
	                 * If negative number: 4294967296 - Math.floor(Math.abs(limit))
	                 * If other: Type-convert, then use the above rules
	                 */
	                var splitLimit = typeof limit === 'undefined' ? maxSafe32BitInt : ES.ToUint32(limit);
	                match = separatorCopy.exec(string);
	                while (match) {
	                    // `separatorCopy.lastIndex` is not reliable cross-browser
	                    lastIndex = match.index + match[0].length;
	                    if (lastIndex > lastLastIndex) {
	                        pushCall(output, strSlice(string, lastLastIndex, match.index));
	                        // Fix browsers whose `exec` methods don't consistently return `undefined` for
	                        // nonparticipating capturing groups
	                        if (!compliantExecNpcg && match.length > 1) {
	                            /* eslint-disable no-loop-func */
	                            match[0].replace(separator2, function () {
	                                for (var i = 1; i < arguments.length - 2; i++) {
	                                    if (typeof arguments[i] === 'undefined') {
	                                        match[i] = void 0;
	                                    }
	                                }
	                            });
	                            /* eslint-enable no-loop-func */
	                        }
	                        if (match.length > 1 && match.index < string.length) {
	                            array_push.apply(output, arraySlice(match, 1));
	                        }
	                        lastLength = match[0].length;
	                        lastLastIndex = lastIndex;
	                        if (output.length >= splitLimit) {
	                            break;
	                        }
	                    }
	                    if (separatorCopy.lastIndex === match.index) {
	                        separatorCopy.lastIndex++; // Avoid an infinite loop
	                    }
	                    match = separatorCopy.exec(string);
	                }
	                if (lastLastIndex === string.length) {
	                    if (lastLength || !separatorCopy.test('')) {
	                        pushCall(output, '');
	                    }
	                } else {
	                    pushCall(output, strSlice(string, lastLastIndex));
	                }
	                return output.length > splitLimit ? arraySlice(output, 0, splitLimit) : output;
	            };
	        }());
	
	    // [bugfix, chrome]
	    // If separator is undefined, then the result array contains just one String,
	    // which is the this value (converted to a String). If limit is not undefined,
	    // then the output array is truncated so that it contains no more than limit
	    // elements.
	    // "0".split(undefined, 0) -> []
	    } else if ('0'.split(void 0, 0).length) {
	        StringPrototype.split = function split(separator, limit) {
	            if (typeof separator === 'undefined' && limit === 0) {
	                return [];
	            }
	            return strSplit(this, separator, limit);
	        };
	    }
	
	    var str_replace = StringPrototype.replace;
	    var replaceReportsGroupsCorrectly = (function () {
	        var groups = [];
	        'x'.replace(/x(.)?/g, function (match, group) {
	            pushCall(groups, group);
	        });
	        return groups.length === 1 && typeof groups[0] === 'undefined';
	    }());
	
	    if (!replaceReportsGroupsCorrectly) {
	        StringPrototype.replace = function replace(searchValue, replaceValue) {
	            var isFn = isCallable(replaceValue);
	            var hasCapturingGroups = isRegex(searchValue) && (/\)[*?]/).test(searchValue.source);
	            if (!isFn || !hasCapturingGroups) {
	                return str_replace.call(this, searchValue, replaceValue);
	            } else {
	                var wrappedReplaceValue = function (match) {
	                    var length = arguments.length;
	                    var originalLastIndex = searchValue.lastIndex;
	                    searchValue.lastIndex = 0;
	                    var args = searchValue.exec(match) || [];
	                    searchValue.lastIndex = originalLastIndex;
	                    pushCall(args, arguments[length - 2], arguments[length - 1]);
	                    return replaceValue.apply(this, args);
	                };
	                return str_replace.call(this, searchValue, wrappedReplaceValue);
	            }
	        };
	    }
	
	    // ECMA-262, 3rd B.2.3
	    // Not an ECMAScript standard, although ECMAScript 3rd Edition has a
	    // non-normative section suggesting uniform semantics and it should be
	    // normalized across all browsers
	    // [bugfix, IE lt 9] IE < 9 substr() with negative value not working in IE
	    var string_substr = StringPrototype.substr;
	    var hasNegativeSubstrBug = ''.substr && '0b'.substr(-1) !== 'b';
	    defineProperties(StringPrototype, {
	        substr: function substr(start, length) {
	            var normalizedStart = start;
	            if (start < 0) {
	                normalizedStart = max(this.length + start, 0);
	            }
	            return string_substr.call(this, normalizedStart, length);
	        }
	    }, hasNegativeSubstrBug);
	
	    // ES5 15.5.4.20
	    // whitespace from: http://es5.github.io/#x15.5.4.20
	    var ws = '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003' +
	        '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028' +
	        '\u2029\uFEFF';
	    var zeroWidth = '\u200b';
	    var wsRegexChars = '[' + ws + ']';
	    var trimBeginRegexp = new RegExp('^' + wsRegexChars + wsRegexChars + '*');
	    var trimEndRegexp = new RegExp(wsRegexChars + wsRegexChars + '*$');
	    var hasTrimWhitespaceBug = StringPrototype.trim && (ws.trim() || !zeroWidth.trim());
	    defineProperties(StringPrototype, {
	        // http://blog.stevenlevithan.com/archives/faster-trim-javascript
	        // http://perfectionkills.com/whitespace-deviations/
	        trim: function trim() {
	            if (typeof this === 'undefined' || this === null) {
	                throw new TypeError("can't convert " + this + ' to object');
	            }
	            return $String(this).replace(trimBeginRegexp, '').replace(trimEndRegexp, '');
	        }
	    }, hasTrimWhitespaceBug);
	    var trim = call.bind(String.prototype.trim);
	
	    var hasLastIndexBug = StringPrototype.lastIndexOf && 'abcあい'.lastIndexOf('あい', 2) !== -1;
	    defineProperties(StringPrototype, {
	        lastIndexOf: function lastIndexOf(searchString) {
	            if (typeof this === 'undefined' || this === null) {
	                throw new TypeError("can't convert " + this + ' to object');
	            }
	            var S = $String(this);
	            var searchStr = $String(searchString);
	            var numPos = arguments.length > 1 ? $Number(arguments[1]) : NaN;
	            var pos = isActualNaN(numPos) ? Infinity : ES.ToInteger(numPos);
	            var start = min(max(pos, 0), S.length);
	            var searchLen = searchStr.length;
	            var k = start + searchLen;
	            while (k > 0) {
	                k = max(0, k - searchLen);
	                var index = strIndexOf(strSlice(S, k, start + searchLen), searchStr);
	                if (index !== -1) {
	                    return k + index;
	                }
	            }
	            return -1;
	        }
	    }, hasLastIndexBug);
	
	    var originalLastIndexOf = StringPrototype.lastIndexOf;
	    defineProperties(StringPrototype, {
	        lastIndexOf: function lastIndexOf(searchString) {
	            return originalLastIndexOf.apply(this, arguments);
	        }
	    }, StringPrototype.lastIndexOf.length !== 1);
	
	    // ES-5 15.1.2.2
	    /* eslint-disable radix */
	    if (parseInt(ws + '08') !== 8 || parseInt(ws + '0x16') !== 22) {
	    /* eslint-enable radix */
	        /* global parseInt: true */
	        parseInt = (function (origParseInt) {
	            var hexRegex = /^[\-+]?0[xX]/;
	            return function parseInt(str, radix) {
	                var string = trim(String(str));
	                var defaultedRadix = $Number(radix) || (hexRegex.test(string) ? 16 : 10);
	                return origParseInt(string, defaultedRadix);
	            };
	        }(parseInt));
	    }
	
	    // https://es5.github.io/#x15.1.2.3
	    if (1 / parseFloat('-0') !== -Infinity) {
	        /* global parseFloat: true */
	        parseFloat = (function (origParseFloat) {
	            return function parseFloat(string) {
	                var inputString = trim(String(string));
	                var result = origParseFloat(inputString);
	                return result === 0 && strSlice(inputString, 0, 1) === '-' ? -0 : result;
	            };
	        }(parseFloat));
	    }
	
	    if (String(new RangeError('test')) !== 'RangeError: test') {
	        var errorToStringShim = function toString() {
	            if (typeof this === 'undefined' || this === null) {
	                throw new TypeError("can't convert " + this + ' to object');
	            }
	            var name = this.name;
	            if (typeof name === 'undefined') {
	                name = 'Error';
	            } else if (typeof name !== 'string') {
	                name = $String(name);
	            }
	            var msg = this.message;
	            if (typeof msg === 'undefined') {
	                msg = '';
	            } else if (typeof msg !== 'string') {
	                msg = $String(msg);
	            }
	            if (!name) {
	                return msg;
	            }
	            if (!msg) {
	                return name;
	            }
	            return name + ': ' + msg;
	        };
	        // can't use defineProperties here because of toString enumeration issue in IE <= 8
	        Error.prototype.toString = errorToStringShim;
	    }
	
	    if (supportsDescriptors) {
	        var ensureNonEnumerable = function (obj, prop) {
	            if (isEnum(obj, prop)) {
	                var desc = Object.getOwnPropertyDescriptor(obj, prop);
	                if (desc.configurable) {
	                    desc.enumerable = false;
	                    Object.defineProperty(obj, prop, desc);
	                }
	            }
	        };
	        ensureNonEnumerable(Error.prototype, 'message');
	        if (Error.prototype.message !== '') {
	            Error.prototype.message = '';
	        }
	        ensureNonEnumerable(Error.prototype, 'name');
	    }
	
	    if (String(/a/mig) !== '/a/gim') {
	        var regexToString = function toString() {
	            var str = '/' + this.source + '/';
	            if (this.global) {
	                str += 'g';
	            }
	            if (this.ignoreCase) {
	                str += 'i';
	            }
	            if (this.multiline) {
	                str += 'm';
	            }
	            return str;
	        };
	        // can't use defineProperties here because of toString enumeration issue in IE <= 8
	        RegExp.prototype.toString = regexToString;
	    }
	}));

/***/ },
/* 2 */
/***/ function(module, exports) {

	// Copyright 2006 Google Inc.
	//
	// Licensed under the Apache License, Version 2.0 (the "License");
	// you may not use this file except in compliance with the License.
	// You may obtain a copy of the License at
	//
	//   http://www.apache.org/licenses/LICENSE-2.0
	//
	// Unless required by applicable law or agreed to in writing, software
	// distributed under the License is distributed on an "AS IS" BASIS,
	// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	// See the License for the specific language governing permissions and
	// limitations under the License.
	
	
	// Known Issues:
	//
	// * Patterns only support repeat.
	// * Radial gradient are not implemented. The VML version of these look very
	//   different from the canvas one.
	// * Clipping paths are not implemented.
	// * Coordsize. The width and height attribute have higher priority than the
	//   width and height style values which isn't correct.
	// * Painting mode isn't implemented.
	// * Canvas width/height should is using content-box by default. IE in
	//   Quirks mode will draw the canvas using border-box. Either change your
	//   doctype to HTML5
	//   (http://www.whatwg.org/specs/web-apps/current-work/#the-doctype)
	//   or use Box Sizing Behavior from WebFX
	//   (http://webfx.eae.net/dhtml/boxsizing/boxsizing.html)
	// * Non uniform scaling does not correctly scale strokes.
	// * Optimize. There is always room for speed improvements.
	
	// Only add this code if we do not already have a canvas implementation
	if (!document.createElement('canvas').getContext) {
	
	(function() {
	
	  // alias some functions to make (compiled) code shorter
	  var m = Math;
	  var mr = m.round;
	  var ms = m.sin;
	  var mc = m.cos;
	  var abs = m.abs;
	  var sqrt = m.sqrt;
	
	  // this is used for sub pixel precision
	  var Z = 10;
	  var Z2 = Z / 2;
	
	  var IE_VERSION = +navigator.userAgent.match(/MSIE ([\d.]+)?/)[1];
	
	  /**
	   * This funtion is assigned to the <canvas> elements as element.getContext().
	   * @this {HTMLElement}
	   * @return {CanvasRenderingContext2D_}
	   */
	  function getContext() {
	    return this.context_ ||
	        (this.context_ = new CanvasRenderingContext2D_(this));
	  }
	
	  var slice = Array.prototype.slice;
	
	  /**
	   * Binds a function to an object. The returned function will always use the
	   * passed in {@code obj} as {@code this}.
	   *
	   * Example:
	   *
	   *   g = bind(f, obj, a, b)
	   *   g(c, d) // will do f.call(obj, a, b, c, d)
	   *
	   * @param {Function} f The function to bind the object to
	   * @param {Object} obj The object that should act as this when the function
	   *     is called
	   * @param {*} var_args Rest arguments that will be used as the initial
	   *     arguments when the function is called
	   * @return {Function} A new function that has bound this
	   */
	  function bind(f, obj, var_args) {
	    var a = slice.call(arguments, 2);
	    return function() {
	      return f.apply(obj, a.concat(slice.call(arguments)));
	    };
	  }
	
	  function encodeHtmlAttribute(s) {
	    return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
	  }
	
	  function addNamespace(doc, prefix, urn) {
	    if (!doc.namespaces[prefix]) {
	      doc.namespaces.add(prefix, urn, '#default#VML');
	    }
	  }
	
	  function addNamespacesAndStylesheet(doc) {
	    addNamespace(doc, 'g_vml_', 'urn:schemas-microsoft-com:vml');
	    addNamespace(doc, 'g_o_', 'urn:schemas-microsoft-com:office:office');
	
	    // Setup default CSS.  Only add one style sheet per document
	    if (!doc.styleSheets['ex_canvas_']) {
	      var ss = doc.createStyleSheet();
	      ss.owningElement.id = 'ex_canvas_';
	      ss.cssText = 'canvas{display:inline-block;overflow:hidden;' +
	          // default size is 300x150 in Gecko and Opera
	          'text-align:left;width:300px;height:150px}';
	    }
	  }
	
	  // Add namespaces and stylesheet at startup.
	  addNamespacesAndStylesheet(document);
	
	  var G_vmlCanvasManager_ = {
	    init: function(opt_doc) {
	      var doc = opt_doc || document;
	      // Create a dummy element so that IE will allow canvas elements to be
	      // recognized.
	      doc.createElement('canvas');
	      doc.attachEvent('onreadystatechange', bind(this.init_, this, doc));
	    },
	
	    init_: function(doc) {
	      // find all canvas elements
	      var els = doc.getElementsByTagName('canvas');
	      for (var i = 0; i < els.length; i++) {
	        this.initElement(els[i]);
	      }
	    },
	
	    /**
	     * Public initializes a canvas element so that it can be used as canvas
	     * element from now on. This is called automatically before the page is
	     * loaded but if you are creating elements using createElement you need to
	     * make sure this is called on the element.
	     * @param {HTMLElement} el The canvas element to initialize.
	     * @return {HTMLElement} the element that was created.
	     */
	    initElement: function(el) {
	      if (!el.getContext) {
	        el.getContext = getContext;
	
	        // Add namespaces and stylesheet to document of the element.
	        addNamespacesAndStylesheet(el.ownerDocument);
	
	        // Remove fallback content. There is no way to hide text nodes so we
	        // just remove all childNodes. We could hide all elements and remove
	        // text nodes but who really cares about the fallback content.
	        el.innerHTML = '';
	
	        // do not use inline function because that will leak memory
	        el.attachEvent('onpropertychange', onPropertyChange);
	        el.attachEvent('onresize', onResize);
	
	        var attrs = el.attributes;
	        if (attrs.width && attrs.width.specified) {
	          // TODO: use runtimeStyle and coordsize
	          // el.getContext().setWidth_(attrs.width.nodeValue);
	          el.style.width = attrs.width.nodeValue + 'px';
	        } else {
	          el.width = el.clientWidth;
	        }
	        if (attrs.height && attrs.height.specified) {
	          // TODO: use runtimeStyle and coordsize
	          // el.getContext().setHeight_(attrs.height.nodeValue);
	          el.style.height = attrs.height.nodeValue + 'px';
	        } else {
	          el.height = el.clientHeight;
	        }
	        //el.getContext().setCoordsize_()
	      }
	      return el;
	    }
	  };
	
	  function onPropertyChange(e) {
	
	    var el = e.srcElement;
	
	    switch (e.propertyName) {
	      case 'width':
	        el.getContext().clearRect();
	        el.style.width = el.attributes.width.nodeValue + 'px';
	        // In IE8 this does not trigger onresize.
	        el.firstChild.style.width =  el.clientWidth + 'px';
	        break;
	      case 'height':
	        el.getContext().clearRect();
	        el.style.height = el.attributes.height.nodeValue + 'px';
	        el.firstChild.style.height = el.clientHeight + 'px';
	        break;
	    }
	  }
	
	  function onResize(e) {
	    var el = e.srcElement;
	    if (el.firstChild) {
	      el.firstChild.style.width =  el.clientWidth + 'px';
	      el.firstChild.style.height = el.clientHeight + 'px';
	    }
	  }
	
	  G_vmlCanvasManager_.init();
	
	  // precompute "00" to "FF"
	  var decToHex = [];
	  for (var i = 0; i < 16; i++) {
	    for (var j = 0; j < 16; j++) {
	      decToHex[i * 16 + j] = i.toString(16) + j.toString(16);
	    }
	  }
	
	  function createMatrixIdentity() {
	    return [
	      [1, 0, 0],
	      [0, 1, 0],
	      [0, 0, 1]
	    ];
	  }
	
	  function matrixMultiply(m1, m2) {
	    var result = createMatrixIdentity();
	
	    for (var x = 0; x < 3; x++) {
	      for (var y = 0; y < 3; y++) {
	        var sum = 0;
	
	        for (var z = 0; z < 3; z++) {
	          sum += m1[x][z] * m2[z][y];
	        }
	
	        result[x][y] = sum;
	      }
	    }
	    return result;
	  }
	
	  function copyState(o1, o2) {
	    o2.fillStyle     = o1.fillStyle;
	    o2.lineCap       = o1.lineCap;
	    o2.lineJoin      = o1.lineJoin;
	    o2.lineWidth     = o1.lineWidth;
	    o2.miterLimit    = o1.miterLimit;
	    o2.shadowBlur    = o1.shadowBlur;
	    o2.shadowColor   = o1.shadowColor;
	    o2.shadowOffsetX = o1.shadowOffsetX;
	    o2.shadowOffsetY = o1.shadowOffsetY;
	    o2.strokeStyle   = o1.strokeStyle;
	    o2.globalAlpha   = o1.globalAlpha;
	    o2.font          = o1.font;
	    o2.textAlign     = o1.textAlign;
	    o2.textBaseline  = o1.textBaseline;
	    o2.arcScaleX_    = o1.arcScaleX_;
	    o2.arcScaleY_    = o1.arcScaleY_;
	    o2.lineScale_    = o1.lineScale_;
	  }
	
	  var colorData = {
	    aliceblue: '#F0F8FF',
	    antiquewhite: '#FAEBD7',
	    aquamarine: '#7FFFD4',
	    azure: '#F0FFFF',
	    beige: '#F5F5DC',
	    bisque: '#FFE4C4',
	    black: '#000000',
	    blanchedalmond: '#FFEBCD',
	    blueviolet: '#8A2BE2',
	    brown: '#A52A2A',
	    burlywood: '#DEB887',
	    cadetblue: '#5F9EA0',
	    chartreuse: '#7FFF00',
	    chocolate: '#D2691E',
	    coral: '#FF7F50',
	    cornflowerblue: '#6495ED',
	    cornsilk: '#FFF8DC',
	    crimson: '#DC143C',
	    cyan: '#00FFFF',
	    darkblue: '#00008B',
	    darkcyan: '#008B8B',
	    darkgoldenrod: '#B8860B',
	    darkgray: '#A9A9A9',
	    darkgreen: '#006400',
	    darkgrey: '#A9A9A9',
	    darkkhaki: '#BDB76B',
	    darkmagenta: '#8B008B',
	    darkolivegreen: '#556B2F',
	    darkorange: '#FF8C00',
	    darkorchid: '#9932CC',
	    darkred: '#8B0000',
	    darksalmon: '#E9967A',
	    darkseagreen: '#8FBC8F',
	    darkslateblue: '#483D8B',
	    darkslategray: '#2F4F4F',
	    darkslategrey: '#2F4F4F',
	    darkturquoise: '#00CED1',
	    darkviolet: '#9400D3',
	    deeppink: '#FF1493',
	    deepskyblue: '#00BFFF',
	    dimgray: '#696969',
	    dimgrey: '#696969',
	    dodgerblue: '#1E90FF',
	    firebrick: '#B22222',
	    floralwhite: '#FFFAF0',
	    forestgreen: '#228B22',
	    gainsboro: '#DCDCDC',
	    ghostwhite: '#F8F8FF',
	    gold: '#FFD700',
	    goldenrod: '#DAA520',
	    grey: '#808080',
	    greenyellow: '#ADFF2F',
	    honeydew: '#F0FFF0',
	    hotpink: '#FF69B4',
	    indianred: '#CD5C5C',
	    indigo: '#4B0082',
	    ivory: '#FFFFF0',
	    khaki: '#F0E68C',
	    lavender: '#E6E6FA',
	    lavenderblush: '#FFF0F5',
	    lawngreen: '#7CFC00',
	    lemonchiffon: '#FFFACD',
	    lightblue: '#ADD8E6',
	    lightcoral: '#F08080',
	    lightcyan: '#E0FFFF',
	    lightgoldenrodyellow: '#FAFAD2',
	    lightgreen: '#90EE90',
	    lightgrey: '#D3D3D3',
	    lightpink: '#FFB6C1',
	    lightsalmon: '#FFA07A',
	    lightseagreen: '#20B2AA',
	    lightskyblue: '#87CEFA',
	    lightslategray: '#778899',
	    lightslategrey: '#778899',
	    lightsteelblue: '#B0C4DE',
	    lightyellow: '#FFFFE0',
	    limegreen: '#32CD32',
	    linen: '#FAF0E6',
	    magenta: '#FF00FF',
	    mediumaquamarine: '#66CDAA',
	    mediumblue: '#0000CD',
	    mediumorchid: '#BA55D3',
	    mediumpurple: '#9370DB',
	    mediumseagreen: '#3CB371',
	    mediumslateblue: '#7B68EE',
	    mediumspringgreen: '#00FA9A',
	    mediumturquoise: '#48D1CC',
	    mediumvioletred: '#C71585',
	    midnightblue: '#191970',
	    mintcream: '#F5FFFA',
	    mistyrose: '#FFE4E1',
	    moccasin: '#FFE4B5',
	    navajowhite: '#FFDEAD',
	    oldlace: '#FDF5E6',
	    olivedrab: '#6B8E23',
	    orange: '#FFA500',
	    orangered: '#FF4500',
	    orchid: '#DA70D6',
	    palegoldenrod: '#EEE8AA',
	    palegreen: '#98FB98',
	    paleturquoise: '#AFEEEE',
	    palevioletred: '#DB7093',
	    papayawhip: '#FFEFD5',
	    peachpuff: '#FFDAB9',
	    peru: '#CD853F',
	    pink: '#FFC0CB',
	    plum: '#DDA0DD',
	    powderblue: '#B0E0E6',
	    rosybrown: '#BC8F8F',
	    royalblue: '#4169E1',
	    saddlebrown: '#8B4513',
	    salmon: '#FA8072',
	    sandybrown: '#F4A460',
	    seagreen: '#2E8B57',
	    seashell: '#FFF5EE',
	    sienna: '#A0522D',
	    skyblue: '#87CEEB',
	    slateblue: '#6A5ACD',
	    slategray: '#708090',
	    slategrey: '#708090',
	    snow: '#FFFAFA',
	    springgreen: '#00FF7F',
	    steelblue: '#4682B4',
	    tan: '#D2B48C',
	    thistle: '#D8BFD8',
	    tomato: '#FF6347',
	    turquoise: '#40E0D0',
	    violet: '#EE82EE',
	    wheat: '#F5DEB3',
	    whitesmoke: '#F5F5F5',
	    yellowgreen: '#9ACD32'
	  };
	
	
	  function getRgbHslContent(styleString) {
	    var start = styleString.indexOf('(', 3);
	    var end = styleString.indexOf(')', start + 1);
	    var parts = styleString.substring(start + 1, end).split(',');
	    // add alpha if needed
	    if (parts.length != 4 || styleString.charAt(3) != 'a') {
	      parts[3] = 1;
	    }
	    return parts;
	  }
	
	  function percent(s) {
	    return parseFloat(s) / 100;
	  }
	
	  function clamp(v, min, max) {
	    return Math.min(max, Math.max(min, v));
	  }
	
	  function hslToRgb(parts){
	    var r, g, b, h, s, l;
	    h = parseFloat(parts[0]) / 360 % 360;
	    if (h < 0)
	      h++;
	    s = clamp(percent(parts[1]), 0, 1);
	    l = clamp(percent(parts[2]), 0, 1);
	    if (s == 0) {
	      r = g = b = l; // achromatic
	    } else {
	      var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
	      var p = 2 * l - q;
	      r = hueToRgb(p, q, h + 1 / 3);
	      g = hueToRgb(p, q, h);
	      b = hueToRgb(p, q, h - 1 / 3);
	    }
	
	    return '#' + decToHex[Math.floor(r * 255)] +
	        decToHex[Math.floor(g * 255)] +
	        decToHex[Math.floor(b * 255)];
	  }
	
	  function hueToRgb(m1, m2, h) {
	    if (h < 0)
	      h++;
	    if (h > 1)
	      h--;
	
	    if (6 * h < 1)
	      return m1 + (m2 - m1) * 6 * h;
	    else if (2 * h < 1)
	      return m2;
	    else if (3 * h < 2)
	      return m1 + (m2 - m1) * (2 / 3 - h) * 6;
	    else
	      return m1;
	  }
	
	  var processStyleCache = {};
	
	  function processStyle(styleString) {
	    if (styleString in processStyleCache) {
	      return processStyleCache[styleString];
	    }
	
	    var str, alpha = 1;
	
	    styleString = String(styleString);
	    if (styleString.charAt(0) == '#') {
	      str = styleString;
	    } else if (/^rgb/.test(styleString)) {
	      var parts = getRgbHslContent(styleString);
	      var str = '#', n;
	      for (var i = 0; i < 3; i++) {
	        if (parts[i].indexOf('%') != -1) {
	          n = Math.floor(percent(parts[i]) * 255);
	        } else {
	          n = +parts[i];
	        }
	        str += decToHex[clamp(n, 0, 255)];
	      }
	      alpha = +parts[3];
	    } else if (/^hsl/.test(styleString)) {
	      var parts = getRgbHslContent(styleString);
	      str = hslToRgb(parts);
	      alpha = parts[3];
	    } else {
	      str = colorData[styleString] || styleString;
	    }
	    return processStyleCache[styleString] = {color: str, alpha: alpha};
	  }
	
	  var DEFAULT_STYLE = {
	    style: 'normal',
	    variant: 'normal',
	    weight: 'normal',
	    size: 10,
	    family: 'sans-serif'
	  };
	
	  // Internal text style cache
	  var fontStyleCache = {};
	
	  function processFontStyle(styleString) {
	    if (fontStyleCache[styleString]) {
	      return fontStyleCache[styleString];
	    }
	
	    var el = document.createElement('div');
	    var style = el.style;
	    try {
	      style.font = styleString;
	    } catch (ex) {
	      // Ignore failures to set to invalid font.
	    }
	
	    return fontStyleCache[styleString] = {
	      style: style.fontStyle || DEFAULT_STYLE.style,
	      variant: style.fontVariant || DEFAULT_STYLE.variant,
	      weight: style.fontWeight || DEFAULT_STYLE.weight,
	      size: style.fontSize || DEFAULT_STYLE.size,
	      family: style.fontFamily || DEFAULT_STYLE.family
	    };
	  }
	
	  function getComputedStyle(style, element) {
	    var computedStyle = {};
	
	    for (var p in style) {
	      computedStyle[p] = style[p];
	    }
	
	    // Compute the size
	    var canvasFontSize = parseFloat(element.currentStyle.fontSize),
	        fontSize = parseFloat(style.size);
	
	    if (typeof style.size == 'number') {
	      computedStyle.size = style.size;
	    } else if (style.size.indexOf('px') != -1) {
	      computedStyle.size = fontSize;
	    } else if (style.size.indexOf('em') != -1) {
	      computedStyle.size = canvasFontSize * fontSize;
	    } else if(style.size.indexOf('%') != -1) {
	      computedStyle.size = (canvasFontSize / 100) * fontSize;
	    } else if (style.size.indexOf('pt') != -1) {
	      computedStyle.size = fontSize / .75;
	    } else {
	      computedStyle.size = canvasFontSize;
	    }
	
	    // Different scaling between normal text and VML text. This was found using
	    // trial and error to get the same size as non VML text.
	    computedStyle.size *= 0.981;
	
	    return computedStyle;
	  }
	
	  function buildStyle(style) {
	    return style.style + ' ' + style.variant + ' ' + style.weight + ' ' +
	        style.size + 'px ' + style.family;
	  }
	
	  var lineCapMap = {
	    'butt': 'flat',
	    'round': 'round'
	  };
	
	  function processLineCap(lineCap) {
	    return lineCapMap[lineCap] || 'square';
	  }
	
	  /**
	   * This class implements CanvasRenderingContext2D interface as described by
	   * the WHATWG.
	   * @param {HTMLElement} canvasElement The element that the 2D context should
	   * be associated with
	   */
	  function CanvasRenderingContext2D_(canvasElement) {
	    this.m_ = createMatrixIdentity();
	
	    this.mStack_ = [];
	    this.aStack_ = [];
	    this.currentPath_ = [];
	
	    // Canvas context properties
	    this.strokeStyle = '#000';
	    this.fillStyle = '#000';
	
	    this.lineWidth = 1;
	    this.lineJoin = 'miter';
	    this.lineCap = 'butt';
	    this.miterLimit = Z * 1;
	    this.globalAlpha = 1;
	    this.font = '10px sans-serif';
	    this.textAlign = 'left';
	    this.textBaseline = 'alphabetic';
	    this.canvas = canvasElement;
	
	    var cssText = 'width:' + canvasElement.clientWidth + 'px;height:' +
	        canvasElement.clientHeight + 'px;overflow:hidden;position:absolute;zoom:1;';
	    var el = canvasElement.ownerDocument.createElement('div');
	    el.style.cssText = cssText;
	    canvasElement.appendChild(el);
	
	    var overlayEl = el.cloneNode(false);
	    // Use a non transparent background.
	    overlayEl.style.backgroundColor = 'red';
	    overlayEl.style.filter = 'alpha(opacity=0)';
	    canvasElement.appendChild(overlayEl);
	
	    this.element_ = el;
	    this.arcScaleX_ = 1;
	    this.arcScaleY_ = 1;
	    this.lineScale_ = 1;
	  }
	
	  var contextPrototype = CanvasRenderingContext2D_.prototype;
	  contextPrototype.clearRect = function() {
	    if (this.textMeasureEl_) {
	      this.textMeasureEl_.removeNode(true);
	      this.textMeasureEl_ = null;
	    }
	    this.element_.innerHTML = '';
	  };
	
	  contextPrototype.beginPath = function() {
	    // TODO: Branch current matrix so that save/restore has no effect
	    //       as per safari docs.
	    this.currentPath_ = [];
	  };
	
	  contextPrototype.moveTo = function(aX, aY) {
	    var p = getCoords(this, aX, aY);
	    this.currentPath_.push({type: 'moveTo', x: p.x, y: p.y});
	    this.currentX_ = p.x;
	    this.currentY_ = p.y;
	  };
	
	  contextPrototype.lineTo = function(aX, aY) {
	    var p = getCoords(this, aX, aY);
	    this.currentPath_.push({type: 'lineTo', x: p.x, y: p.y});
	
	    this.currentX_ = p.x;
	    this.currentY_ = p.y;
	  };
	
	  contextPrototype.bezierCurveTo = function(aCP1x, aCP1y,
	                                            aCP2x, aCP2y,
	                                            aX, aY) {
	    var p = getCoords(this, aX, aY);
	    var cp1 = getCoords(this, aCP1x, aCP1y);
	    var cp2 = getCoords(this, aCP2x, aCP2y);
	    bezierCurveTo(this, cp1, cp2, p);
	  };
	
	  // Helper function that takes the already fixed cordinates.
	  function bezierCurveTo(self, cp1, cp2, p) {
	    self.currentPath_.push({
	      type: 'bezierCurveTo',
	      cp1x: cp1.x,
	      cp1y: cp1.y,
	      cp2x: cp2.x,
	      cp2y: cp2.y,
	      x: p.x,
	      y: p.y
	    });
	    self.currentX_ = p.x;
	    self.currentY_ = p.y;
	  }
	
	  contextPrototype.quadraticCurveTo = function(aCPx, aCPy, aX, aY) {
	    // the following is lifted almost directly from
	    // http://developer.mozilla.org/en/docs/Canvas_tutorial:Drawing_shapes
	
	    var cp = getCoords(this, aCPx, aCPy);
	    var p = getCoords(this, aX, aY);
	
	    var cp1 = {
	      x: this.currentX_ + 2.0 / 3.0 * (cp.x - this.currentX_),
	      y: this.currentY_ + 2.0 / 3.0 * (cp.y - this.currentY_)
	    };
	    var cp2 = {
	      x: cp1.x + (p.x - this.currentX_) / 3.0,
	      y: cp1.y + (p.y - this.currentY_) / 3.0
	    };
	
	    bezierCurveTo(this, cp1, cp2, p);
	  };
	
	  contextPrototype.arc = function(aX, aY, aRadius,
	                                  aStartAngle, aEndAngle, aClockwise) {
	    aRadius *= Z;
	    var arcType = aClockwise ? 'at' : 'wa';
	
	    var xStart = aX + mc(aStartAngle) * aRadius - Z2;
	    var yStart = aY + ms(aStartAngle) * aRadius - Z2;
	
	    var xEnd = aX + mc(aEndAngle) * aRadius - Z2;
	    var yEnd = aY + ms(aEndAngle) * aRadius - Z2;
	
	    // IE won't render arches drawn counter clockwise if xStart == xEnd.
	    if (xStart == xEnd && !aClockwise) {
	      xStart += 0.125; // Offset xStart by 1/80 of a pixel. Use something
	                       // that can be represented in binary
	    }
	
	    var p = getCoords(this, aX, aY);
	    var pStart = getCoords(this, xStart, yStart);
	    var pEnd = getCoords(this, xEnd, yEnd);
	
	    this.currentPath_.push({type: arcType,
	                           x: p.x,
	                           y: p.y,
	                           radius: aRadius,
	                           xStart: pStart.x,
	                           yStart: pStart.y,
	                           xEnd: pEnd.x,
	                           yEnd: pEnd.y});
	
	  };
	
	  contextPrototype.rect = function(aX, aY, aWidth, aHeight) {
	    this.moveTo(aX, aY);
	    this.lineTo(aX + aWidth, aY);
	    this.lineTo(aX + aWidth, aY + aHeight);
	    this.lineTo(aX, aY + aHeight);
	    this.closePath();
	  };
	
	  contextPrototype.strokeRect = function(aX, aY, aWidth, aHeight) {
	    var oldPath = this.currentPath_;
	    this.beginPath();
	
	    this.moveTo(aX, aY);
	    this.lineTo(aX + aWidth, aY);
	    this.lineTo(aX + aWidth, aY + aHeight);
	    this.lineTo(aX, aY + aHeight);
	    this.closePath();
	    this.stroke();
	
	    this.currentPath_ = oldPath;
	  };
	
	  contextPrototype.fillRect = function(aX, aY, aWidth, aHeight) {
	    var oldPath = this.currentPath_;
	    this.beginPath();
	
	    this.moveTo(aX, aY);
	    this.lineTo(aX + aWidth, aY);
	    this.lineTo(aX + aWidth, aY + aHeight);
	    this.lineTo(aX, aY + aHeight);
	    this.closePath();
	    this.fill();
	
	    this.currentPath_ = oldPath;
	  };
	
	  contextPrototype.createLinearGradient = function(aX0, aY0, aX1, aY1) {
	    var gradient = new CanvasGradient_('gradient');
	    gradient.x0_ = aX0;
	    gradient.y0_ = aY0;
	    gradient.x1_ = aX1;
	    gradient.y1_ = aY1;
	    return gradient;
	  };
	
	  contextPrototype.createRadialGradient = function(aX0, aY0, aR0,
	                                                   aX1, aY1, aR1) {
	    var gradient = new CanvasGradient_('gradientradial');
	    gradient.x0_ = aX0;
	    gradient.y0_ = aY0;
	    gradient.r0_ = aR0;
	    gradient.x1_ = aX1;
	    gradient.y1_ = aY1;
	    gradient.r1_ = aR1;
	    return gradient;
	  };
	
	  contextPrototype.drawImage = function(image, var_args) {
	    var dx, dy, dw, dh, sx, sy, sw, sh;
	
	    // to find the original width we overide the width and height
	    var oldRuntimeWidth = image.runtimeStyle.width;
	    var oldRuntimeHeight = image.runtimeStyle.height;
	    image.runtimeStyle.width = 'auto';
	    image.runtimeStyle.height = 'auto';
	
	    // get the original size
	    var w = image.width;
	    var h = image.height;
	
	    // and remove overides
	    image.runtimeStyle.width = oldRuntimeWidth;
	    image.runtimeStyle.height = oldRuntimeHeight;
	
	    if (arguments.length == 3) {
	      dx = arguments[1];
	      dy = arguments[2];
	      sx = sy = 0;
	      sw = dw = w;
	      sh = dh = h;
	    } else if (arguments.length == 5) {
	      dx = arguments[1];
	      dy = arguments[2];
	      dw = arguments[3];
	      dh = arguments[4];
	      sx = sy = 0;
	      sw = w;
	      sh = h;
	    } else if (arguments.length == 9) {
	      sx = arguments[1];
	      sy = arguments[2];
	      sw = arguments[3];
	      sh = arguments[4];
	      dx = arguments[5];
	      dy = arguments[6];
	      dw = arguments[7];
	      dh = arguments[8];
	    } else {
	      throw Error('Invalid number of arguments');
	    }
	
	    var d = getCoords(this, dx, dy);
	
	    var w2 = sw / 2;
	    var h2 = sh / 2;
	
	    var vmlStr = [];
	
	    var W = 10;
	    var H = 10;
	
	    // For some reason that I've now forgotten, using divs didn't work
	    vmlStr.push(' <g_vml_:group',
	                ' coordsize="', Z * W, ',', Z * H, '"',
	                ' coordorigin="0,0"' ,
	                ' style="width:', W, 'px;height:', H, 'px;position:absolute;');
	
	    // If filters are necessary (rotation exists), create them
	    // filters are bog-slow, so only create them if abbsolutely necessary
	    // The following check doesn't account for skews (which don't exist
	    // in the canvas spec (yet) anyway.
	
	    if (this.m_[0][0] != 1 || this.m_[0][1] ||
	        this.m_[1][1] != 1 || this.m_[1][0]) {
	      var filter = [];
	
	      // Note the 12/21 reversal
	      filter.push('M11=', this.m_[0][0], ',',
	                  'M12=', this.m_[1][0], ',',
	                  'M21=', this.m_[0][1], ',',
	                  'M22=', this.m_[1][1], ',',
	                  'Dx=', mr(d.x / Z), ',',
	                  'Dy=', mr(d.y / Z), '');
	
	      // Bounding box calculation (need to minimize displayed area so that
	      // filters don't waste time on unused pixels.
	      var max = d;
	      var c2 = getCoords(this, dx + dw, dy);
	      var c3 = getCoords(this, dx, dy + dh);
	      var c4 = getCoords(this, dx + dw, dy + dh);
	
	      max.x = m.max(max.x, c2.x, c3.x, c4.x);
	      max.y = m.max(max.y, c2.y, c3.y, c4.y);
	
	      vmlStr.push('padding:0 ', mr(max.x / Z), 'px ', mr(max.y / Z),
	                  'px 0;filter:progid:DXImageTransform.Microsoft.Matrix(',
	                  filter.join(''), ", sizingmethod='clip');");
	
	    } else {
	      vmlStr.push('top:', mr(d.y / Z), 'px;left:', mr(d.x / Z), 'px;');
	    }
	
	    vmlStr.push(' ">' ,
	                '<g_vml_:image src="', image.src, '"',
	                ' style="width:', Z * dw, 'px;',
	                ' height:', Z * dh, 'px"',
	                ' cropleft="', sx / w, '"',
	                ' croptop="', sy / h, '"',
	                ' cropright="', (w - sx - sw) / w, '"',
	                ' cropbottom="', (h - sy - sh) / h, '"',
	                ' />',
	                '</g_vml_:group>');
	
	    this.element_.insertAdjacentHTML('BeforeEnd', vmlStr.join(''));
	  };
	
	  contextPrototype.stroke = function(aFill) {
	    var lineStr = [];
	    var lineOpen = false;
	
	    var W = 10;
	    var H = 10;
	
	    lineStr.push('<g_vml_:shape',
	                 ' filled="', !!aFill, '"',
	                 ' style="position:absolute;width:', W, 'px;height:', H, 'px;"',
	                 ' coordorigin="0,0"',
	                 ' coordsize="', Z * W, ',', Z * H, '"',
	                 ' stroked="', !aFill, '"',
	                 ' path="');
	
	    var newSeq = false;
	    var min = {x: null, y: null};
	    var max = {x: null, y: null};
	
	    for (var i = 0; i < this.currentPath_.length; i++) {
	      var p = this.currentPath_[i];
	      var c;
	
	      switch (p.type) {
	        case 'moveTo':
	          c = p;
	          lineStr.push(' m ', mr(p.x), ',', mr(p.y));
	          break;
	        case 'lineTo':
	          lineStr.push(' l ', mr(p.x), ',', mr(p.y));
	          break;
	        case 'close':
	          lineStr.push(' x ');
	          p = null;
	          break;
	        case 'bezierCurveTo':
	          lineStr.push(' c ',
	                       mr(p.cp1x), ',', mr(p.cp1y), ',',
	                       mr(p.cp2x), ',', mr(p.cp2y), ',',
	                       mr(p.x), ',', mr(p.y));
	          break;
	        case 'at':
	        case 'wa':
	          lineStr.push(' ', p.type, ' ',
	                       mr(p.x - this.arcScaleX_ * p.radius), ',',
	                       mr(p.y - this.arcScaleY_ * p.radius), ' ',
	                       mr(p.x + this.arcScaleX_ * p.radius), ',',
	                       mr(p.y + this.arcScaleY_ * p.radius), ' ',
	                       mr(p.xStart), ',', mr(p.yStart), ' ',
	                       mr(p.xEnd), ',', mr(p.yEnd));
	          break;
	      }
	
	
	      // TODO: Following is broken for curves due to
	      //       move to proper paths.
	
	      // Figure out dimensions so we can do gradient fills
	      // properly
	      if (p) {
	        if (min.x == null || p.x < min.x) {
	          min.x = p.x;
	        }
	        if (max.x == null || p.x > max.x) {
	          max.x = p.x;
	        }
	        if (min.y == null || p.y < min.y) {
	          min.y = p.y;
	        }
	        if (max.y == null || p.y > max.y) {
	          max.y = p.y;
	        }
	      }
	    }
	    lineStr.push(' ">');
	
	    if (!aFill) {
	      appendStroke(this, lineStr);
	    } else {
	      appendFill(this, lineStr, min, max);
	    }
	
	    lineStr.push('</g_vml_:shape>');
	
	    this.element_.insertAdjacentHTML('beforeEnd', lineStr.join(''));
	  };
	
	  function appendStroke(ctx, lineStr) {
	    var a = processStyle(ctx.strokeStyle);
	    var color = a.color;
	    var opacity = a.alpha * ctx.globalAlpha;
	    var lineWidth = ctx.lineScale_ * ctx.lineWidth;
	
	    // VML cannot correctly render a line if the width is less than 1px.
	    // In that case, we dilute the color to make the line look thinner.
	    if (lineWidth < 1) {
	      opacity *= lineWidth;
	    }
	
	    lineStr.push(
	      '<g_vml_:stroke',
	      ' opacity="', opacity, '"',
	      ' joinstyle="', ctx.lineJoin, '"',
	      ' miterlimit="', ctx.miterLimit, '"',
	      ' endcap="', processLineCap(ctx.lineCap), '"',
	      ' weight="', lineWidth, 'px"',
	      ' color="', color, '" />'
	    );
	  }
	
	  function appendFill(ctx, lineStr, min, max) {
	    var fillStyle = ctx.fillStyle;
	    var arcScaleX = ctx.arcScaleX_;
	    var arcScaleY = ctx.arcScaleY_;
	    var width = max.x - min.x;
	    var height = max.y - min.y;
	    if (fillStyle instanceof CanvasGradient_) {
	      // TODO: Gradients transformed with the transformation matrix.
	      var angle = 0;
	      var focus = {x: 0, y: 0};
	
	      // additional offset
	      var shift = 0;
	      // scale factor for offset
	      var expansion = 1;
	
	      if (fillStyle.type_ == 'gradient') {
	        var x0 = fillStyle.x0_ / arcScaleX;
	        var y0 = fillStyle.y0_ / arcScaleY;
	        var x1 = fillStyle.x1_ / arcScaleX;
	        var y1 = fillStyle.y1_ / arcScaleY;
	        var p0 = getCoords(ctx, x0, y0);
	        var p1 = getCoords(ctx, x1, y1);
	        var dx = p1.x - p0.x;
	        var dy = p1.y - p0.y;
	        angle = Math.atan2(dx, dy) * 180 / Math.PI;
	
	        // The angle should be a non-negative number.
	        if (angle < 0) {
	          angle += 360;
	        }
	
	        // Very small angles produce an unexpected result because they are
	        // converted to a scientific notation string.
	        if (angle < 1e-6) {
	          angle = 0;
	        }
	      } else {
	        var p0 = getCoords(ctx, fillStyle.x0_, fillStyle.y0_);
	        focus = {
	          x: (p0.x - min.x) / width,
	          y: (p0.y - min.y) / height
	        };
	
	        width  /= arcScaleX * Z;
	        height /= arcScaleY * Z;
	        var dimension = m.max(width, height);
	        shift = 2 * fillStyle.r0_ / dimension;
	        expansion = 2 * fillStyle.r1_ / dimension - shift;
	      }
	
	      // We need to sort the color stops in ascending order by offset,
	      // otherwise IE won't interpret it correctly.
	      var stops = fillStyle.colors_;
	      stops.sort(function(cs1, cs2) {
	        return cs1.offset - cs2.offset;
	      });
	
	      var length = stops.length;
	      var color1 = stops[0].color;
	      var color2 = stops[length - 1].color;
	      var opacity1 = stops[0].alpha * ctx.globalAlpha;
	      var opacity2 = stops[length - 1].alpha * ctx.globalAlpha;
	
	      var colors = [];
	      for (var i = 0; i < length; i++) {
	        var stop = stops[i];
	        colors.push(stop.offset * expansion + shift + ' ' + stop.color);
	      }
	
	      // When colors attribute is used, the meanings of opacity and o:opacity2
	      // are reversed.
	      lineStr.push('<g_vml_:fill type="', fillStyle.type_, '"',
	                   ' method="none" focus="100%"',
	                   ' color="', color1, '"',
	                   ' color2="', color2, '"',
	                   ' colors="', colors.join(','), '"',
	                   ' opacity="', opacity2, '"',
	                   ' g_o_:opacity2="', opacity1, '"',
	                   ' angle="', angle, '"',
	                   ' focusposition="', focus.x, ',', focus.y, '" />');
	    } else if (fillStyle instanceof CanvasPattern_) {
	      if (width && height) {
	        var deltaLeft = -min.x;
	        var deltaTop = -min.y;
	        lineStr.push('<g_vml_:fill',
	                     ' position="',
	                     deltaLeft / width * arcScaleX * arcScaleX, ',',
	                     deltaTop / height * arcScaleY * arcScaleY, '"',
	                     ' type="tile"',
	                     // TODO: Figure out the correct size to fit the scale.
	                     //' size="', w, 'px ', h, 'px"',
	                     ' src="', fillStyle.src_, '" />');
	       }
	    } else {
	      var a = processStyle(ctx.fillStyle);
	      var color = a.color;
	      var opacity = a.alpha * ctx.globalAlpha;
	      lineStr.push('<g_vml_:fill color="', color, '" opacity="', opacity,
	                   '" />');
	    }
	  }
	
	  contextPrototype.fill = function() {
	    this.stroke(true);
	  };
	
	  contextPrototype.closePath = function() {
	    this.currentPath_.push({type: 'close'});
	  };
	
	  function getCoords(ctx, aX, aY) {
	    var m = ctx.m_;
	    return {
	      x: Z * (aX * m[0][0] + aY * m[1][0] + m[2][0]) - Z2,
	      y: Z * (aX * m[0][1] + aY * m[1][1] + m[2][1]) - Z2
	    };
	  };
	
	  contextPrototype.save = function() {
	    var o = {};
	    copyState(this, o);
	    this.aStack_.push(o);
	    this.mStack_.push(this.m_);
	    this.m_ = matrixMultiply(createMatrixIdentity(), this.m_);
	  };
	
	  contextPrototype.restore = function() {
	    if (this.aStack_.length) {
	      copyState(this.aStack_.pop(), this);
	      this.m_ = this.mStack_.pop();
	    }
	  };
	
	  function matrixIsFinite(m) {
	    return isFinite(m[0][0]) && isFinite(m[0][1]) &&
	        isFinite(m[1][0]) && isFinite(m[1][1]) &&
	        isFinite(m[2][0]) && isFinite(m[2][1]);
	  }
	
	  function setM(ctx, m, updateLineScale) {
	    if (!matrixIsFinite(m)) {
	      return;
	    }
	    ctx.m_ = m;
	
	    if (updateLineScale) {
	      // Get the line scale.
	      // Determinant of this.m_ means how much the area is enlarged by the
	      // transformation. So its square root can be used as a scale factor
	      // for width.
	      var det = m[0][0] * m[1][1] - m[0][1] * m[1][0];
	      ctx.lineScale_ = sqrt(abs(det));
	    }
	  }
	
	  contextPrototype.translate = function(aX, aY) {
	    var m1 = [
	      [1,  0,  0],
	      [0,  1,  0],
	      [aX, aY, 1]
	    ];
	
	    setM(this, matrixMultiply(m1, this.m_), false);
	  };
	
	  contextPrototype.rotate = function(aRot) {
	    var c = mc(aRot);
	    var s = ms(aRot);
	
	    var m1 = [
	      [c,  s, 0],
	      [-s, c, 0],
	      [0,  0, 1]
	    ];
	
	    setM(this, matrixMultiply(m1, this.m_), false);
	  };
	
	  contextPrototype.scale = function(aX, aY) {
	    this.arcScaleX_ *= aX;
	    this.arcScaleY_ *= aY;
	    var m1 = [
	      [aX, 0,  0],
	      [0,  aY, 0],
	      [0,  0,  1]
	    ];
	
	    setM(this, matrixMultiply(m1, this.m_), true);
	  };
	
	  contextPrototype.transform = function(m11, m12, m21, m22, dx, dy) {
	    var m1 = [
	      [m11, m12, 0],
	      [m21, m22, 0],
	      [dx,  dy,  1]
	    ];
	
	    setM(this, matrixMultiply(m1, this.m_), true);
	  };
	
	  contextPrototype.setTransform = function(m11, m12, m21, m22, dx, dy) {
	    var m = [
	      [m11, m12, 0],
	      [m21, m22, 0],
	      [dx,  dy,  1]
	    ];
	
	    setM(this, m, true);
	  };
	
	  /**
	   * The text drawing function.
	   * The maxWidth argument isn't taken in account, since no browser supports
	   * it yet.
	   */
	  contextPrototype.drawText_ = function(text, x, y, maxWidth, stroke) {
	    var m = this.m_,
	        delta = 1000,
	        left = 0,
	        right = delta,
	        offset = {x: 0, y: 0},
	        lineStr = [];
	
	    var fontStyle = getComputedStyle(processFontStyle(this.font),
	                                     this.element_);
	
	    var fontStyleString = buildStyle(fontStyle);
	
	    var elementStyle = this.element_.currentStyle;
	    var textAlign = this.textAlign.toLowerCase();
	    switch (textAlign) {
	      case 'left':
	      case 'center':
	      case 'right':
	        break;
	      case 'end':
	        textAlign = elementStyle.direction == 'ltr' ? 'right' : 'left';
	        break;
	      case 'start':
	        textAlign = elementStyle.direction == 'rtl' ? 'right' : 'left';
	        break;
	      default:
	        textAlign = 'left';
	    }
	
	    // 1.75 is an arbitrary number, as there is no info about the text baseline
	    switch (this.textBaseline) {
	      case 'hanging':
	      case 'top':
	        offset.y = fontStyle.size / 1.75;
	        break;
	      case 'middle':
	        break;
	      default:
	      case null:
	      case 'alphabetic':
	      case 'ideographic':
	      case 'bottom':
	        offset.y = -fontStyle.size / 2.25;
	        break;
	    }
	
	    switch(textAlign) {
	      case 'right':
	        left = delta;
	        right = 0.05;
	        break;
	      case 'center':
	        left = right = delta / 2;
	        break;
	    }
	
	    var d = getCoords(this, x + offset.x, y + offset.y);
	
	    lineStr.push('<g_vml_:line from="', -left ,' 0" to="', right ,' 0.05" ',
	                 ' coordsize="100 100" coordorigin="0 0"',
	                 ' filled="', !stroke, '" stroked="', !!stroke,
	                 '" style="position:absolute;width:1px;height:1px;">');
	
	    if (stroke) {
	      appendStroke(this, lineStr);
	    } else {
	      // TODO: Fix the min and max params.
	      appendFill(this, lineStr, {x: -left, y: 0},
	                 {x: right, y: fontStyle.size});
	    }
	
	    var skewM = m[0][0].toFixed(3) + ',' + m[1][0].toFixed(3) + ',' +
	                m[0][1].toFixed(3) + ',' + m[1][1].toFixed(3) + ',0,0';
	
	    var skewOffset = mr(d.x / Z) + ',' + mr(d.y / Z);
	
	    lineStr.push('<g_vml_:skew on="t" matrix="', skewM ,'" ',
	                 ' offset="', skewOffset, '" origin="', left ,' 0" />',
	                 '<g_vml_:path textpathok="true" />',
	                 '<g_vml_:textpath on="true" string="',
	                 encodeHtmlAttribute(text),
	                 '" style="v-text-align:', textAlign,
	                 ';font:', encodeHtmlAttribute(fontStyleString),
	                 '" /></g_vml_:line>');
	
	    this.element_.insertAdjacentHTML('beforeEnd', lineStr.join(''));
	  };
	
	  contextPrototype.fillText = function(text, x, y, maxWidth) {
	    this.drawText_(text, x, y, maxWidth, false);
	  };
	
	  contextPrototype.strokeText = function(text, x, y, maxWidth) {
	    this.drawText_(text, x, y, maxWidth, true);
	  };
	
	  contextPrototype.measureText = function(text) {
	    if (!this.textMeasureEl_) {
	      var s = '<span style="position:absolute;' +
	          'top:-20000px;left:0;padding:0;margin:0;border:none;' +
	          'white-space:pre;"></span>';
	      this.element_.insertAdjacentHTML('beforeEnd', s);
	      this.textMeasureEl_ = this.element_.lastChild;
	    }
	    var doc = this.element_.ownerDocument;
	    this.textMeasureEl_.innerHTML = '';
	
	    try{
	      this.textMeasureEl_.style.font = this.font;
	    }
	    catch (e){
	      
	    }
	    
	    // Don't use innerHTML or innerText because they allow markup/whitespace.
	    this.textMeasureEl_.appendChild(doc.createTextNode(text));
	    return {width: this.textMeasureEl_.offsetWidth};
	  };
	
	  /******** STUBS ********/
	  contextPrototype.clip = function() {
	    // TODO: Implement
	  };
	
	  contextPrototype.arcTo = function() {
	    // TODO: Implement
	  };
	
	  contextPrototype.createPattern = function(image, repetition) {
	    return new CanvasPattern_(image, repetition);
	  };
	
	  // Gradient / Pattern Stubs
	  function CanvasGradient_(aType) {
	    this.type_ = aType;
	    this.x0_ = 0;
	    this.y0_ = 0;
	    this.r0_ = 0;
	    this.x1_ = 0;
	    this.y1_ = 0;
	    this.r1_ = 0;
	    this.colors_ = [];
	  }
	
	  CanvasGradient_.prototype.addColorStop = function(aOffset, aColor) {
	    aColor = processStyle(aColor);
	    this.colors_.push({offset: aOffset,
	                       color: aColor.color,
	                       alpha: aColor.alpha});
	  };
	
	  function CanvasPattern_(image, repetition) {
	    assertImageIsValid(image);
	    switch (repetition) {
	      case 'repeat':
	      case null:
	      case '':
	        this.repetition_ = 'repeat';
	        break
	      case 'repeat-x':
	      case 'repeat-y':
	      case 'no-repeat':
	        this.repetition_ = repetition;
	        break;
	      default:
	        throwException('SYNTAX_ERR');
	    }
	
	    this.src_ = image.src;
	    this.width_ = image.width;
	    this.height_ = image.height;
	  }
	
	  function throwException(s) {
	    throw new DOMException_(s);
	  }
	
	  function assertImageIsValid(img) {
	    if (!img || img.nodeType != 1 || img.tagName != 'IMG') {
	      throwException('TYPE_MISMATCH_ERR');
	    }
	    if (img.readyState != 'complete') {
	      throwException('INVALID_STATE_ERR');
	    }
	  }
	
	  function DOMException_(s) {
	    this.code = this[s];
	    this.message = s +': DOM Exception ' + this.code;
	  }
	  var p = DOMException_.prototype = new Error;
	  p.INDEX_SIZE_ERR = 1;
	  p.DOMSTRING_SIZE_ERR = 2;
	  p.HIERARCHY_REQUEST_ERR = 3;
	  p.WRONG_DOCUMENT_ERR = 4;
	  p.INVALID_CHARACTER_ERR = 5;
	  p.NO_DATA_ALLOWED_ERR = 6;
	  p.NO_MODIFICATION_ALLOWED_ERR = 7;
	  p.NOT_FOUND_ERR = 8;
	  p.NOT_SUPPORTED_ERR = 9;
	  p.INUSE_ATTRIBUTE_ERR = 10;
	  p.INVALID_STATE_ERR = 11;
	  p.SYNTAX_ERR = 12;
	  p.INVALID_MODIFICATION_ERR = 13;
	  p.NAMESPACE_ERR = 14;
	  p.INVALID_ACCESS_ERR = 15;
	  p.VALIDATION_ERR = 16;
	  p.TYPE_MISMATCH_ERR = 17;
	
	  // set up externs
	  G_vmlCanvasManager = G_vmlCanvasManager_;
	  CanvasRenderingContext2D = CanvasRenderingContext2D_;
	  CanvasGradient = CanvasGradient_;
	  CanvasPattern = CanvasPattern_;
	  DOMException = DOMException_;
	})();
	
	} // if

/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	/*绘制mobi分时图*/
	var ChartTime = __webpack_require__(4);
	/*绘制mobiK线图*/
	var ChartK = __webpack_require__(18);
	/*绘制折线图*/
	var ChartLine = __webpack_require__(26);
	/*绘制折线图*/
	var ChartLineRate = __webpack_require__(29);
	/*绘制季度柱状图*/
	var ChartBarQuarter = __webpack_require__(33);
	/*绘制季度折线图*/
	var ChartLineQuarter = __webpack_require__(36);
	/*绘制web分时图*/
	var ChartWebTime = __webpack_require__(38);
	/*绘制web的K线图*/
	var ChartWebK = __webpack_require__(46);
	/*加载样式文件*/
	__webpack_require__(67);
	
	window.EmchartsMobileTime = ChartTime;
	window.EmchartsMobileK = ChartK;
	window.EmchartsMobileLine = ChartLine;
	window.EmchartsWebBarQuarter = ChartBarQuarter;
	window.EmchartsWebLineQuarter = ChartLineQuarter;
	window.EmchartsWebLineRate = ChartLineRate;
	window.EmchartsWebTime = ChartWebTime;
	window.EmchartsWebK = ChartWebK;


/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制手机分时图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	// 绘制坐标轴
	var DrawXY = __webpack_require__(5);
	// 主题
	var theme = __webpack_require__(7);
	var common = __webpack_require__(8); 
	// 获取分时图数据
	var GetDataTime = __webpack_require__(9); 
	// 绘制分时折线图
	var DrawLine = __webpack_require__(13); 
	// 绘制分时折线图中的平均线
	var DrawAvgCost = __webpack_require__(14); 
	// 绘制成交量图
	var DrawV = __webpack_require__(15);
	// 工具
	var common = __webpack_require__(8); 
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 交互效果
	var Interactive = __webpack_require__(16); 
	// 水印
	var watermark = __webpack_require__(17);
	
	var ChartTime = (function() {
	
	    // 构造函数
	    function ChartTime(options) {
	        this.defaultoptions = theme.chartTime;
	        this.options = {};
	        // this.options = extend(this.defaultoptions, options);
	        extend(true, this.options, theme.defaulttheme, this.defaultoptions, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.onChartLoaded = options.onChartLoaded == undefined ? function(op){
	
	        }:options.onChartLoaded;
	        
	    }
	
	    // 初始化
	    ChartTime.prototype.init = function() {
	
	        this.options.type = "TL";
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        // this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable","on");
	        this.container.style.position = "relative";
	        // 画布
	        var ctx = canvas.getContext('2d');
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr;
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / 8;
	        // 画布内容向坐偏移的距离
	        this.options.padding_left = theme.defaulttheme.padding_left * dpr;
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / 8;
	        // 缩放默认值
	        this.options.scale_count = 0;
	        // 画布上第一个图表的高度
	        this.options.c_1_height = canvas.height * 0.5;
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0",this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr + 0.5;
	        
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	        
	    };
	
	    // 绘图
	    ChartTime.prototype.draw = function(callback) {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        // 初始化交互
	        var inter = this.options.interactive = new Interactive(this.options);
	        // 显示loading效果
	        inter.showLoading();
	        var _this = this;
	        try{
	            
	            GetDataTime(this.options.code,
	                function(data){
	                    if(data){
	                        dataCallback.apply(_this,[data]);
	                    }else{
	                        dataCallback.apply(_this,[[]]);
	                    }
	                    /*绑定事件*/
	                    bindEvent.call(_this,_this.options.context);
	                    // 传入的回调函数
	                    if(callback){
	                        callback();
	                    }
	                    
	                },inter);
	
	        }catch(e){
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	    };
	    // 重绘
	    ChartTime.prototype.reDraw = function() {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        dataCallback.call(this);
	    }
	    /*删除canvas画布*/
	    ChartTime.prototype.clear = function(cb) {
	        if(this.container){
	            this.container.innerHTML = "";
	        }else{
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	    /*回调函数*/
	    function dataCallback(data){
	
	        this.options.data = data == null ? this.options.data : data;
	
	        // 图表交互
	        var inter = this.options.interactive;
	
	        try{
	
	            // 保留的小数位
	            this.options.pricedigit = data.pricedigit || 2;
	            // 获取单位绘制区域
	            var rect_unit = common.get_rect.apply(this,[this.options.context.canvas,this.options.data.total]);
	            this.options.rect_unit = rect_unit;
	
	            // 绘制坐标轴
	            new DrawXY(this.options);
	
	            if(data && data.data && data.data.length > 0){
	                // 绘制分时折线图
	                new DrawLine(this.options);
	                // 绘制分时折线图平均线
	                new DrawAvgCost(this.options);
	            }
	            
	            // 绘制分时图成交量
	            new DrawV(this.options);
	            // 隐藏loading效果
	            inter.hideLoading();
	            // 图表加载完成时间
	            this.onChartLoaded(this);
	
	        }catch(e){
	            // 暂无数据
	            // inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	        // 加水印
	        watermark.apply(this,[this.options.context,170,20 - this.options.canvas.height / 8]);
	
	        return true;
	    }
	
	    // 绑定事件
	    function bindEvent(ctx){
	        var _this = this;
	        var timer_s,timer_m;
	        var canvas = ctx.canvas;
	        var inter = this.options.interactive;
	
	        var delayed = false;
	        var delaytouch = this.options.delaytouch = true;;
	
	        // 触摸事件
	        canvas.addEventListener("touchstart",function(event){
	            // 显示交互效果
	            if(delaytouch){
	                delayed = false;
	                timer_s = setTimeout(function(){
	                    delayed = true;
	                    inter.show();
	                    dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	                    event.preventDefault();
	                },200);
	            }else{
	                inter.show();
	                dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	            }
	
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	
	        });
	        // 手指滑动事件
	        canvas.addEventListener("touchmove",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	                if(delayed){
	                    dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	                    event.preventDefault();
	                }
	            }else{
	                dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	            }
	            
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	
	        });
	         // 手指离开事件
	        canvas.addEventListener("touchend",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	            }
	            // 隐藏交互效果
	            inter.hide();
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	
	        });
	
	        canvas.addEventListener("touchcancel",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	                // delay.style.display = "none";
	            }
	            // 隐藏交互效果
	            inter.hide();
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	        });
	
	
	        // if(!delaytouch){
	            canvas.addEventListener("mousemove",function(event){
	                //console.info(event);
	                dealEvent.apply(_this,[inter,event]);
	                event.preventDefault();
	            });
	
	            canvas.addEventListener("mouseleave",function(event){
	                //console.info(event);
	                inter.hide();
	                event.preventDefault();
	            });
	
	            canvas.addEventListener("mouseenter",function(event){
	                //console.info(event);
	                dealEvent.apply(_this,[inter,event]);
	                inter.show();
	                event.preventDefault();
	            });
	
	        // }
	        
	    }
	    // 处理交互事件
	    function dealEvent(inter,eventposition){
	        // 画布对象
	        var canvas = this.options.canvas;
	        // 分时行情数据
	        var time_data = this.options.data.data;
	        // 单位绘制区域
	        var rect_unit = this.options.rect_unit;
	        // 单位绘图区域的宽度
	        var rect_w = rect_unit.rect_w;
	        // K线柱体的宽度
	        // var bar_w = rect_unit.bar_w;
	
	        // 鼠标事件位置
	        var w_x = eventposition.offsetX || (eventposition.clientX - this.container.getBoundingClientRect().left);
	        var w_y = eventposition.offsetY || (eventposition.clientY - this.container.getBoundingClientRect().top);
	
	        // 鼠标在画布中的坐标
	        var c_pos = common.windowToCanvas.apply(this,[canvas,w_x,w_y]);
	        var c_x = (c_pos.x).toFixed(0);
	        // var c_y = (c_pos.y).toFixed(0);
	
	        // 当前点在数组中的下标
	        var index = Math.floor((c_x - this.options.padding_left)/rect_w);
	
	        if(time_data[index]){
	            // Tip显示行情数据
	            inter.showTip(canvas,w_x,time_data[index]);
	
	            // 显示十字指示线的
	            var cross = common.canvasToWindow.apply(this,[canvas,time_data[index].cross_x,time_data[index].cross_y]);
	            var cross_w_x = cross.x;
	            var cross_w_y = cross.y;
	            inter.cross(canvas,cross_w_x,cross_w_y);
	        }
	
	    }
	
	    return ChartTime;
	})();
	
	module.exports = ChartTime;


/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制直角坐标系
	 */
	var extend = __webpack_require__(6);
	/*主题*/
	var theme = __webpack_require__(7);
	var DrawXY = (function(){
	    //构造方法
	    function DrawXY(options){
	        /*设置默认参数*/
	        this.defaultoptions = theme.draw_xy;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
	    };
	    /*绘图*/
	    DrawXY.prototype.draw = function(){
	        var data = this.options.data;
	        var ctx = this.options.context;
	        var type = this.options.type;
	        // var dpr = this.options.dpr;
	
	        /*Y轴上的最大值*/
	        var y_max = data.max;
	        /*Y轴上的最小值*/
	        var y_min = data.min;
	
	        /*Y轴上分隔线数量*/
	        var sepe_num = this.options.sepe_num;
	        /*开盘收盘时间数组*/
	        var oc_time_arr = data.timeStrs;
	
	        /*K线图的高度*/
	        var k_height = this.options.c_1_height;
	        /*Y轴标识线列表*/
	        var line_list_array = getLineList(y_max, y_min, sepe_num, k_height);
	
	        if(type == "TL"){
	            drawXYTime.call(this,ctx,y_max,y_min,line_list_array);
	        }else{
	            drawXYK.apply(this,[ctx,y_max,y_min,line_list_array]);
	        }
	
	        // 绘制横坐标刻度
	        if(oc_time_arr){
	            drawXMark.apply(this,[ctx,k_height,oc_time_arr]);
	        }
	        
	    };
	    // 绘制分时图坐标轴
	    function drawXYTime(ctx,y_max,y_min,line_list_array){
	        var _this = this;
	        var sepe_num = line_list_array.length;
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	
	            if (i < (sepe_num -1) / 2) {
	                ctx.fillStyle = '#007F24';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	            else if(i > (sepe_num -1) / 2){
	                ctx.fillStyle = '#FF0A16';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	            else{
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = '#cadef8';
	            }
	
	            ctx.moveTo(0, Math.round(item.y));
	            ctx.lineTo(ctx.canvas.width, Math.round(item.y));
	            // 绘制纵坐标刻度
	            if(isNaN(item.num)){
	                ctx.fillText("0.00", 0, item.y - 10);
	            }else{
	                ctx.fillText((item.num).toFixed(this.options.pricedigit), 0, item.y - 10);
	            }
	
	            ctx.stroke();
	            // 绘制纵坐标涨跌幅
	            drawYPercent.call(_this,ctx,y_max, y_min, item);
	        }
	
	    }
	    //绘制K线图坐标轴
	    function drawXYK(ctx,y_max,y_min,line_list_array){
	        var sepe_num = line_list_array.length;
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	
	            if (i < (sepe_num -1) / 2) {
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	            else if(i > (sepe_num -1) / 2){
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	            else{
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            }
	
	            
	            ctx.moveTo(0, Math.round(item.y));
	            ctx.lineTo(ctx.canvas.width, Math.round(item.y));
	            // 绘制纵坐标刻度
	            if(isNaN(item.num)){
	                ctx.fillText("0.00", 0, item.y - 10);
	            }else{
	                ctx.fillText((item.num).toFixed(this.options.pricedigit), 0, item.y - 10);
	            }
	            ctx.stroke();
	        }
	
	    }
	    /*绘制纵坐标涨跌幅*/
	    function drawYPercent(ctx,y_max, y_min, obj){
	        /*纵坐标中间值*/
	        var y_middle = (y_max + y_min)/2;
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        /*纵坐标刻度涨跌幅*/
	        if(y_middle){
	            var percent = ((obj.num - y_middle)/y_middle * 100).toFixed(2) + "%";
	        }else{
	            var percent = "0.00%";
	        }
	        /*绘制纵坐标刻度百分比*/
	        ctx.fillText(percent, k_width - ctx.measureText(percent).width, obj.y - 10);
	        ctx.stroke();
	    }
	    /*绘制横坐标刻度值*/
	    function drawXMark(ctx,k_height,oc_time_arr){
	        // var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        ctx.beginPath();
	        ctx.fillStyle = '#999';
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        var y_date = k_height + ctx.canvas.height/8/2;
	
	        ctx.fillText(oc_time_arr[0], padding_left, y_date);
	        ctx.fillText(oc_time_arr[1], (k_width-padding_left)/2 + padding_left - ctx.measureText(oc_time_arr[1]).width/2, y_date);
	        ctx.fillText(oc_time_arr[2], k_width - ctx.measureText(oc_time_arr[2]).width, y_date);
	        // ctx.moveTo(0,k_height + 10);
	    }
	    /*Y轴标识线列表*/
	    function getLineList(y_max, y_min, sepe_num, k_height) {
	        var ratio = (y_max - y_min) / (sepe_num-1);
	        var result = [];
	        for (var i = 0; i < sepe_num; i++) {
	            result.push({
	                num:  (y_min + i * ratio),
	                x: 0,
	                y: k_height - (i / (sepe_num-1)) * k_height
	            });
	        }
	        return result;
	    }
	    return DrawXY;
	})();
	
	module.exports = DrawXY;

/***/ },
/* 6 */
/***/ function(module, exports) {

	var hasOwn = Object.prototype.hasOwnProperty;
	var toStr = Object.prototype.toString;
	
	var isArray = function isArray(arr) {
		if (typeof Array.isArray === 'function') {
			return Array.isArray(arr);
		}
	
		return toStr.call(arr) === '[object Array]';
	};
	
	var isPlainObject = function isPlainObject(obj) {
		if (!obj || toStr.call(obj) !== '[object Object]') {
			return false;
		}
	
		var hasOwnConstructor = hasOwn.call(obj, 'constructor');
		var hasIsPrototypeOf = obj.constructor && obj.constructor.prototype && hasOwn.call(obj.constructor.prototype, 'isPrototypeOf');
		// Not own constructor property must be Object
		if (obj.constructor && !hasOwnConstructor && !hasIsPrototypeOf) {
			return false;
		}
	
		// Own properties are enumerated firstly, so to speed up,
		// if last one is own, then all properties are own.
		var key;
		for (key in obj) { /**/ }
	
		return typeof key === 'undefined' || hasOwn.call(obj, key);
	};
	
	module.exports = function extend() {
		var options, name, src, copy, copyIsArray, clone;
		var target = arguments[0];
		var i = 1;
		var length = arguments.length;
		var deep = false;
	
		// Handle a deep copy situation
		if (typeof target === 'boolean') {
			deep = target;
			target = arguments[1] || {};
			// skip the boolean and the target
			i = 2;
		} else if ((typeof target !== 'object' && typeof target !== 'function') || target == null) {
			target = {};
		}
	
		for (; i < length; ++i) {
			options = arguments[i];
			// Only deal with non-null/undefined values
			if (options != null) {
				// Extend the base object
				for (name in options) {
					src = target[name];
					copy = options[name];
	
					// Prevent never-ending loop
					if (target !== copy) {
						// Recurse if we're merging plain objects or arrays
						if (deep && copy && (isPlainObject(copy) || (copyIsArray = isArray(copy)))) {
							if (copyIsArray) {
								copyIsArray = false;
								clone = src && isArray(src) ? src : [];
							} else {
								clone = src && isPlainObject(src) ? src : {};
							}
	
							// Never move original objects, clone them
							target[name] = extend(deep, clone, copy);
	
						// Don't bring in undefined values
						} else if (typeof copy !== 'undefined') {
							target[name] = copy;
						}
					}
				}
			}
		}
	
		// Return the modified object
		return target;
	};

/***/ },
/* 7 */
/***/ function(module, exports) {

	/**
	 * 默认主题
	 */
	
	var defaultopions = {
		defaulttheme:{
			spacing:0.4, //K线柱体的间距比例，取值范围[0,1]
			padding_left:30,//画布的左内边距
			k_v_away:30,//K线图表和成交量之间的间距
			canvas_offset_top:40,//画布的上内边距
			point_width:2,
			font_size:12,//默认字体大小
			point_color:"#8f8f8f",//鼠标指示线交点颜色
			up_color:"#ff0000",
			down_color:"#17b03e"
		},
		// 分时线图表配置参数
		chartTime:{
			crossline:true
		},
		// K线图表配置参数
		chartK:{
			crossline:false
		},
		// 折线图表配置参数
		chartLine:{
	        showPoint:false,	//是否显示折线图上的节点
	        canvasPaddingTop:10, //画布的上内边距
	        canvasPaddingLeft:20, //画布的左内边距
	        pointRadius:10,
	        lineMarkWidth:15
		},
		// 坐标轴配置参数
		draw_xy:{
	        axis_color:"#fff", //坐标轴颜色
	        y_max:100,//纵坐标最小值
	        y_min:0,//纵坐标最小值
	        sepe_num:5, 	//沿Y轴平均分割线的个数
	        y_padding_per:0.05, //画布上线内间距占(y_max - y_min)的比例
	        date_offset_top:15//横坐标轴上的日期刻度
		},
		// web的坐标轴配置参数
		draw_xy_web:{
			spacing:0.4, //K线柱体的间距比例，取值范围[0,1]
			padding_left:30,//画布的左内边距
			k_v_away:30,//K线图表和成交量之间的间距
			canvas_offset_top:40,//画布的上内边距
			point_width:5,
			font_size:12,//默认字体大小
			point_color:"#8f8f8f",//鼠标指示线交点颜色
			up_color:"#ff0000",
			down_color:"#17b03e",
	        axis_color:"#fff", //坐标轴颜色
	        y_max:100,//纵坐标最小值
	        y_min:0,//纵坐标最小值
	        sepe_num:9, 	//沿Y轴平均分割线的个数
	        y_padding_per:0.05, //画布上线内间距占(y_max - y_min)的比例
	        date_offset_top:15,//横坐标轴上的日期刻度
	        crossline:true
		},
		// 分时图配置参数
		draw_line:{
	     	avg_cost_color:"#f1ca15"   //平均线的颜色
		},
		draw_k:{
	        
		},
		draw_ma:{
	        
		},
		// 成交量配置参数
		draw_v:{
	        
		},
		// 图表交互
		interactive:{
	
		}
	};
	
	module.exports = defaultopions;

/***/ },
/* 8 */
/***/ function(module, exports) {

	var common = {
	    // 由股票代码判断股票上市场所，1(沪市)或2(深市)或5(港股)
	    getMktByCode: function(code) {
	        if (code.Length < 3)
	            return code + "1";
	        var one = code.substr(0, 1);
	        var three = code.substr(0, 3);
	        if (one == "5" || one == "6" || one == "9") {
	            return code + "1";
	        } else {
	            if (three == "009" || three == "126" || three == "110" || three == "201" || three == "202" || three == "203" || three == "204") {
	                return code + "1";
	            } else {
	                return code + "2";
	            }
	        }   
	    },
	    // 数字标准化，字符串输出，例如：9----->09
	    fixed: function(str, len) {
	        var i = 0;
	        str = str.toString();
	        var result = str;
	        for (i = 0; i < len - str.length; i++) {
	            result = '0' + result;
	        }
	
	        return result;
	    },
	    // 日期标准化，字符串输出，例如: 20121112---->2012-11-12
	    transform: function(str) {
	        return str.replace(/(\d{4})(\d{2})(\d{2})/g, function(whole, a, b, c) {
	            return a + "-" + b + "-" + c;
	        });
	    },
	    // 将鼠标坐标转换为Canvas坐标
	    windowToCanvas: function(canvas,x,y){
	        // var box = canvas.getBoundingClientRect();
	        return {
	            // x:(x-box.left)*(canvas.width/box.width),
	            // y:(y-box.top)*(canvas.height/box.height)
	
	            x: x*this.options.dpr,
	            y: y*this.options.dpr
	        };
	    },
	    // 将Canvas坐标转换为鼠标坐标
	    canvasToWindow: function(canvas,x,y){
	        var box = canvas.getBoundingClientRect();
	        // 相对于窗口
	        // return {
	        //     x:(x *(box.width/canvas.width)+box.left),
	        //     y:(y *(box.height/canvas.height)+box.top + this.options.canvas_offset_top/this.options.dpr)
	        // };
	        return {
	            x:x/this.options.dpr,
	            // x:x * (box.width/canvas.width),
	            y:(y+this.options.canvas_offset_top) * (box.height/canvas.height)
	        };
	    },
	    // 图表y轴坐标计算
	    get_y: function(y) {
	        return this.options.c_1_height - (this.options.c_1_height * (y - this.options.data.min)/(this.options.data.max - this.options.data.min));
	    },
	    // 图表x轴坐标计算
	    get_x: function(x) {
	        var canvas = this.options.context.canvas;
	        var type = this.options.type;
	        var rect_w = this.options.rect_unit.rect_w;
	        var num = this.options.data.data.length;
	        var total = this.options.data.total;
	        var padding_left = this.options.padding_left;
	        // var dpr = this.options.dpr;
	
	        if(type == "TL"){
	            return (canvas.width-padding_left) / total * x + padding_left;
	        }else{
	            return (canvas.width-padding_left) / num * x + padding_left - (rect_w/2);
	        }
	        
	    },
	    // 图表x轴坐标计算
	    get_rect: function(canvas,num) {
	        var rect_w = (canvas.width-this.options.padding_left) / num;
	        var bar_w = rect_w * (1 - this.options.spacing);
	        return {
	            rect_w:rect_w,
	            bar_w:bar_w
	        };
	    },
	    // 格式化数据单位
	    format_unit: function(value,num){
	        num = num == undefined ? 2 : num;
	        var flag = false;
	        if(value < 0){
	            value = Math.abs(value);
	            flag = true;
	        }
	
	        if(flag){
	            if (value < 10000) {
	                return value * -1;
	            } else if (value >= 10000 && value < 100000000) {
	                return (value / 10000).toFixed(num) * -1 + "万";
	            } else if (value >= 100000000) {
	                return (value / 100000000).toFixed(num) * -1 + "亿";
	            } else {
	                return value * -1;
	            }
	
	        }else{
	            if (value < 10000) {
	                return value;
	            } else if (value >= 10000 && value < 100000000) {
	                return (value / 10000).toFixed(num) + "万";
	            } else if (value >= 100000000) {
	                return (value / 100000000).toFixed(num) + "亿";
	            } else {
	                return value;
	            }
	        }
	    },
	    /**
	     * 兼容性的事件添加
	     * @param {[type]}   obj  对哪个元素添加
	     * @param {[type]}   type 事件类型
	     * @param {Function} fn   事件触发的处理函数
	     */
	    addEvent: function(obj, type, fn) {
	        if (obj.attachEvent) {
	            obj['e' + type + fn] = fn;
	            obj[type + fn] = function() { obj['e' + type + fn](window.event); }
	            obj.attachEvent('on' + type, obj[type + fn]);
	        } else
	            obj.addEventListener(type, fn, false);
	    },
	    removeEvent: function(obj, type, fn) {
	        if (obj.detachEvent) {
	            obj.detachEvent('on' + type, obj[type + fn]);
	            obj[type + fn] = null;
	        } else
	            obj.removeEventListener(type, fn, false);
	    }
	
	};
	module.exports = common;


/***/ },
/* 9 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获取手机分时图数据
	 * 返回数据对象
	 *   result{
	 *      name://股票名字
	 *      data: [//当前各个时间点
	 *          {   //一个对象代表一个点
	 *              price:价格：45.50
	 *              time:时间: 10:00
	 *              volume:换手数 12000
	 *              percent:涨跌百分比 -8.9%
	 *              up:涨跌标志: false(跌)
	 *              isCR:false(不包含盘前数据),true(包含盘前数据)
	 *          }   
	 *      ]
	 *      v_max: //最大成交量
	 *      max://坐标最大值
	 *      min://坐标最小值
	 *      yc://昨收
	 *   }
	 */
	
	var dealdata = __webpack_require__(10); //处理数据
	var coordinate = __webpack_require__(11); //处理数据
	var fix = __webpack_require__(8).fixed;
	
	var jsonp = __webpack_require__(12);
	
	
	function getdata(id, callback, interactive) {
	
	    var url = 'http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js';
	    var callbackstring = 'fsdata';
	    var urldata = {
	        id: id,
	        TYPE: 'R',
	        js: callbackstring + '((x))',
	        'rtntype': 5,
	        isCR :false
	    };
	    jsonp(url, urldata, callbackstring, function(json) {
	        try{
	            if (!json) {
	                callback(null);
	            } else {
	                //拿到股票的数据
	                var info = json.info;
	                // var dataArray = json.data;
	                var ticks = info.ticks.split('|');
	
	                // 保留小数位
	                if(info.pricedigit.split(".").length > 1){
	                    window.pricedigit = info.pricedigit.split(".")[1].length == 0 ? 2 : info.pricedigit.split(".")[1].length;
	                }else{
	                    window.pricedigit = 0;
	                }
	
	                var result = {};
	
	                //股票名称
	                result.name = json.name;
	                //总比数
	                result.total = info.total;
	
	                var returnData = dealdata(json, info.yc)
	                //股票数据
	                result.data = returnData[0];
	
	                //最下面的时间
	                result.timeStrs = [];
	                var morning_start_hour = Math.floor(ticks[0] / 3600) > 24 ? (Math.floor(ticks[0] / 3600) - 24) : Math.floor(ticks[0] / 3600);
	
	                result.timeStrs.push(fix(morning_start_hour, 2) + ":" + fix((ticks[0] / 60) % 60, 2));
	
	                var morning_end_hour = Math.floor(ticks[4] / 3600) > 24 ? (Math.floor(ticks[4] / 3600) - 24) : Math.floor(ticks[4] / 3600);
	
	                if(ticks.length <= 5){
	                    result.timeStrs.push("");
	                }else{
	                    var afternoon_start_hour = Math.floor(ticks[5] / 3600) > 24 ? (Math.floor(ticks[5] / 3600) - 24) : Math.floor(ticks[5] / 3600);
	                    result.timeStrs.push(fix(morning_end_hour, 2) + ":" + fix((ticks[4] / 60) % 60, 2) + " / " + fix(afternoon_start_hour) + ":" + fix((ticks[5] / 60) % 60, 2));
	                }
	                
	                var afternoon_end_hour = Math.floor(ticks[1] / 3600) > 24 ? (Math.floor(ticks[1] / 3600) - 24) : Math.floor(ticks[1] / 3600);
	                result.timeStrs.push(fix(afternoon_end_hour, 2) + ":" + fix((ticks[1] / 60) % 60, 2));
	                //坐标的最大最小值
	                result.max = coordinate(returnData[1], returnData[2], info.yc).max;
	                //坐标的最小值
	                result.min = coordinate(returnData[1], returnData[2], info.yc).min;
	                //昨收
	                result.yc = info.yc;
	
	                // 保留小数位
	                result.pricedigit = window.pricedigit;
	
	                callback(result);
	            }
	
	        }catch(e){
	            // 暂无数据
	            interactive.showNoData();
	            // 隐藏loading效果
	            interactive.hideLoading();
	        }
	
	    });
	}
	
	module.exports = getdata;


/***/ },
/* 10 */
/***/ function(module, exports) {

	/**
	 * [dealData description]
	 * @return [
	 *         data1:{
	 *         		价格：price
	 *         		时间:time
	 *         		换手数:volume
	 *         		涨跌百分比: percent
	 *         		涨跌标志:up?
	 *              平均成本：avg_cost
	 *              成交量最大值：v_max
	 *         }]
	 * 
	 */
	var dealData = function(json, yc) {
	    // var info = json.info;
	    var arryData = json.data;
		var result = [];
	    var v_max = 0;
	    var max = 0;
	    var min = 0;
	    var total_cost = 0;//成交总额
	    var total_num = 0;//成交总量
	
	    for (var i = 0; i < arryData.length; i++) {
	        var items = arryData[i].split(",");
	        v_max = v_max > Number(items[2])? v_max: Number(items[2]);
	
	        if(i == 0){
	            max = min = Number(items[1]);
	        }
	
	        // if(items[1] >= items[3]){
	        //     var _max = items[1];
	        //     var _min = items[3];
	        // }else{
	        //     var _min = items[1];
	        //     var _max = items[3];
	        // }
	        
	        max = Math.max(max,items[1]);
	        min = Math.min(min,items[1]);
	
	        var point = {};
	        point.time = items[0].split(" ")[1];
	        point.price = items[1];
	      
	        point.volume = Number((Number(items[2])).toFixed(0));
	        //计算平均成本
	        // total_num += Number(items[2]);
	        // total_cost += Number(items[2])*parseFloat(items[1]);
	        // point.avg_cost = parseFloat((total_cost/total_num).toFixed(pricedigit));
	        point.avg_cost = items[3];
	
	        if (i != 0) {
	            // point.percent = ((items[1] - arryData[i - 1].split(',')[1]) / items[1] * 100).toFixed(2);
	            point.percent = ((items[1] - yc) / yc * 100).toFixed(2);
	            // point.up = items[1] - arryData[i - 1].split(',')[1] > 0 ? true : false;
	            point.up = items[1] - yc > 0 ? true : false;
	        }else{
	        	point.percent = ((items[1] - yc) / yc * 100).toFixed(2);
	        	point.up = items[1] - yc > 0 ? true : false;
	        }
	        result.push(point);
	    }
	    result.v_max = Number((v_max).toFixed(0));
	
	    return [result, max, min];
	};
	
	module.exports = dealData;


/***/ },
/* 11 */
/***/ function(module, exports) {

	/**
	 * 分时图坐标上下限算法
	 */
	
	/*
	1.遍历出当前价的最高(high),最低点(low)
	2.和昨收(pre)价进行比较
		Math.Abs(pre-high)   
		Math.Abs(pre-low)  
			取两个中比较大的值 设为offset
				top=pre+offset*1.05;
				fall=pre-offset*1.05;
		
		同时满足如果fall<=0则为fall=0
		如果high==low==pre则
			top=pre*1.08
			fall=pre*0.92
	
		如果pre==0 则top==fall==0
	 */
	
	/**
	 * 分时图坐标上下限
	 * @param  {[type]} high 最高
	 * @param  {[type]} low 最低
	 * @param  {[type]} pre  昨收
	 */
	function coordinate(high, low, pre) {
		var top = 0;
		var fall = 0;
		var offset = Math.max(Math.abs(pre - high), Math.abs(pre - low));
	
		top = Number(pre) + offset * 1.05;
		fall = Number(pre) - offset * 1.05;
		if ( fall <= 0 ) {
			fall = 0;
		}
		if ( high == low && low == pre ) {
			top = pre * 1.08;
			fall = pre * 0.92;
		}
		if ( pre == 0 ) {
			top = 0;
			fall = 0;
		}
	
		return { max: top, min: fall };
	}
	
	module.exports = coordinate;

/***/ },
/* 12 */
/***/ function(module, exports) {

	/**
	 * jsonp
	 * 使用说明 jsonp([uri], [data], [custom_method_name], [callback(json)])
	 */
	
	/**
	 * JSONP sets up and allows you to execute a JSONP request
	 * @param {String} url  The URL you are requesting with the JSON data
	 * @param {Object} data The Data object you want to generate the URL params from
	 * @param {String} method  The method name for the callback function. Defaults to callback (for example, flickr's is "jsoncallback")
	 * @param {Function} callback  The callback you want to execute as an anonymous function. The first parameter of the anonymous callback function is the JSON
	 *
	 * @example
	 * JSONP('http://twitter.com/users/oscargodson.json',function(json){
	 *  document.getElementById('avatar').innerHTML = '<p>Twitter Pic:</p><img src="'+json.profile_image_url+'">';
	 * });
	 *
	 * @example
	 * JSONP('http://api.flickr.com/services/feeds/photos_public.gne',{'id':'12389944@N03','format':'json'},'jsoncallback',function(json){
	 *  document.getElementById('flickrPic').innerHTML = '<p>Flickr Pic:</p><img src="'+json.items[0].media.m+'">';
	 * });
	 *
	 * @example
	 * JSONP('http://graph.facebook.com/FacebookDevelopers', 'callback', function(json){
	 *  document.getElementById('facebook').innerHTML = json.about;
	 * });
	 */
	
	  var JSONP = function(url,data,method,callback){
	    //Set the defaults
	    url = url || '';
	    data = data || {};
	    method = method || '';
	    callback = callback || function(){};
	    
	    //Gets all the keys that belong
	    //to an object
	    var getKeys = function(obj){
	      var keys = [];
	      for(var key in obj){
	        if (obj.hasOwnProperty(key)) {
	          keys.push(key);
	        }
	        
	      }
	      return keys;
	    }
	
	    //Turn the data object into a query string.
	    //Add check to see if the second parameter is indeed
	    //a data object. If not, keep the default behaviour
	    if(typeof data == 'object'){
	      var queryString = '';
	      var keys = getKeys(data);
	      for(var i = 0; i < keys.length; i++){
	        queryString += encodeURIComponent(keys[i]) + '=' + encodeURIComponent(data[keys[i]])
	        if(i != keys.length - 1){ 
	          queryString += '&';
	        }
	      }
	      url += '?' + queryString;
	    } else if(typeof data == 'function'){
	      method = data;
	      callback = method;
	    }
	
	    //If no method was set and they used the callback param in place of
	    //the method param instead, we say method is callback and set a
	    //default method of "callback"
	    if(typeof method == 'function'){
	      callback = method;
	      method = 'callback';
	    }
	  
	    //Check to see if we have Date.now available, if not shim it for older browsers
	    if(!Date.now){
	      Date.now = function() { return new Date().getTime(); };
	    }
	
	    //Use timestamp + a random factor to account for a lot of requests in a short time
	    //e.g. jsonp1394571775161 
	    var timestamp = Date.now();
	    var generatedFunction = 'jsonp'+Math.round(timestamp+Math.random()*1000001);
	    if (typeof method == 'string') {
	    	generatedFunction = method;
	    }
	
	    //Generate the temp JSONP function using the name above
	    //First, call the function the user defined in the callback param [callback(json)]
	    //Then delete the generated function from the window [delete window[generatedFunction]]
	    window[generatedFunction] = function(json){
	      callback(json);
	
	      // IE8 throws an exception when you try to delete a property on window
	      // http://stackoverflow.com/a/1824228/751089
	      try {
	        document.getElementsByTagName("head")[0].removeChild(jsonpScript);
	        delete window[generatedFunction];
	      } catch(e) {
	        window[generatedFunction] = undefined;
	      }
	
	    };
	
	    //Check if the user set their own params, and if not add a ? to start a list of params
	    //If in fact they did we add a & to add onto the params
	    //example1: url = http://url.com THEN http://url.com?callback=X
	    //example2: url = http://url.com?example=param THEN http://url.com?example=param&callback=X
	    if(url.indexOf('?') === -1){ url = url+'?'; }
	    else{ url = url+'&'; }
	  
	    //This generates the <script> tag
	    var jsonpScript = document.createElement('script');
	    jsonpScript.setAttribute("src", url+method+'='+generatedFunction);
	    document.getElementsByTagName("head")[0].appendChild(jsonpScript)
	  }
	 module.exports = JSONP;


/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制K线
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	/*继承*/
	var extend = __webpack_require__(6);
	/*主题*/
	var theme = __webpack_require__(7);
	/*工具*/
	var common = __webpack_require__(8);
	var DrawLine = (function(){
		function DrawLine(options){
			/*设置默认参数*/
	        this.defaultoptions = theme.draw_line;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
		};
		
		/*绘图*/
		DrawLine.prototype.draw = function(){
	
			var ctx = this.options.context;
			var data = this.options.data;
			var data_arr = data.data;
			
			drawStroke.apply(this,[ctx,data_arr]);
			drawFill.apply(this,[ctx,data_arr]);
		};
		/*绘制分时线*/
		function drawStroke(ctx,data_arr){
			ctx.beginPath();
		 	
			// ctx.strokeStyle = "rgba(0,0,0,0)";
			ctx.strokeStyle = "#3f88e5";
			
			// var data_arr_length = data_arr.length;
			for(var i = 0,item;item = data_arr[i]; i++){
				 var x = common.get_x.call(this,i + 1);
				 var y = common.get_y.call(this,item.price);
			 	 ctx.lineTo(x,y);
				 item.cross_x = x;
				 item.cross_y = y;
			}
			ctx.stroke();
		}
		/*分时线填充渐变色*/
		function drawFill(ctx,data_arr){
			var y_min = common.get_y.call(this,this.options.data.min);
			/* 指定渐变区域 */
	        var grad  = ctx.createLinearGradient(0,0,0,ctx.canvas.height);
	        /* 指定几个颜色 */
	        grad.addColorStop(0,'rgba(221,234,250,0.7)');
	        grad.addColorStop(1,'rgba(255,255,255,0)');
	        var data_arr_length = data_arr.length;
	
			ctx.beginPath();
			ctx.fillStyle = grad;
			ctx.moveTo(this.options.padding_left,y_min);
	
			for(var i = 0,item;item = data_arr[i]; i++){
				 var x = common.get_x.call(this,i + 1);
				 var y = common.get_y.call(this,item.price);
				 if(i == data_arr_length - 1){
				 	ctx.lineTo(x,y_min);
				 }else{
				 	ctx.lineTo(x,y);
				 }
			}
			ctx.fill();
		}
		return DrawLine;
	})();
	
	module.exports = DrawLine;

/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制分时图平均成本线
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 主题
	var theme = __webpack_require__(7);
	// 工具
	var common = __webpack_require__(8);
	var Draw_Avg_Cost = (function () {
		function Draw_Avg_Cost(options){
			// 设置默认参数
	        this.defaultoptions = theme.draw_line;
	        this.options = {};
	        extend(true,this.options,this.defaultoptions, options);
	        // 绘图
	        this.draw();
		}
	
		Draw_Avg_Cost.prototype.draw = function() {
			var ctx = this.options.context;
			var data = this.options.data;
			this.options.height = ctx.canvas.height * theme.defaulttheme.c_h_percent;
			// 绘制平均线
			this.draw_k(ctx,data);
		};
		// 绘制平均线
		Draw_Avg_Cost.prototype.draw_k = function(ctx,data) {
			var color = this.options.avg_cost_color;
			var data_arr = data.data;
			// var w = this.options.width - 30;
			ctx.beginPath();
			ctx.lineWidth = 1;
			ctx.strokeStyle = color;
			ctx.fillStyle = '';
			for(var i = 0;i<data_arr.length;i++) {
				var x = common.get_x.call(this,i+1);
				var y = common.get_y.call(this,data_arr[i].avg_cost);
				if(i == 0){
					ctx.moveTo(x,y);
				}
				else {
					ctx.lineTo(x,y);
				}
				
			}
			ctx.stroke();
			
		};
	
		return Draw_Avg_Cost
	})()
	
	module.exports = Draw_Avg_Cost;

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	/*继承*/
	var extend = __webpack_require__(6);
	/*工具*/
	var common = __webpack_require__(8);
	/*主题*/
	var theme = __webpack_require__(7);
	var DrawV = (function(){
		function DrawV(options){
			/*设置默认参数*/
			this.defaultoptions = theme.draw_v;
			this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
			/*绘图*/
			this.draw();
		};
		
		/*绘图*/
		DrawV.prototype.draw = function(){
			if(this.options.type == "TL") {
				/*绘制分时图成交量*/
				drawVTime.call(this);
			}else{
				/*绘制K线图成交量*/
				drawVK.call(this);
			}
			
		};
		/*绘制分时图成交量*/
		function drawVTime(){
			var ctx = this.options.context;
			var data = this.options.data;
			/*成交量数组*/
			var data_arr = data.data;
			var v_height = ctx.canvas.height / 4;
			var v_base_height = v_height * 0.9;
			var y_v_bottom = ctx.canvas.height - this.options.canvas_offset_top;
			var y_v_top = y_v_bottom - v_height;
	
			if(!data_arr || data_arr.length == 0){
				ctx.beginPath();
				ctx.fillStyle = '#999';
				ctx.strokeStyle = 'rgba(230,230,230, 1)';
				ctx.fillText(0,0,y_v_top + 10);
				ctx.rect(this.options.padding_left,y_v_top,ctx.canvas.width - this.options.padding_left -2,v_height);
				ctx.stroke();
				return;
			}
	
			if(this.options.type == "TL") {
				this.options.data.v_max = getVMax(this.options.data);
			}
	
			/*Y轴上的最大值*/
			// var y_max = data.max;
			/*Y轴上的最小值*/
			// var y_min = data.min;
			/*最大成交量*/
			var v_max = (data.v_max).toFixed(0);
			
			/*K线图表的高度*/
			// var c_1_height = this.options.c_1_height;
			//成交量图表的高度
			// var v_height = ctx.canvas.height - c_1_height - this.options.k_v_away - this.options.canvas_offset_top;
			
			/*获取单位矩形对象*/
			var rect_unit = this.options.rect_unit;
			/*单位绘图矩形画布的宽度*/
			// var rect_w = rect_unit.rect_w;
			/*K线柱体的宽度*/
			var bar_w = rect_unit.bar_w;
			/*K线柱体的颜色*/
			var up_color = this.options.up_color;
			var down_color =this.options.down_color
	
			//标识最大成交量
			markVMax.apply(this,[ctx,v_max,y_v_top]);
	
			ctx.strokeStyle = 'rgba(230,230,230, 1)';
			ctx.lineWidth = this.options.dpr;
			ctx.rect(this.options.padding_left,y_v_top,ctx.canvas.width - this.options.padding_left -2,v_height);
			ctx.stroke();
	
			ctx.lineWidth = 1;
			for(var i = 0,item; item = data_arr[i]; i++){
	
				var volume = item.volume;
				var is_up = item.up;
				var bar_height = volume/v_max * v_base_height;
				var x = common.get_x.call(this,i + 1);
				var y = y_v_bottom - bar_height;
	
				ctx.beginPath();
				ctx.moveTo(x,y);
	
				if(i == 0){
					if(is_up){
						ctx.fillStyle = up_color;
						ctx.strokeStyle = up_color;
					}else{
						ctx.fillStyle = down_color;
						ctx.strokeStyle = down_color;
					}
				}else{
					if(item.price >= data_arr[i - 1].price){
						ctx.fillStyle = up_color;
						ctx.strokeStyle = up_color;
					}else{
						ctx.fillStyle = down_color;
						ctx.strokeStyle = down_color;
					}
				}
	
				ctx.rect(x - bar_w/2,y,bar_w,bar_height);
				ctx.stroke();
				ctx.fill();
			}
	
		}
		/*绘制K线图成交量*/
		function drawVK(){
			var ctx = this.options.context;
			var data = this.options.data;
			/*成交量数组*/
			var data_arr = data.data;
			var v_height = ctx.canvas.height / 4;
			var v_base_height = v_height * 0.9;
			var y_v_bottom = ctx.canvas.height - this.options.canvas_offset_top;
			var y_v_top = y_v_bottom - v_height;
			if(!data_arr || data_arr.length == 0){
				ctx.beginPath();
				ctx.fillStyle = '#999';
				ctx.strokeStyle = 'rgba(230,230,230, 1)';
				ctx.fillText(0,0,y_v_top + 10);
				ctx.rect(this.options.padding_left,y_v_top,ctx.canvas.width - this.options.padding_left -2,v_height);
				ctx.stroke();
				return;
			}
	
	
			/*Y轴上的最大值*/
			// var y_max = data.max;
			/*Y轴上的最小值*/
			// var y_min = data.min;
			/*最大成交量*/
			var v_max = (data.v_max).toFixed(0);
			
			/*K线图表的高度*/
			// var c_1_height = this.options.c_1_height;
			//成交量图表的高度
			// var v_height = ctx.canvas.height - c_1_height - this.options.k_v_away - this.options.canvas_offset_top;
			
			/*获取单位矩形对象*/
			var rect_unit = this.options.rect_unit;
			/*单位绘图矩形画布的宽度*/
			// var rect_w = rect_unit.rect_w;
			/*K线柱体的宽度*/
			var bar_w = rect_unit.bar_w;
			/*K线柱体的颜色*/
			var up_color = this.options.up_color;
			var down_color =this.options.down_color
	
			//标识最大成交量
			markVMax.apply(this,[ctx,v_max,y_v_top]);
	
			ctx.strokeStyle = 'rgba(230,230,230, 1)';
			ctx.lineWidth = this.options.dpr;
			ctx.rect(this.options.padding_left,y_v_top,ctx.canvas.width - this.options.padding_left -2,v_height);
			ctx.stroke();
	
			ctx.lineWidth = 1;
			for(var i = 0,item; item = data_arr[i]; i++){
	
				var volume = item.volume;
				var is_up = item.up;
				var bar_height = volume/v_max * v_base_height;
				var x = common.get_x.call(this,i + 1);
				var y = y_v_bottom - bar_height;
	
				ctx.beginPath();
				ctx.moveTo(x,y);
	
				if(is_up){
					ctx.fillStyle = up_color;
					ctx.strokeStyle = up_color;
				}else{
					ctx.fillStyle = down_color;
					ctx.strokeStyle = down_color;
				}
	
				ctx.rect(x - bar_w/2,y,bar_w,bar_height);
				ctx.stroke();
				ctx.fill();
			}
	
		}
		// 标识最大成交量
		function markVMax(ctx,v_max,y_v_end){
			ctx.beginPath();
			ctx.fillStyle = '#999';
			ctx.fillText(common.format_unit(v_max),0,y_v_end + 10);
			ctx.stroke();
		}
		// 获取最大成交量
		function getVMax(data){
			if(data.data[0]){
				var max = data.data[0].volume;
			}else{
				var max = 0;
			}
			
			for(var i = 0,item = data.data;i<data.data.length;i++) {
				if(max<item[i].volume)
				{
					max=item[i].volume;
				}
			}
			return max
		}
	
		return DrawV;
	})();
	
	module.exports = DrawV;

/***/ },
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 图表交互
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 *
	 * 	   cross: 	十字指示线dom对象
	 * 	   mark_ma: 	均线标识dom对象
	 * 	   scale: 	缩放dom对象
	 * }
	 *
	 */
	
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 工具模块
	var common = __webpack_require__(8); 
	// 主题
	var theme = __webpack_require__(7);
	
	var Interactive = (function() {
	
		// 构造函数
	    function Interactive(options) {
	        this.defaultoptions = theme.interactive;
	        this.options = {};
	        this.options = extend(true,this.options,this.defaultoptions, options);
	    }
	
	  	// 鼠标十字标识线
		Interactive.prototype.cross = function(canvas,w_x,w_y){
		    var c_box = canvas.getBoundingClientRect();
		    var dpr = this.options.dpr;
	
			if(!this.options.cross){
		        this.options.cross = {};
				/*Y轴标识线*/
		        var y_line = document.createElement("div");
		        y_line.className = "cross-y";
		        y_line.style.height = c_box.height + "px";
		        y_line.style.top = "0px";
		        this.options.cross.y_line = y_line;
	
		        /*X轴标识线*/
		        var x_line = document.createElement("div");
		        x_line.className = "cross-x";
		        x_line.style.width = canvas.width/dpr + "px";
		        this.options.cross.x_line = x_line;
	
		        /*X轴和Y轴标示线相交点*/
		        var point = document.createElement("div");
		        point.className = "cross-p";
		        point.style.width = point.style.height = this.options.point_width + "px";
		        point.style.borderRadius = point.style.width;
		        point.style.backgroundColor = this.options.point_color;
		        this.options.cross.point = point;
		        /*创建文档碎片*/
		        var frag = document.createDocumentFragment();
		        
		        // if(this.options.type == "TL"){
		        if(this.options.crossline){
		        	frag.appendChild(x_line);
		        	frag.appendChild(y_line);
		        	frag.appendChild(point);
		        }else{
		        	frag.appendChild(y_line);
		        }
		     	document.getElementById(this.options.container).appendChild(frag);
		     }
		     	var y_line = this.options.cross.y_line;
			 	if(y_line){
			 		y_line.style.left = w_x + "px";
			 	}
			 	var x_line = this.options.cross.x_line;
			 	if(x_line){
			 		x_line.style.top = w_y + "px";
			 	}
			 	var point = this.options.cross.point;
			 	if(point){
			 		var p_w = this.options.point_width;
			 		point.style.left = w_x - p_w/2 + "px";
			 		point.style.top = w_y - p_w/2 + "px";
			 	}
		}
	
		// 绘制移动平均线标识
		Interactive.prototype.markMA = function (canvas,obj_5,obj_10,obj_20){
		    // var c_box = canvas.getBoundingClientRect();
		    // var dpr = this.options.dpr;
		    if(!this.options.mark_ma){
		        this.options.mark_ma = {};
		        var div_mark = document.createElement("div"); 
		        div_mark.className = "mark-ma";
		        div_mark.style.top = "5px";
		        this.options.mark_ma.mark_ma = div_mark;
		        
		        /*创建文档碎片*/
		        var frag = document.createDocumentFragment();
	
		        /*5日均线*/
		        var ma_5_data = document.createElement('span');
		        ma_5_data.className = "span-m5";
		        if(obj_5){
		            ma_5_data.innerText = "MA5: " + obj_5.value;
		        }else{
		        	if(this.default_m5){
		        		ma_5_data.innerText = "MA5: " + this.default_m5.value;
		        	}else{
		        		ma_5_data.innerText = "MA5: -";
		        	}
		        }
		        this.options.mark_ma.ma_5_data = ma_5_data;
		       
		        /*10日均线*/
		        var ma_10_data = document.createElement('span');
		        ma_10_data.id = "ma_10_data";
		        ma_10_data.className = "span-m10";
		        if(obj_10){
		            ma_10_data.innerText = "MA10: " + obj_10.value;
		        }else{
		        	if(this.default_m10){
						ma_10_data.innerText = "MA10: " + this.default_m10.value;
		        	}else{
		        		ma_10_data.innerText = "MA10: -";
		        	}
		        }
		        this.options.mark_ma.ma_10_data = ma_10_data;
	
		        /*20日均线*/
		        var ma_20_data = document.createElement('span');
		        ma_20_data.id = "ma_20_data";
		        ma_20_data.className = "span-m20";
		        if(obj_20){
		            ma_20_data.innerText = "MA20: " + obj_20.value;
		        }else{
		        	if(this.default_m20){
		        		ma_20_data.innerText = "MA20: " + this.default_m20.value;
		        	}else{
		        		ma_20_data.innerText = "MA20: -";
		        	}
		        }
		        this.options.mark_ma.ma_20_data = ma_20_data;
	
		        frag.appendChild(ma_5_data);
		        frag.appendChild(ma_10_data);
		        frag.appendChild(ma_20_data);
		        div_mark.appendChild(frag);
		        document.getElementById(this.options.container).appendChild(div_mark);
		        // div_tip.style.left = w_pos.x - 300 + "px";
		    }else{
		        var div_mark = this.options.mark_ma.mark_ma; 
		        if(obj_5){
		           this.options.mark_ma.ma_5_data.innerText = "MA5: " + obj_5.value;
		        }else{
		        	if(this.default_m5){
		        		this.options.mark_ma.ma_5_data.innerText = "MA5: " + this.default_m5.value;
		        	}else{
		        		this.options.mark_ma.ma_5_data.innerText = "MA5: -";
		        	}
		        }
	
		        if(obj_10){
		            this.options.mark_ma.ma_10_data.innerText = "MA10: " + obj_10.value;
		        }else{
		        	if(this.default_m10){
						this.options.mark_ma.ma_10_data.innerText = "MA10: " + this.default_m10.value;
		        	}else{
		        		this.options.mark_ma.ma_10_data.innerText = "MA10: -";
		        	}
		        }
	
		        if(obj_20){
		            this.options.mark_ma.ma_20_data.innerText = "MA20: " + obj_20.value;
		        }else{
		        	if(this.default_m20){
		        		this.options.mark_ma.ma_20_data.innerText = "MA20: " + this.default_m20.value;
		        	}else{
		        		this.options.mark_ma.ma_20_data.innerText = "MA20: -";
		        	}
		        }
		        
		    }
		    
		}
		// 缩放
		Interactive.prototype.scale = function(canvas){
			/*K线图表右下角相对于父容器的位置*/
		    var w_pos = common.canvasToWindow.apply(this,[canvas,canvas.width,this.options.c_1_height]);
			if(!this.options.scale){
				this.options.scale = {};
				/*创建外部包裹元素*/
				var scale_div = document.createElement("div"); 
				scale_div.className = "scale-div";
				scale_div.style.right = "20px";
				scale_div.style.top = w_pos.y - 40 + "px";
				this.options.scale.scale = scale_div;
	
				/*创建文档碎片*/
				var frag = document.createDocumentFragment();
	
				/*创建减号*/
				var minus_button = document.createElement('span');
				minus_button.className = "span-minus";
				this.options.scale.minus = minus_button;
	
				/*创建加号*/
				var plus_button = document.createElement('span');
				plus_button.className = "span-plus";
				this.options.scale.plus = plus_button;
	
				frag.appendChild(minus_button);
				frag.appendChild(plus_button);
				scale_div.appendChild(frag);
				document.getElementById(this.options.container).appendChild(scale_div);
			}
		}
	
		// Tip显示行情数据
		Interactive.prototype.showTip = function(canvas,x,obj){
			// var c_box = canvas.getBoundingClientRect();
		    var type = this.options.type;
		    if(!this.options.tip){
		        this.options.tip = {};
		        // 创建外部包裹元素
		        var div_tip = document.createElement("div"); 
		        div_tip.className = "show-tip";
	
		        this.options.tip.tip = div_tip;
		        
		        // 创建文档碎片
		        var frag = document.createDocumentFragment();
	
		        // 创建收盘价格
		        var close_data = document.createElement('span');
		        close_data.className = "span-price";
		        this.options.tip.close = close_data;
		       
		        // 创建百分比
		        var percent = document.createElement('span');
		        this.options.tip.percent = percent;
		        
		        // 创建股数
		        var count = document.createElement('span');
		        this.options.tip.count = count;
		        
		        // 创建时间
		        var time = document.createElement('span');
		        this.options.tip.time = time;
	
		        var tip_line_1 = document.createElement("div");
		        tip_line_1.className = "tip-line-1";
		        tip_line_1.appendChild(close_data);
		        tip_line_1.appendChild(percent);
	
		        var tip_line_2 = document.createElement("div");
		        tip_line_2.className = "tip-line-2";
		        tip_line_2.appendChild(count);
		        tip_line_2.appendChild(time);
		        
		        frag.appendChild(tip_line_1);
		        frag.appendChild(tip_line_2);
		        div_tip.appendChild(frag);
		        document.getElementById(this.options.container).appendChild(div_tip);
	
		        var volume = obj.volume;
		        if(type == "DK" || type == "WK" || type == "MK"){
		            close_data.innerText = obj.close;
		            percent.innerText = obj.percent+'%';
	            	count.innerText = common.format_unit(volume);
		            time.innerText = obj.data_time;
		            div_tip.style.top = - div_tip.clientHeight + "px";
	
		            var c1 = "span-k-c1";
		            var c2 = "span-k-c2";
		        }else if(type == "TL"){
		            close_data.innerText = obj.price;
		            percent.innerText = obj.percent+'%';
	            	count.innerText = common.format_unit(volume);
		            time.innerText = obj.time;
		            div_tip.style.top = - div_tip.clientHeight + "px";
		            div_tip.className = div_tip.className + " " + "time-tip" 
	
		            var c1 = "span-time-c1";
		            var c2 = "span-time-c2";
		        }
	
		        close_data.className = close_data.className + " " + c1;
	            percent.className = percent.className + " " + c2;
	            count.className = count.className + " " + c1;
	            time.className = time.className + " " + c2;
	
		    }else{
		        var tip_obj = this.options.tip;
		        var div_tip = this.options.tip.tip;
		        var volume = obj.volume;
		       
		        if(type == "DK" || type == "WK" || type == "MK"){
		            tip_obj.close.innerText = obj.close;
		            tip_obj.percent.innerText = obj.percent+'%';
		            tip_obj.count.innerText = common.format_unit(volume);
		            tip_obj.time.innerText = obj.data_time.replace(/-/g,"/");
		        }else if(type == "TL"){
		            tip_obj.close.innerText = obj.price;
		            tip_obj.percent.innerText = obj.percent+'%';
	
		            tip_obj.count.innerText = common.format_unit(volume);
		            tip_obj.time.innerText = obj.time;
		        }
		    }
	
		    if(obj && obj.up){
		        div_tip.style.backgroundColor = this.options.up_color;
		    }else if(obj && !obj.up){
		        div_tip.style.backgroundColor = this.options.down_color;
		    }
	
		    // if((c_box.left + div_tip.clientWidth/2) >= x){
		    if(x <= (div_tip.clientWidth/2 + this.options.padding_left/this.options.dpr)){
		        div_tip.style.left = this.options.padding_left/this.options.dpr + "px";
		    }else if(x >= (canvas.width/this.options.dpr - div_tip.clientWidth/2)){
		        div_tip.style.left = canvas.width/this.options.dpr - div_tip.clientWidth + "px";
		    }else{
		        div_tip.style.left = x - div_tip.clientWidth/2 + "px";
		    }
		}
	
		// 标记上榜日
		Interactive.prototype.markPoint = function(x,date,canvas,scale_count){
			if(scale_count >= 0){
				// K线图表右下角相对于父容器的位置
			    var c1_pos = common.canvasToWindow.apply(this,[canvas,canvas.width,this.options.c_1_height]);
			    // 上榜日标记的横坐标
			   	var p_pos = common.canvasToWindow.apply(this,[canvas,x,this.options.c_1_height]);
	
				// 创建外部包裹元素
				var markPoint = document.createElement("div"); 
	
				markPoint.className = "mark-point";
				var imgUrl = this.options.markPoint.imgUrl;
				// 上榜日标识宽度
				var imgWidth = this.options.markPoint.width == undefined ? 15 : this.options.markPoint.width + "px";
				// 上榜日标识高度
				var imgHeight = this.options.markPoint.height == undefined ? 15 : this.options.markPoint.height + "px";
				if(imgUrl){
					markPoint.style.background = "url(" + imgUrl + ") no-repeat center center/" + imgWidth + " " + imgHeight + " #cccccc";
					markPoint.style.background = "url(" + imgUrl + ") no-repeat center center/" + imgWidth + " " + imgHeight + " #cccccc";
				}
	
				if(this.options.markPoint.width && this.options.markPoint.height){
					markPoint.style.width = imgWidth;
					markPoint.style.height = imgHeight;
				}else{
					markPoint.style.width = imgWidth;
					markPoint.style.height = imgHeight;
					// markPoint.style.borderRadius = "5px";
				}
				markPoint.setAttribute("data-point",date);
				if(!this.options.pointsContainer){
					var pointsContainer = document.createElement("div");
					this.options.pointsContainer = pointsContainer;
					document.getElementById(this.options.container).appendChild(this.options.pointsContainer);
				}
				this.options.pointsContainer.appendChild(markPoint);
				// 定位上榜日标识点的位置
				markPoint.style.left = p_pos.x - markPoint.clientWidth/2 + "px";
				markPoint.style.top = c1_pos.y - 30 + "px";
	
			}
			
		}
	
		// 显示交互效果
		Interactive.prototype.show = function(){
			
			if(this.options.cross){
	            var x_line = this.options.cross.x_line;
	            if(x_line){
	            	x_line.style.display = "block";
	            }
	            var y_line = this.options.cross.y_line;
	            if(y_line){
	            	y_line.style.display = "block";
	            }
	            var point = this.options.cross.point;
	            if(point){
	            	point.style.display = "block";
	            }
	        }
	
	        if(this.options.tip){
	            var tip = this.options.tip.tip;
	            if(tip){
	            	tip.style.display = "block";
	            }
	            
	        }
	        
		}
	
		// 隐藏交互效果
		Interactive.prototype.hide = function(){
			if(this.options.cross){
	            var x_line = this.options.cross.x_line;
	            if(x_line){
	            	x_line.style.display = "none";
	            }
	            var y_line = this.options.cross.y_line;
	            if(y_line){
	            	y_line.style.display = "none";
	            }
	            var point = this.options.cross.point;
	            if(point){
	            	point.style.display = "none";
	            }
	        }
	
	        if(this.options.mark_ma){
	            var ma_5_data = this.options.mark_ma.ma_5_data;
	            if(ma_5_data){
	            	if(this.default_m5){
		        		ma_5_data.innerText = "MA5: " + this.default_m5.value;
		        	}else{
		        		ma_5_data.innerText = "MA5: -";
		        	}
	            }
	            var ma_10_data = this.options.mark_ma.ma_10_data;
	            if(ma_10_data){
	            	if(this.default_m10){
		        		ma_10_data.innerText = "MA10: " + this.default_m10.value;
		        	}else{
		        		ma_10_data.innerText = "MA10: -";
		        	}
	            }
	            var ma_20_data = this.options.mark_ma.ma_20_data;
	            if(ma_20_data){
	            	if(this.default_m20){
		        		ma_20_data.innerText = "MA20: " + this.default_m20.value;
		        	}else{
		        		ma_20_data.innerText = "MA20: -";
		        	}
	            }
	
	        }
	
	        if(this.options.tip){
	            var tip = this.options.tip.tip;
	            if(tip){
	            	tip.style.display = "none";
	            }
	            
	        }
	
		}
	
		// 显示loading效果
		Interactive.prototype.showLoading = function(){
	
			if(this.options.loading){
				this.options.loading.style.display = "block";
			}else{
				// 获取图表容器
		        var chart_container = document.getElementById(this.options.container);
		        // var chart_container_height = chart_container.offsetHeight;
		        // loading提示信息
		        var loading_notice = document.createElement("div");
		        loading_notice.className = "loading-chart";
		        loading_notice.innerText = "加载中...";
		        loading_notice.style.height = this.options.height - 100 + "px";
		        loading_notice.style.width = this.options.width + "px";
		        // loading_notice.style.paddingTop = chart_container_height / 2 + "px";
		        loading_notice.style.paddingTop = "100px";
		        // 把提示信息添加到图表容器中
		        this.options.loading = loading_notice;
		        chart_container.appendChild(loading_notice);
			}
			
		}
	
		// 隐藏loading效果
		Interactive.prototype.hideLoading = function(){
			this.options.loading.style.display = "none";
		}
	
		// 暂无数据
		Interactive.prototype.showNoData = function(){
	
			if(this.options.noData){
				this.options.noData.style.display = "block";
			}else{
				//获取图表容器
		        var noData_container = document.getElementById(this.options.container);
		        // var noData_container_height = noData_container.offsetHeight;
		        //无数据时提示信息
		        var noData_notice = document.createElement("div");
		        noData_notice.className = "loading-chart";
		        noData_notice.innerText = "暂无数据";
		        noData_notice.style.height = this.options.height - 100 + "px";
		        noData_notice.style.width = this.options.width + "px";
	
		        noData_notice.style.paddingTop = "100px";
		        //把提示信息添加到图表容器中
		        this.options.noData = noData_notice;
		        noData_container.appendChild(noData_notice);
			}
			
		}
	
	    return Interactive;
	})();
	
	module.exports = Interactive;


/***/ },
/* 17 */
/***/ function(module, exports) {

	/*加水印*/
	function addWatermark(ctx,right,top,width,height) {
	    var _this = this;
		var canvas = ctx.canvas;
		var img = new Image();
	    width = width == undefined ? 164 : width;
	    height = height == undefined ? 41 : height;
	    img.width = 0;
	    img.height = 0;
	    //img.src = require("../images/water_mark.png");
	
	    img.onload = function(){
	        //console.info(111);
	        setTimeout(function() {
	            ctx.drawImage(img, canvas.width - right, top, width, height);	
	        }, 0);
	        
	    }
	
	    img.src = 'http://g1.dfcfw.com/g1/201607/20160727150611.png'
	
	    
	
	
	    //ctx.drawImage(img, canvas.width - right, top, 164, 41);	
	}
	
	module.exports = addWatermark;

/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制手机K线图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	 
	// 绘制坐标轴
	var DrawXY = __webpack_require__(5);
	// 主题
	var theme = __webpack_require__(7);
	// 获取K线图数据
	var GetDataDay = __webpack_require__(19); 
	var GetDataWeek = __webpack_require__(22); 
	var GetDataMonth = __webpack_require__(23); 
	// 绘制K线图
	var DrawK = __webpack_require__(24); 
	// 绘制均线图
	var DrawMA = __webpack_require__(25); 
	// 绘制成交量图
	var DrawV = __webpack_require__(15); 
	// 工具
	var common = __webpack_require__(8); 
	// 交互效果
	var Interactive = __webpack_require__(16); 
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 水印
	var watermark = __webpack_require__(17);
	
	var ChartK = (function() {
	
	    function ChartK(options) {
	        this.defaultoptions = theme.chartK;
	        this.options = {};
	        extend(true, this.options, theme.defaulttheme, this.defaultoptions, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.options.onChartLoaded = options.onChartLoaded == undefined ? function(op){
	
	        }:options.onChartLoaded;
	    }
	
	    /*初始化*/
	    ChartK.prototype.init = function() {
	        this.options.type = this.options.type == undefined ? "DK" : this.options.type;
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        // this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable","on");
	        this.container.style.position = "relative";
	        //画布
	        var ctx = canvas.getContext('2d');
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr;
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / 8;
	        // 画布内容向坐偏移的距离
	        this.options.padding_left = theme.defaulttheme.padding_left * dpr;
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / 8;
	        // 缩放默认值
	        this.options.scale_count = this.options.scale_count == undefined ? 0 : this.options.scale_count;
	        // 画布上第一个图表的高度
	        this.options.c_1_height = canvas.height * 0.5;
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0",this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr + 0.5;
	       
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	       
	    };
	
	    // 绘图
	    ChartK.prototype.draw = function(callback) {
	        var _this = this;
	        // 删除canvas画布
	        _this.clear();
	        // 初始化
	        _this.init();
	
	        // 初始化交互
	        var inter = _this.options.interactive = new Interactive(_this.options);
	        // 显示loading效果
	        inter.showLoading();
	
	        var type = _this.options.type;
	        try{
	            if(type == "DK"){
	                GetDataDay(getParamsObj.call(_this),function(data){
	                    var flag = dataCallback.apply(_this,[data]);
	                    // 均线数据标识
	                    inter.markMA(_this.options.canvas);
	                    // 缩放
	                    inter.scale(_this.options.canvas);
	                    if(flag){
	                        // 绑定事件
	                        bindEvent.call(_this,_this.options.context);
	                    }
	                    // 传入的回调函数
	                    if(callback){
	                        callback(_this.options);
	                    }
	
	                    
	                },inter);
	            }else if(type == "WK"){
	                GetDataWeek(getParamsObj.call(_this),function(data){
	                    var flag = dataCallback.apply(_this,[data]);
	                    // 均线数据标识
	                    inter.markMA(_this.options.canvas);
	                    // 缩放
	                    inter.scale(_this.options.canvas);
	                    if(flag){
	                        // 绑定事件
	                        bindEvent.call(_this,_this.options.context);
	                    }
	                    // 传入的回调函数
	                    if(callback){
	                        callback(_this.options);
	                    }
	
	                },inter);
	            }else if(type == "MK"){
	                GetDataMonth(getParamsObj.call(_this),function(data){
	                    var flag = dataCallback.apply(_this,[data]);
	                    // 均线数据标识
	                    inter.markMA(_this.options.canvas);
	                    // 缩放
	                    inter.scale(_this.options.canvas);
	                    if(flag){
	                        // 绑定事件
	                        bindEvent.call(_this,_this.options.context);
	                    }
	                    // 传入的回调函数
	                    if(callback){
	                        callback(_this.options);
	                    }
	
	                },inter);
	            }
	
	        }catch(e){
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	
	    };
	    // 重绘
	    ChartK.prototype.reDraw = function() {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        dataCallback.call(this);
	    }
	    // 删除canvas画布
	    ChartK.prototype.clear = function(cb) {
	        if(this.container){
	            this.container.innerHTML = "";
	        }else{
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	
	    // 获取上榜日标识dom
	    ChartK.prototype.getMarkPointsDom = function(cb) {
	        var points =  this.options.interactive.options.pointsContainer.children;
	        return points;
	    }
	
	    // 缩放图表
	    function scaleClick() {
	      
	        var _this = this;
	        var type = _this.options.type;
	        // 初始化交互
	        var inter = _this.options.interactive
	        // 显示loading效果
	        this.options.interactive.showLoading();
	
	        try{
	            if(type == "DK"){
	                GetDataDay(getParamsObj.call(_this),function(data){
	                    if(data){
	                        dataCallback.apply(_this,[data]);
	                        // 缩放按钮点击有效
	                        _this.options.clickable = true;
	                    }
	
	                },inter);
	            }else if(type == "WK"){
	                GetDataWeek(getParamsObj.call(_this),function(data){
	                    if(data){
	                        dataCallback.apply(_this,[data]);
	                        // 缩放按钮点击有效
	                        _this.options.clickable = true;
	                    }
	
	                },inter);
	            }else if(type == "MK"){
	                GetDataMonth(getParamsObj.call(_this),function(data){
	                    if(data){
	                        dataCallback.apply(_this,[data]);
	                        // 缩放按钮点击有效
	                        _this.options.clickable = true;
	                    }
	
	                },inter);
	            }
	
	        }catch(e){
	            // 缩放按钮点击有效
	            _this.options.clickable = true;
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	        
	    };
	
	    // 获取参数对象
	    function getParamsObj(){
	        var obj = {};
	        obj.code = this.options.code;
	        obj.count = this.options.scale_count;
	        return obj;
	    }
	    // 回调函数
	    function dataCallback(data){
	        var ctx = this.options.context;
	        var canvas = ctx.canvas;
	        this.options.data = data == null ? this.options.data : data;
	        data = this.options.data;
	
	        // 图表交互
	        var inter = this.options.interactive;
	
	        try{
	            if(!data || !data.data || data.data.length == 0){
	                this.options.data = {};
	                // 绘制坐标轴
	                new DrawXY(this.options);
	                // 绘制成交量图
	                new DrawV(this.options);
	                inter.hideLoading();
	                return;
	            }
	
	            // 保留的小数位
	            this.options.pricedigit = data.pricedigit || 2;
	
	            // 默认显示均线数据
	            var five_average = data.five_average;
	            var ten_average = data.ten_average;
	            var twenty_average = data.twenty_average;
	            inter.default_m5 = five_average[five_average.length - 1];
	            inter.default_m10 = ten_average[ten_average.length - 1];
	            inter.default_m20 = twenty_average[twenty_average.length - 1];
	
	            // 获取单位绘制区域
	            var rect_unit = common.get_rect.apply(this,[canvas,data.data.length]);
	            this.options.rect_unit = rect_unit;
	
	            // 绘制坐标轴
	            new DrawXY(this.options);
	
	            if(data && data.data && data.data.length > 0){
	                // 绘制K线图
	                new DrawK(this.options);
	                // 绘制均线图
	                new DrawMA(this.options);
	            }
	            // 绘制成交量图
	            new DrawV(this.options);
	
	            // 上榜日标识点
	            if(this.options.interactive.options.pointsContainer){
	                var points =  this.options.interactive.options.pointsContainer.children;
	                this.markPointsDom = points;
	            }
	
	            // 隐藏loading效果
	            inter.hideLoading();
	            
	            // 图表加载完成时间
	            this.options.onChartLoaded(this);
	
	        }catch(e){
	            // 缩放按钮点击有效
	            _this.options.clickable = true;
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	       // 加水印
	       watermark.apply(this,[this.options.context,170,20]);
	
	       return true;
	    }
	    // 绑定事件
	    function bindEvent(ctx){
	        var _this = this;
	        var timer_s,timer_m,timer_e;
	        var canvas = ctx.canvas;
	        var inter = _this.options.interactive;
	        //缩放按钮是否可点击
	        this.options.clickable = true;
	
	        var delayed = false;
	        var delaytouch = this.options.delaytouch = true;
	
	        // if(delaytouch){
	        //     var chart_container = document.getElementById(_this.options.container);
	        //     var delay = document.createElement("div");
	        //     delay.className = "delay-div";
	        //     delay.style.height = _this.options.height + "px";
	        //     delay.style.width = _this.options.width + "px";
	        //     delay.style.display = "none";
	        //     chart_container.appendChild(delay);
	
	        // }
	
	        // 触摸事件
	        canvas.addEventListener("touchstart",function(event){
	            // 显示交互效果
	            if(delaytouch){
	                delayed = false;
	                timer_s = setTimeout(function(){
	                    delayed = true;
	                    inter.show();
	                    dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	                    event.preventDefault();
	                },200);
	            }else{
	                inter.show();
	                dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	            }
	            
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	        });
	        
	        // 手指滑动事件
	        canvas.addEventListener("touchmove",function(event){
	            // dealEvent.apply(_this,[inter,event]);
	            if(delaytouch){
	                clearTimeout(timer_s);
	                if(delayed){
	                    dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	                    event.preventDefault();
	                }
	            }else{
	                dealEvent.apply(_this,[inter,event.changedTouches[0]]);
	            }
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	           
	        });
	
	        // 手指离开事件
	        canvas.addEventListener("touchend",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	            }
	            // 隐藏交互效果
	            inter.hide();
	            //event.preventDefault();
	        });
	
	        canvas.addEventListener("touchcancel",function(event){
	            if(delaytouch){
	                clearTimeout(timer_s);
	            }
	            // 隐藏交互效果
	            inter.hide();
	            if(_this.options.preventdefault){
	                event.preventDefault();
	            }
	        });
	        
	
	        // if(!delaytouch){
	            canvas.addEventListener("mousemove",function(event){
	                //console.info(event);
	                dealEvent.apply(_this,[inter,event]);
	                event.preventDefault();
	            });
	
	            canvas.addEventListener("mouseleave",function(event){
	                //console.info(event);
	                inter.hide();
	                event.preventDefault();
	            });
	
	            canvas.addEventListener("mouseenter",function(event){
	                //console.info(event);
	                inter.show();
	                event.preventDefault();
	            });
	        // }
	        
	        // 放大按钮
	        var scale_plus = inter.options.scale.plus;
	        // 缩小按钮
	        var scale_minus = inter.options.scale.minus;
	
	        // 点击放大
	        scale_plus.addEventListener("click",function(event){
	            var scale_count = _this.options.scale_count;
	            if(scale_count < 2 && _this.options.clickable){
	                // 缩放按钮点击无效
	                _this.options.clickable = false;
	                scale_minus.style.opacity = "1";
	                _this.options.scale_count = scale_count + 1;
	
	                // 清除上榜日标识
	                if(_this.options.interactive.options.pointsContainer){
	                    _this.options.interactive.options.pointsContainer.innerHTML = "";
	                }
	                // 清空画布
	                ctx.clearRect(0,-_this.options.canvas_offset_top,canvas.width,canvas.height);
	                scaleClick.apply(_this);
	            }
	
	            if(_this.options.scale_count >= 2){
	                scale_plus.style.opacity = "0.5";
	            }
	            
	        });
	
	        // 点击缩小
	        scale_minus.addEventListener("click",function(event){
	            var scale_count = _this.options.scale_count;
	            if(scale_count > -2 && _this.options.clickable){
	                // 缩放按钮点击无效
	                _this.options.clickable = false;
	                scale_plus.style.opacity = "1";
	                _this.options.scale_count = scale_count - 1;
	
	                // 清除上榜日标识
	                if(_this.options.interactive.options.pointsContainer){
	                    _this.options.interactive.options.pointsContainer.innerHTML = "";
	                }
	                // 清空画布
	                ctx.clearRect(0,-_this.options.canvas_offset_top,canvas.width,canvas.height);
	                scaleClick.apply(_this);
	            }
	
	            if(_this.options.scale_count <= -2){
	                scale_minus.style.opacity = "0.5";
	            }
	            
	        });
	
	    }
	    // 图表交互
	    function dealEvent(inter,eventposition){
	
	        var canvas = this.options.canvas;
	
	        var k_data = this.options.data.data;
	        var ma_5_data = this.options.data.five_average;
	        var ma_10_data = this.options.data.ten_average;
	        var ma_20_data = this.options.data.twenty_average;
	
	        // 单位绘制区域
	        var rect_unit = this.options.rect_unit;
	        // 单位绘制区域的宽度
	        var rect_w = rect_unit.rect_w;
	        // K线柱体的宽度
	        // var bar_w = rect_unit.bar_w;
	
	        // 鼠标事件位置
	        // var w_x = eventposition.clientX;
	        // var w_y = eventposition.clientY;
	
	        var w_x = eventposition.offsetX || (eventposition.clientX - this.container.getBoundingClientRect().left);
	        var w_y = eventposition.offsetY || (eventposition.clientY - this.container.getBoundingClientRect().top);
	
	        // 鼠标在画布中的坐标
	        var c_pos = common.windowToCanvas.apply(this,[canvas,w_x,w_y]);
	        var c_x = (c_pos.x).toFixed(0);
	        // var c_y = (c_pos.y).toFixed(0);
	
	        // 当前K线在数组中的下标
	        var index = Math.floor((c_x - this.options.padding_left)/rect_w);
	
	        if(k_data[index]){
	            // 显示行情数据
	            inter.showTip(canvas,w_x,k_data[index]);
	            
	            // 显示十字指示线的
	            var cross = common.canvasToWindow.apply(this,[canvas,k_data[index].cross_x,k_data[index].cross_y]);
	            var cross_w_x = cross.x;
	            var cross_w_y = cross.y;
	            inter.cross(canvas,cross_w_x,cross_w_y);
	        }
	
	        if(ma_5_data[index]){
	             // 标识均线数据
	             inter.markMA(canvas,ma_5_data[index],ma_10_data[index],ma_20_data[index]);
	        }
	
	    }
	
	    return ChartK;
	})();
	
	module.exports = ChartK;


/***/ },
/* 19 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获取手机分日K数据
	 * 传入option:{code:股票代码, count: 点击加减按钮的参数}
	 *     option.count取值对应的情况
	 *     0 ： 默认60根
	 *     1 ： 点击了一次放大， 显示45根
	 *     2 ： 点击了两次放大，显示36根
	 *     -1 ： 点击了一次缩小， 显示105根
	 *     -2 ： 点击了两次缩小，显示205根
	 *
	 * 返回result{
	 *     max: 坐标最大值
	 *     min: 坐标最小值
	 *     v_max:最大成交量
	 *     rect:[//每天天的情况
	 *         {
	 *              date_time：2015-11-12//日期
	 *              open : 64.50//开盘价 
	 *              close:  64.10 //收市价格
	 *              percent: 百分比 -8.1
	 *              height : 最高 65.4
	 *              low : 最低 63.10
	 *              volume: 换手数 10200
	 *              up: 涨跌标志 true(涨)
	 *         }，.....
	 *     ]
	 *     five_average:[{data:2016-02-11, value:63.41}] //五日均线
	 *     ten_average:[{data:2016-02-11, value:63.41}] //十日均线
	 *     twenty_average:[{data:2016-02-11, value:63.41}] //二十日均线
	 *     
	 * }
	 */
	
	// var transform = require('common').transform;
	var jsonp = __webpack_require__(12);
	var dealData = __webpack_require__(20);
	var fixed = __webpack_require__(8).fixed;
	
	
	//传入参数取数据
	function getdata(option, callback, interactive) {
	
	    var url = 'http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js';
	    var callbackstring = 'fsdata' + (new Date()).getTime().toString().substring(0, 10);
	    var id = option.code || option; //如果只传入了一个参数，就把那个参数当股票代码；如果传入两个，则id代表股票代码
	    var count = 0 | option.count;
	    var num = 60;
	    //判断count进行相应的根数变化
	    switch(count){
	        case 0: num = 60; break;
	        case 1: num = 45; break;
	        case 2: num = 36; break;
	        case -1: num = 105; break;
	        case -2: num = 205; break;
	    }
	    var today = new Date();
	    //获取当天的时间，成为 20160426 格式,查询从当天开始，往前的80天的数据
	    var today_number_str = today.getFullYear().toString() + fixed((today.getMonth() + 1).toString(), 2) + fixed(today.getDate(), 2);
	    var QuerySpan = today_number_str + ','+(num+20);
	    var urldata = {
	        id: id,
	        TYPE: 'K',
	        js: callbackstring + '((x))',
	        'rtntype': 5,
	        "QueryStyle": "2.2",
	        'QuerySpan': QuerySpan,
	        'extend':"ma",
	        isCR :false
	    };
	
	    jsonp(url, urldata, callbackstring, function(json) {
	        try{    
	            if (!json) {
	                callback(null);
	            } else {
	                var info = json.info;
	                // var data = json.data;
	
	                // 保留小数位
	                if(info.pricedigit.split(".").length > 1){
	                    window.pricedigit = info.pricedigit.split(".")[1].length == 0 ? 2 : info.pricedigit.split(".")[1].length;
	                }else{
	                    window.pricedigit = 0;
	                }
	
	                //获取数据处理后的结果
	                if(info.total < num){
	                    var result = dealData(json,info.total);
	                }else{
	                    var result = dealData(json,num);
	                }
	                
	                result.name = json.name;
	                result.total = info.total;
	                result.count = num-20;
	
	                // 保留小数位
	                result.pricedigit = window.pricedigit;
	
	                callback(result);
	            }
	
	        }catch(e){
	            // 暂无数据
	            interactive.showNoData();
	            // 隐藏loading效果
	            interactive.hideLoading();
	        }
	    });
	}
	
	module.exports = getdata;


/***/ },
/* 20 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 进行日K各个柱体的计算
	 *
	 * return {
	 *     max,//所有柱体中的最大值
	 *     min,//所有柱体中的最小值
	 *     fiv_average //五日均线
	 *     ten_average //十日均线
	 *     twenty_average //二十日均线
	 *     timeStrs //三个时间点日期字符串
	 *     data[ //所有的柱体
	 *          date_time： 日期
	 *          open : 开盘价
	 *          close: 收市价格
	 *          percent: 百分比
	 *          highest : 最高
	 *          lowest : 最低
	 *          volume: 换手数
	 *          up:涨跌标志
	 *     ]
	 * }
	 *     
	 */
	
	//转换日期（20121112 -> 2012-11-12）
	var transform = __webpack_require__(8).transform;
	var coordinate = __webpack_require__(21);
	// var fixed = require('common').fixed;
	function dealData(json, num) {
	    // var info = json.info;
	    var arr = json.data;
	    var result = {};
	    var max = 0;
	    var min = 100000;
	    var maxVolume = 0;
	    var i = 0;
	    result.data = [];
	    //昨日收盘价
	    var yes_clo_price = 0;
	    var len = arr.length;
	    var start = (len - num) > 0 ? (len - num) : 0;
	    for (i = start; i < len; i++) {
	        try {
	            var item = arr[i].split(/\[|\]/);
	            var itemBase = arr[i].split(/\[|\]/)[0].split(",");
	        } catch (e) {
	
	        }
	
	        var rect = {};
	
	        //进行各个柱体的计算
	        rect.data_time = itemBase[0];
	        rect.open = itemBase[1];
	        rect.close = itemBase[2];
	        rect.highest = itemBase[3];
	        rect.lowest = itemBase[4];
	
	        if (i > 0) {
	            rect.percent = (Math.abs(rect.close * 1.0 - rect.open * 1.0) / rect.open * 1.0).toFixed(2);
	        } else {
	            rect.percent = 0;
	            max = min = rect.open;
	        }
	        rect.volume = itemBase[5];
	
	        yes_clo_price = close;
	        rect.up = (rect.close * 1.0 - rect.open * 1.0) > 0 ? true : false;
	
	        var mas = item[1].split(",");
	        intoArr.call(result, "five_average", mas[0], rect.data_time);
	        intoArr.call(result, "ten_average", mas[1], rect.data_time);
	        intoArr.call(result, "twenty_average", mas[2], rect.data_time);
	        intoArr.call(result, "thirty_average", mas[3], rect.data_time);
	
	        //进行最大最小值计算
	        // max = getMax([max, rect.lowest, rect.highest*1.0]);
	        // min = getMin([min, rect.lowest, rect.highest*1.0]);
	        max = Math.max(max,rect.highest);
	        min = Math.min(min,rect.lowest);
	        maxVolume = maxVolume > rect.volume*1.0 ? maxVolume : rect.volume*1.0;
	
	        result.data.push(rect);
	
	    }
	
	
	    //日期字符串
	    result.timeStrs = [];
	
	    result.timeStrs[0] = transform(arr[start].split(',')[0]);
	    result.timeStrs[1] = transform(arr[Math.floor((len + start) / 2)].split(',')[0]);
	    result.timeStrs[2] = transform(arr[len - 1].split(',')[0]);
	
	    //坐标最大价格
	    result.max = parseFloat(coordinate(max, min).max);
	
	    //坐标最小价格
	    result.min = parseFloat(coordinate(max, min).min);
	
	    //最大成交量
	    result.v_max = Number((maxVolume).toFixed(2));
	
	    return result;
	}
	
	//创建一个数组，并且push值
	function intoArr(name, value, date) {
	    
	    if (this[name] === undefined) {
	        this[name] = [{ value: value, date: date }];
	    } else {
	        this[name].push({ value: value, date: date });
	    }
	}
	
	//数组冒泡得到最大值
	function getMax(arr) {
	    var max = 0;
	    for (var i = 0; i < arr.length; i++) {
	        max = max > arr[i] * 1.0 ? max : arr[i] * 1.0;
	    }
	    return max;
	}
	//数组冒泡得到最小值
	function getMin(arr) {
	    var min = 100000;
	    for (var i = 0; i < arr.length; i++) {
	        min = min < arr[i] * 1.0 ? min : arr[i] * 1.0;
	    }
	    return min;
	}
	
	
	module.exports = dealData;


/***/ },
/* 21 */
/***/ function(module, exports) {

	/**
	 * 分时图坐标上下限算法
	 */
	
	/*
	1.遍历出当前价的最高(high),最低点(low)
	2.取最高和最低的平均值
	3.(最高-平均)/2*1.05 得到偏移
	4.最高+偏移得最高， 最低加偏移得最低
	 */
	
	/**
	 * 分时图坐标上下限
	 * @param  {[type]} high 最高
	 * @param  {[type]} low 最低
	 */
	function coordinate(high, low) {
		var top = 0;
		// var fall = 0;
		var offset = (high-low)/2*0.05;
	
		top = high+offset;
		low = low-offset;
	
		return { max: top, min: low };
	}
	
	module.exports = coordinate;

/***/ },
/* 22 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获取手机分日K数据
	 * 传入option:{code:股票代码, count: 点击加减按钮的参数}
	 *     option.count取值对应的情况
	 *     0 ： 默认60根
	 *     1 ： 点击了一次放大， 显示45根
	 *     2 ： 点击了两次放大，显示36根
	 *     -1 ： 点击了一次缩小， 显示105根
	 *     -2 ： 点击了两次缩小，显示205根
	 *
	 * 返回result{
	 *     max: 坐标最大值
	 *     min: 坐标最小值
	 *     v_max:最大成交量
	 *     rect:[//每天天的情况
	 *         {
	 *              date_time：2015-11-12//日期
	 *              open : 64.50//开盘价 
	 *              close:  64.10 //收市价格
	 *              percent: 百分比 -8.1
	 *              height : 最高 65.4
	 *              low : 最低 63.10
	 *              volume: 换手数 10200
	 *              up: 涨跌标志 true(涨)
	 *         }，.....
	 *     ]
	 *     five_average:[{data:2016-02-11, value:63.41}] //五日均线
	 *     ten_average:[{data:2016-02-11, value:63.41}] //十日均线
	 *     twenty_average:[{data:2016-02-11, value:63.41}] //二十日均线
	 *     
	 * }
	 */
	
	// var transform = require('common').transform;
	var jsonp = __webpack_require__(12);
	var dealData = __webpack_require__(20);
	var fixed = __webpack_require__(8).fixed;
	
	
	//传入参数取数据
	function getdata(option, callback, interactive) {
	
	    var url = 'http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js';
	    var callbackstring = 'fsdata' + (new Date()).getTime().toString().substring(0, 10);
	    var id = option.code || option; //如果只传入了一个参数，就把那个参数当股票代码；如果传入两个，则id代表股票代码
	    var count = 0 | option.count;
	    var num = 60;
	    //判断count进行相应的根数变化
	    switch(count){
	        case 0: num = 60; break;
	        case 1: num = 45; break;
	        case 2: num = 36; break;
	        case -1: num = 105; break;
	        case -2: num = 205; break;
	    }
	    var today = new Date();
	    //获取当天的时间，成为 20160426 格式,查询从当天开始，往前的80天的数据
	    var today_number_str = today.getFullYear().toString() + fixed((today.getMonth() + 1).toString(), 2) + fixed(today.getDate(), 2);
	    var QuerySpan = today_number_str + ','+(num+20);
	    var urldata = {
	        id: id,
	        TYPE: 'WK',
	        js: callbackstring + '((x))',
	        'rtntype': 5,
	        "QueryStyle": "2.2",
	        'QuerySpan': QuerySpan,
	        'extend':"ma",
	        isCR :false
	    };
	
	    jsonp(url, urldata, callbackstring, function(json) {
	        try{
	            if (!json) {
	                callback(null);
	            } else {
	                var info = json.info;
	                // var data = json.data;
	
	                // 保留小数位
	                if(info.pricedigit.split(".").length > 1){
	                    window.pricedigit = info.pricedigit.split(".")[1].length == 0 ? 2 : info.pricedigit.split(".")[1].length;
	                }else{
	                    window.pricedigit = 0;
	                }
	                //获取数据处理后的结果
	                if(info.total < num){
	                    var result = dealData(json,info.total);
	                }else{
	                    var result = dealData(json,num);
	                }
	                result.name = json.name;
	                result.count = num-20;
	                // 保留小数位
	                result.pricedigit = window.pricedigit;
	
	                callback(result);
	            }
	
	        }catch(e){
	            // 暂无数据
	            interactive.showNoData();
	            // 隐藏loading效果
	            interactive.hideLoading();
	        }
	        
	    });
	}
	
	module.exports = getdata;


/***/ },
/* 23 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获取手机分日K数据
	 * 传入option:{code:股票代码, count: 点击加减按钮的参数}
	 *     option.count取值对应的情况
	 *     0 ： 默认60根
	 *     1 ： 点击了一次放大， 显示45根
	 *     2 ： 点击了两次放大，显示36根
	 *     -1 ： 点击了一次缩小， 显示105根
	 *     -2 ： 点击了两次缩小，显示205根
	 *
	 * 返回result{
	 *     max: 坐标最大值
	 *     min: 坐标最小值
	 *     v_max:最大成交量
	 *     rect:[//每天天的情况
	 *         {
	 *              date_time：2015-11-12//日期
	 *              open : 64.50//开盘价 
	 *              close:  64.10 //收市价格
	 *              percent: 百分比 -8.1
	 *              height : 最高 65.4
	 *              low : 最低 63.10
	 *              volume: 换手数 10200
	 *              up: 涨跌标志 true(涨)
	 *         }，.....
	 *     ]
	 *     five_average:[{data:2016-02-11, value:63.41}] //五日均线
	 *     ten_average:[{data:2016-02-11, value:63.41}] //十日均线
	 *     twenty_average:[{data:2016-02-11, value:63.41}] //二十日均线
	 *     
	 * }
	 */
	
	// var transform = require('common').transform;
	var jsonp = __webpack_require__(12);
	var dealData = __webpack_require__(20);
	var fixed = __webpack_require__(8).fixed;
	
	
	//传入参数取数据
	function getdata(option, callback, interactive) {
	
	    var url = 'http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js';
	    var callbackstring = 'fsdata' + (new Date()).getTime().toString().substring(0, 10);
	    var id = option.code || option; //如果只传入了一个参数，就把那个参数当股票代码；如果传入两个，则id代表股票代码
	    var count = 0 | option.count;
	    var num = 60;
	    //判断count进行相应的根数变化
	    switch(count){
	        case 0: num = 60; break;
	        case 1: num = 45; break;
	        case 2: num = 36; break;
	        case -1: num = 105; break;
	        case -2: num = 205; break;
	    }
	    var today = new Date();
	    //获取当天的时间，成为 20160426 格式,查询从当天开始，往前的80天的数据
	    var today_number_str = today.getFullYear().toString() + fixed((today.getMonth() + 1).toString(), 2) + fixed(today.getDate(), 2);
	    var QuerySpan = today_number_str + ','+(num+20);
	    var urldata = {
	        id: id,
	        TYPE: 'MK',
	        js: callbackstring + '((x))',
	        'rtntype': 5,
	        "QueryStyle": "2.2",
	        'QuerySpan': QuerySpan,
	        'extend':"ma",
	        isCR :false
	    };
	
	    jsonp(url, urldata, callbackstring, function(json) {
	
	        try{
	            if (!json) {
	                callback(null);
	            } else {
	                var info = json.info;
	                // var data = json.data;
	
	                // 保留小数位
	                if(info.pricedigit.split(".").length > 1){
	                    window.pricedigit = info.pricedigit.split(".")[1].length == 0 ? 2 : info.pricedigit.split(".")[1].length;
	                }else{
	                    window.pricedigit = 0;
	                }
	                //获取数据处理后的结果
	                if(info.total < num){
	                    var result = dealData(json,info.total);
	                }else{
	                    var result = dealData(json,num);
	                }
	                result.name = json.name;
	                result.count = num-20;
	
	                // 保留小数位
	                result.pricedigit = window.pricedigit;
	
	                callback(result);
	            }
	
	        }catch(e){
	            // 暂无数据
	            interactive.showNoData();
	            // 隐藏loading效果
	            interactive.hideLoading();
	        }
	        
	    });
	}
	
	module.exports = getdata;


/***/ },
/* 24 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制K线
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 工具
	var common = __webpack_require__(8);
	// 主题
	var theme = __webpack_require__(7);
	var DrawK = (function(){
		function DrawK(options){
			// 设置默认参数
	        this.defaultoptions = theme.draw_k;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        // 绘图
	        this.draw();
		};
	
		// 绘图
		DrawK.prototype.draw = function(){
			var ctx = this.options.context;
			var data = this.options.data;
			var data_arr = data.data;
	
			// 绘制K线图
			this.drawK(ctx,data_arr);
		};
		
		// 绘制K线图
		DrawK.prototype.drawK = function(ctx,data_arr){
			
			// 获取单位绘制区域
			var rect_unit = this.options.rect_unit;
			// 单位绘制区域的宽度
			// var rect_w = rect_unit.rect_w;
			// K线柱体的宽度
			var bar_w = rect_unit.bar_w;
			// K线柱体的颜色
			var up_color = this.options.up_color;
			var down_color =this.options.down_color
			// 图表交互
	        var inter = this.options.interactive;
	        // 上榜日数组
	        var pointObj = {};
	        if(this.options.markPoint && this.options.markPoint.show){
	        	var array = this.options.markPoint.dateList;
	        	for(var index in array){
	        		pointObj[array[index]] = array[index];
	        	}
	        }
	
			for(var i = 0,item; item = data_arr[i]; i++){
				// 是否上涨
				var is_up = item.up;
	
				ctx.beginPath();
				ctx.lineWidth = 1;
	
				if(is_up){
				 	ctx.fillStyle = up_color;
	                ctx.strokeStyle = up_color
				}else{
					ctx.fillStyle = down_color
	                ctx.strokeStyle = down_color
				}
	
				var x = common.get_x.call(this,i + 1);
			 	var y_open = common.get_y.call(this,item.open);
			 	var y_close = common.get_y.call(this,item.close);
			 	var y_highest = common.get_y.call(this,item.highest);
			 	var y_lowest = common.get_y.call(this,item.lowest);
			 	item.cross_x = x;
			 	item.cross_y = y_close;
			 	// console.log(x.toFixed(2).toString());
	
			 	//标识上榜日
			 	if(pointObj[item.data_time]){
			 		inter.markPoint(x,item.data_time,this.options.context.canvas,this.options.scale_count);
			 	}
	
			 	ctx.moveTo(x,y_lowest);
			 	ctx.lineTo(x,y_highest);
			 	ctx.stroke();
	
			 	ctx.beginPath();
	
				// ctx.lineWidth = w * (1 - this.options.spacing);
			 	// ctx.moveTo(x,y_open);
			 	// ctx.lineTo(x,y_close);
			 	
			 	if(y_close >= y_open){
			 		ctx.rect(x - bar_w/2,y_open,bar_w,y_close - y_open);
			 	}else{
			 		ctx.rect(x - bar_w/2,y_close,bar_w,y_open - y_close);
			 	}
	
			 	ctx.stroke();
			 	ctx.fill();
			}
		};
	
		return DrawK;
	})();
	
	module.exports = DrawK;

/***/ },
/* 25 */
/***/ function(module, exports, __webpack_require__) {

	/*继承*/
	var extend = __webpack_require__(6);
	/*工具*/
	var common = __webpack_require__(8);
	/*主题*/
	var theme = __webpack_require__(7);
	var DrawMA = (function(){
		function DrawMA(options){
			/*设置默认参数*/
	        this.defaultoptions = theme.drawMA;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
		};
		
		/*绘图*/
		DrawMA.prototype.draw = function(){
			var ctx = this.options.context;
			var data = this.options.data;
			/*5日均线数据*/
			var five_average = data.five_average;
			/*10日均线数据*/
			var ten_average = data.ten_average;
			/*20日均线数据*/
			var twenty_average = data.twenty_average;
	
			this.options.ma_5_data = drawMA.apply(this,[ctx,five_average,"#f4cb15"]);
			this.options.ma_10_data = drawMA.apply(this,[ctx,ten_average,"#ff5b10"]);
			this.options.ma_20_data = drawMA.apply(this,[ctx,twenty_average,"#488ee6"]);
		};
		/**
	     * 绘制均线图
	     */
	    function drawMA(ctx,data_arr,color) {
	    	var ma_data = [];
	    	ctx.beginPath();
			ctx.strokeStyle = color;
			for(var i = 0;i < data_arr.length; i++){
				var item = data_arr[i];
				if(item && item.value){
					 var x = common.get_x.call(this,i + 1);
					 var y = common.get_y.call(this,item.value);
					 //横坐标和均线数据
					 ma_data.push(item);
	
					 if(i == 0 || y > (this.options.c_1_height - ctx.canvas.height/8/2)  || y < 0){
					 	ctx.moveTo(x,y);
					 }else{
					 	ctx.lineTo(x,y);
					 }
				}
				 
			}
			ctx.stroke();
			return ma_data;
	    }
	    
		return DrawMA;
	})();
	
	module.exports = DrawMA;

/***/ },
/* 26 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制手机分时图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	// 绘制坐标轴
	var DrawXY = __webpack_require__(27);
	// 主题
	var theme = __webpack_require__(7);
	// 绘制分时折线图
	var DrawLine = __webpack_require__(28); 
	// 拓展，合并，复制
	var extend = __webpack_require__(6);
	// 交互效果
	var Interactive = __webpack_require__(16); 
	// 水印
	var watermark = __webpack_require__(17);
	
	var ChartLine = (function() {
	
	    // 构造函数
	    function ChartLine(options) {
	        this.defaultoptions = theme.chartLine;
	        this.options = {};
	        extend(true, this.options, theme.defaulttheme, this.defaultoptions, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.onChartLoaded = options.onChartLoaded == undefined ? function(op){
	
	        }:options.onChartLoaded;
	        
	    }
	
	    // 初始化
	    ChartLine.prototype.init = function() {
	
	        this.options.type = "line";
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        // this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable","on");
	        this.container.style.position = "relative";
	        // 画布
	        var ctx = canvas.getContext('2d');
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr;
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / (9 * 2);
	        // 画布内容向坐偏移的距离
	        this.options.padding_left = canvas.width / 6;
	
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / (9 * 2);
	        // 缩放默认值
	        this.options.scale_count = 0;
	        // 画布上第一个图表的高度
	        if(this.options.showflag){
	            this.options.c_1_height = canvas.height * (5/9);
	        }else{
	            this.options.c_1_height = canvas.height * (7/9);
	        }
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0",this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr + 0.5;
	        // 加水印
	        watermark.apply(this,[ctx,190,20]);
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	    };
	
	    // 绘图
	    ChartLine.prototype.draw = function(callback) {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        // 初始化交互
	        this.options.interactive = new Interactive(this.options);
	        // 显示loading效果
	        // inter.showLoading();
	        // var _this = this;
	
	        // 折线数据
	        var series = this.options.series;
	        this.options.data = {};
	        var maxAndMin = getMaxMark(series);
	        this.options.data.max = maxAndMin.max;
	        this.options.data.min = maxAndMin.min;
	        this.options.padding_left = this.options.context.measureText("-1000万").width + 20;
	
	        // 绘制坐标轴
	        new DrawXY(this.options);
	        // 绘制分时折线图
	        new DrawLine(this.options);
	
	    };
	    // 重绘
	    ChartLine.prototype.reDraw = function() {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        this.draw();
	    }
	    // 删除canvas画布
	    ChartLine.prototype.clear = function(cb) {
	        if(this.container){
	            this.container.innerHTML = "";
	        }else{
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	
	    // 获取数组中的最大值
	    function getMaxMark(data) {
	        var max = 0, min = 0,count=[];
	        for(var i = 0;i<data.length;i++){
	            count = count.concat(data[i].data);
	        }
	        max = count[0];
	
	        for(var i =1;i<count.length;i++) {
	            max = Math.max(max,count[i]);
	            min = Math.min(min,count[i]);
	        }
	        var step = Math.ceil((max * 1.1) / 5);
	        if(step <= 10){
	            step = Math.ceil(step);
	        }else if(step > 10 && step < 100){
	            if(step % 10 > 0){
	                step = Math.ceil(step/10) * 10;
	            }
	        }
	
	        else{
	            var num = step.toString().length;
	            var base_step = Math.floor(step/Math.pow(10,(num - 1))) * Math.pow(10,(num - 1));
	            var middle_step = base_step + Math.pow(10,(num - 1))/2;
	            var next_step = base_step + Math.pow(10,(num - 1));
	
	            if(step == base_step){
	                step = base_step;
	            }else if(step > base_step && step <= middle_step){
	                step = middle_step;
	            }else if(step > middle_step && step <= next_step){
	                step = next_step;
	            }
	        }
	
	        // else{
	        //     var num = step.toString().length;
	        //     var base_step = Math.ceil(step/Math.pow(10,(num - 2))) * Math.pow(10,(num - 2));
	        //     step = base_step;
	        // }
	        max = step * 5;
	        return {
	            max:max,
	            min:min
	        };
	     }
	
	    return ChartLine;
	})();
	
	module.exports = ChartLine;


/***/ },
/* 27 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制直角坐标系
	 */
	 var extend = __webpack_require__(6);
	 /*主题*/
	 var theme = __webpack_require__(7);
	 var common = __webpack_require__(8);
	 var DrawXY = (function(){
	    //构造方法
	    function DrawXY(options){
	        /*设置默认参数*/
	        this.defaultoptions = theme.draw_xy;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
	    };
	    /*绘图*/
	    DrawXY.prototype.draw = function(){
	        // var xAxisData = this.options.xaxis;
	        // var yAxisData = this.options.series;
	        // var type = this.options.type;
	        // var dpr = this.options.dpr;
	        var ctx = this.options.context;
	
	        /*Y轴上的最大值*/
	        var y_max = this.options.data.max;
	        /*Y轴上的最小值*/
	        var y_min = this.options.data.min;
	
	        /*Y轴上分隔线数量*/
	        var sepe_num = this.options.sepenum || 6;
	        /*开盘收盘时间数组*/
	        var oc_time_arr = this.options.xaxis;
	
	        /*K线图的高度*/
	        var k_height = this.options.c_1_height;
	        /*Y轴标识线列表*/
	        var line_list_array = getLineList(y_max, y_min, sepe_num, k_height);
	
	        drawXYLine.call(this,ctx,y_max,y_min,line_list_array);
	
	        // 绘制横坐标刻度
	        drawXMark.apply(this,[ctx,k_height,oc_time_arr]);
	    };
	    // 绘制分时图坐标轴最左边刻度
	    function drawXYLine(ctx,y_max,y_min,line_list_array){
	        // var sepe_num = line_list_array.length;
	        ctx.fillStyle = '#b1b1b1';
	        ctx.strokeStyle = '#ccc';
	        ctx.textAlign = 'right';
	
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	            ctx.moveTo(this.options.padding_left, Math.round(item.y));
	            ctx.lineTo(ctx.canvas.width, Math.round(item.y));
	            // 绘制纵坐标刻度
	            ctx.fillText(common.format_unit(item.num/1,2), this.options.padding_left-20, item.y +10);
	            ctx.stroke();
	        }
	
	    }
	
	    /*绘制横坐标刻度值*/
	    function drawXMark(ctx,k_height,oc_time_arr){
	        // var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        ctx.beginPath();
	        ctx.textAlign = 'center';
	        ctx.fillStyle = '#b1b1b1';
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        // var y_date = this.options.c_1_height;
	        var tempDate;
	        // var timeSpacing = (this.options.width * dpr - padding_left) / oc_time_arr.length + padding_left;
	        var arr_length = oc_time_arr.length;
	        for(var i = 0;i<arr_length;i++) {
	            tempDate = oc_time_arr[i];
	            if(tempDate.show == undefined ? true : tempDate.show){
	                if(i < arr_length - 1){
	                    ctx.fillText(tempDate.value, i * (k_width - padding_left) / (arr_length-1) + padding_left, this.options.c_1_height+40);
	                }else
	
	                if(i * (k_width - padding_left) / (arr_length-1) + padding_left + ctx.measureText(tempDate.value).width > ctx.canvas.width){
	                    ctx.fillText(tempDate.value, ctx.canvas.width - ctx.measureText(tempDate.value).width/2, this.options.c_1_height+40);
	                }
	            }
	
	            if(tempDate.showline == undefined ? true : tempDate.showline){
	                ctx.strokeStyle = '#ccc';
	                ctx.moveTo(i * (k_width - padding_left) / (arr_length-1) + padding_left,0);
	                ctx.lineTo(i * (k_width - padding_left) / (arr_length-1) + padding_left,this.options.c_1_height);
	            }
	
	        }
	
	
	        // var x = ((ctx.canvas.width - this.options.padding_left)/(arr_length-1)) * (i) + this.options.padding_left;
	
	            // 绘制坐标刻度
	            ctx.stroke();
	
	
	        // ctx.moveTo(0,k_height + 10);
	    }
	    
	    /*Y轴标识线列表*/
	    function getLineList(y_max, y_min, sepe_num, k_height) {
	        var ratio = (y_max - y_min) / (sepe_num-1);
	        var result = [];
	        for (var i = 0; i < sepe_num; i++) {
	            result.push({
	                num:  (y_min + i * ratio),
	                x: 0,
	                y: k_height - (i / (sepe_num-1)) * k_height
	            });
	        }
	        return result;
	    }
	
	    return DrawXY;
	})();
	
	module.exports = DrawXY;

/***/ },
/* 28 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制折线图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	/*继承*/
	var extend = __webpack_require__(6);
	/*主题*/
	var theme = __webpack_require__(7);
	/*工具*/
	var common = __webpack_require__(8);
	var DrawLine = (function(){
		function DrawLine(options){
			// 设置默认参数
	        this.defaultoptions = theme.drawLine;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        // 绘图
	        this.draw();
		};
		
		// 绘图
		DrawLine.prototype.draw = function(){
	
			var ctx = this.options.context;
			ctx.lineWidth = 1 * this.options.dpr + 1;
			// 折线数据
			var series = this.options.series;
			// 横坐标数据
			// var xaxis = this.options.xaxis;
			for(var i = 0,line;line = series[i]; i++){
				// 填充颜色
				ctx.fillStyle = line.color == undefined ? "#333" : line.color;
				// 画笔颜色
		        ctx.strokeStyle = line.color == undefined ? "#333" : line.color;
	        	drawLine.apply(this,[ctx,line]);
		        			
				if(line.showpoint){
					drawPoint.apply(this,[ctx,line]);
				}
				
			}
			if(this.options.showflag){
				drawLineMark.apply(this,[ctx,series]);
			}
		};
		
		// 绘制折线
		function drawLine(ctx,line){
			// 保存画笔状态
			ctx.save();
	
			var arr = line.data;
	        var arr_length = arr.length;
	
			ctx.beginPath();
	
			for(var i = 0;i < arr_length; i++){
				var item = arr[i];
				if(item){
					 var x = ((ctx.canvas.width - this.options.padding_left)/(arr_length-1)) * (i) + this.options.padding_left;
					 var y = common.get_y.call(this,item);
					 if(i == 0){
					 	ctx.moveTo(this.options.padding_left,y);
					 }else if(i == arr_length - 1){
					 	ctx.lineTo(x,y);
					 }else{
					 	ctx.lineTo(x,y);
					 }
				}else{
					 continue;
				}
				 
			}
			
			// ctx.fill();
			ctx.stroke();
			// 恢复画笔状态
			ctx.restore();
		}
	
		// 绘制折线节点（连接点）
		function drawPoint(ctx,line){
			// 保存画笔状态
			ctx.save();
	
			var arr = line.data;
	        var arr_length = arr.length;
	
	        // 节点（折线连接点半径）
	        var pointRadius = this.options.pointRadius;
	
			for(var i = 0,item;item = arr[i]; i++){
				 ctx.beginPath();
	        	 var x = ((ctx.canvas.width - this.options.padding_left)/(arr_length-1)) * (i) + this.options.padding_left;
				 var y = common.get_y.call(this,item);
				 if(i == 0){
				 	ctx.arc(x, y, pointRadius, 0, Math.PI * 2, true); 
				 	ctx.fill();
				 }else if(i == arr_length - 1){
				 	
				 }else{
				 	ctx.arc(x, y, pointRadius, 0, Math.PI * 2, true); 
				 	ctx.fill();
				 }
			 	 
			}
			// 恢复画笔状态
			ctx.restore();
		}
	
	
	    // 绘制折线标识
	    function drawLineMark(ctx,series){
	    	// 保存画笔状态
			ctx.save();
			var dpr = this.options.dpr;
			var x_middle = ctx.canvas.width/2;
			var wh = this.options.lineMarkWidth * dpr;
			var x_start = 0;
			var y_start = ctx.canvas.height * (7/9 - 1/18);
	
			for(var i = 0,line;line = series[i]; i++){
				ctx.beginPath();
				
				// 画笔颜色
		        ctx.strokeStyle = '#cadef8';
		        var mark_offset = (Math.floor(i/2)) * (wh + 7 * dpr);
		        var text_offset = this.options.font_size * this.options.dpr + (wh-this.options.font_size * this.options.dpr)/2;
				if(i == 0){
					// 填充颜色
					ctx.fillStyle = line.color;
					ctx.rect(x_start + 20,y_start,wh,wh);
					ctx.fill();
					// 填充颜色
					ctx.fillStyle = '#333';
					ctx.fillText(line.name, x_start + wh + 80, y_start + text_offset);
				}else if((i + 1) % 2 == 0){
					// 填充颜色
					ctx.fillStyle = line.color;
			 		ctx.rect(x_middle,y_start + mark_offset,wh,wh);
			 		ctx.fill();
			 		// 填充颜色
					ctx.fillStyle = '#333';
	        		ctx.fillText(line.name, x_middle + wh + 60, y_start + mark_offset + text_offset);
		    	}else{
		    		// 填充颜色
					ctx.fillStyle = line.color;
		    		ctx.rect(x_start + 20,y_start + mark_offset,wh,wh);
		    		ctx.fill();
		    		ctx.fillStyle = '#333';
		    		ctx.fillText(line.name, x_start + wh + 80, y_start + mark_offset + text_offset);
		    	}
			}
			// 恢复画笔状态
			ctx.restore();
	    }
	
		return DrawLine;
	})();
	
	module.exports = DrawLine;

/***/ },
/* 29 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制折线图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     
	 * }
	 *
	 */
	
	// 绘制坐标轴
	var DrawXY = __webpack_require__(30);
	// 主题
	var theme = __webpack_require__(7);
	// 绘制利率折线图
	var DrawLine = __webpack_require__(31);
	// 拓展，合并，复制
	var extend = __webpack_require__(32);
	// 水印
	var watermark = __webpack_require__(17);
	/*工具*/
	var common = __webpack_require__(8);
	
	var ChartLine = (function() {
	
	    // 构造函数
	    function ChartLine(options) {
	        this.defaultoptions = theme.chartLine;
	        this.options = extend(this.defaultoptions, theme.defaulttheme, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.onChartLoaded = options.onChartLoaded == undefined ? function(op) {
	
	        } : options.onChartLoaded;
	
	    }
	
	    // 初始化
	    ChartLine.prototype.init = function() {
	
	        this.options.type = "line";
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        // this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable","on");
	        this.container.style.position = "relative";
	        // 兼容IE6-IE9
	        try {
	            var ctx = canvas.getContext('2d');
	        } catch (error) {
	            canvas = window.G_vmlCanvasManager.initElement(canvas);
	            var ctx = canvas.getContext('2d');
	        }
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr = 1;
	
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / (9 * 2);
	        // 画布内容向坐偏移的距离
	        this.options.padding_left = canvas.width / 6;
	
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / (9 * 2);
	        // 缩放默认值
	        this.options.scale_count = 0;
	        // 画布上第一个图表的高度
	        if (this.options.showflag) {
	            this.options.c_1_height = canvas.height * (5 / 9);
	        } else {
	            this.options.c_1_height = canvas.height * (7 / 9);
	        }
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0", this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr;
	        // 加水印
	        watermark.apply(this,[this.options.context,90,20,82,20]);
	
	    };
	
	    // 绘图
	    ChartLine.prototype.draw = function(callback) {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	
	        // 折线数据
	        var series = this.options.series;
	        var maxAndMin = getMaxAndMin(series);
	        this.options.data = {};
	        this.options.data.max = maxAndMin.max * 1.1;
	        this.options.data.min = maxAndMin.min;
	        this.options.padding_left = this.options.context.measureText("1000万").width + 20;
	
	        // 绘制坐标轴
	        new DrawXY(this.options);
	        // 绘制利率折线图
	        new DrawLine(this.options);
	
	        this.addInteractive();
	
	
	    };
	    // 重绘
	    ChartLine.prototype.reDraw = function() {
	            // 删除canvas画布
	            this.clear();
	            // 初始化
	            this.init();
	            this.draw();
	        }
	        // 删除canvas画布
	    ChartLine.prototype.clear = function(cb) {
	        if (this.container) {
	            this.container.innerHTML = "";
	        } else {
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	
	    //获得tips的显示位置和tips的相关内容(传入的值是乘过dpr值的)
	    function getTips(winX, winY) {
	        //需要被返回的值
	        var result = {};
	        result.showLine = false;
	        result.showTips = false;
	
	        var canvas = this.options.canvas;
	        var paddingLeft = this.options.padding_left;
	        var offSetTop = this.options.canvas_offset_top;
	        var radius = this.options.pointRadius;
	        var dpr = this.options.dpr;
	
	        var series = this.options.series;
	        var xaxis = this.options.xaxis;
	        var unitWidth = (canvas.width - paddingLeft) / (xaxis.length - 1);
	
	        //标识在从左到右第几个圆点上
	        var num = (winX - paddingLeft + unitWidth/2) / (unitWidth);
	        num = num < 0 ? 0 : Math.floor(num);
	
	        //数据点点的圆心
	        var pointX = ((canvas.width - paddingLeft) / (xaxis.length - 1)) * num + paddingLeft;
	
	        for (var i = 0; i < series.length; i++) {
	            //遍历获得
	            var pointY = common.get_y.call(this, series[i].data[num]);
	            //判断鼠标指定的点是不是在数据点周围
	            if ((Math.abs(pointY - winY + offSetTop) < 2 * radius) && (Math.abs(pointX - winX + radius) < 2 * radius) && num != (xaxis.length -1)) {
	                result.showTips = true;
	                result.pointY = pointY + offSetTop / dpr;
	                result.pointX = pointX;
	                result.content = series[i].name + " : " + series[i].data[num];
	            }
	        }
	        //判断虚线是否显示
	        if (Math.abs(pointX - winX ) < 2*radius) {
	            //对竖直的y轴做处理（可能是个bug）
	            if (num !== 0 && num !== xaxis.length - 1) {
	                result.showLine = true;
	                result.lineX = pointX;
	            } else {
	                result.showLine = false;
	            }
	        }
	
	        return result;
	    }
	
	    //添加交互
	    ChartLine.prototype.addInteractive = function() {
	        var canvas = this.options.canvas;
	        var _that = this;
	        var tips = document.createElement("div");
	        var middleLine = document.createElement("div");
	        //用于canvas与windows相互转化
	        var dpr = this.options.dpr ? this.options.dpr : 1;
	        var padding_left = this.options.padding_left;
	        var offSetTop = this.options.canvas_offset_top / dpr;
	        var yHeight = this.options.c_1_height / dpr;
	        var radius = this.options.pointRadius;
	        //用于减少div移动的setTimeout
	        var timeId;
	
	
	
	        tips.className = "web-tips";
	        middleLine.className = "web-middleLine";
	        _that.container.appendChild(tips);
	        _that.container.appendChild(middleLine);
	
	        common.addEvent.call(_that, canvas, "mousemove", function(e) {
	            var winX, winY;
	            //浏览器检测，获取到相对元素的x和y
	            if (e.layerX) {
	                winX = e.layerX;
	                winY = e.layerY;
	            } else if (e.x) {
	                winX = e.x;
	                winY = e.y;
	            }
	
	            //在坐标系外不显示
	            if (winX * dpr >= (padding_left - radius) && (winY >= offSetTop && winY <= (offSetTop + yHeight))) {} else {
	                tips.style.display = "none";
	                middleLine.style.display = "none";
	            }
	
	            //通过鼠标移动获得交互的点
	            var result = getTips.call(_that, winX * _that.options.dpr, winY * _that.options.dpr);
	
	            if (result.showLine && (winY >= offSetTop && winY <= (offSetTop + yHeight))) {
	                middleLine.style.display = "inline-block";
	                //绘制中线
	                middleLine.style.height = yHeight + "px";
	                middleLine.style.left = result.lineX / dpr + "px";
	                middleLine.style.top = offSetTop + "px";
	            } else {
	                middleLine.style.display = "none";
	            }
	            //如果在数据点上，显示tips
	            if (result.showTips) {
	                tips.style.display = "inline-block";
	                tips.innerHTML = result.content;
	                if (winX * dpr - padding_left < canvas.width / 2) {
	                    tips.style.left = (result.pointX / dpr + radius) + "px";
	                } else {
	                    tips.style.left = (result.pointX / dpr - radius - tips.clientWidth) + "px";
	                }
	                console.log();
	                tips.style.top = (result.pointY / dpr + radius) + "px";
	            } else {
	                tips.style.display = "none";
	            }
	        });
	    }
	
	    function getMaxAndMin(series){
	
	        var max = 0,
	            min = 0,
	            seriesLength = series.length,
	            tempObj = {};
	        for (var i = 0; i < seriesLength; i++) {
	            for (var j = 0; j < series[i].data.length; j++) {
	                max = Math.max(max, series[i].data[j]);
	                min = Math.min(min, series[i].data[j]);
	            }
	        }
	       
	        tempObj.max = max;
	        tempObj.min = min;
	        return tempObj;
	    }
	    return ChartLine;
	})();
	
	module.exports = ChartLine;


/***/ },
/* 30 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制直角坐标系
	 */
	 var extend = __webpack_require__(6);
	 /*主题*/
	 var theme = __webpack_require__(7);
	 var common = __webpack_require__(8);
	 var DrawXY = (function(){
	    //构造方法
	    function DrawXY(options){
	        /*设置默认参数*/
	        this.defaultoptions = theme.draw_xy;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
	    };
	    /*绘图*/
	    DrawXY.prototype.draw = function(){
	        // var xAxisData = this.options.xaxis;
	        // var yAxisData = this.options.series;
	        // var type = this.options.type;
	        // var dpr = this.options.dpr;
	        var ctx = this.options.context;
	
	        /*Y轴上的最大值*/
	        var y_max = this.options.data.max;
	        /*Y轴上的最小值*/
	        var y_min = this.options.data.min;
	
	        /*Y轴上分隔线数量*/
	        var sepe_num = this.options.sepenum || 10;
	        /*开盘收盘时间数组*/
	        var oc_time_arr = this.options.xaxis;
	
	        /*K线图的高度*/
	        var k_height = this.options.c_1_height;
	        /*Y轴标识线列表*/
	        var line_list_array = getLineList(y_max, y_min, sepe_num, k_height);
	
	        drawXYLine.call(this,ctx,y_max,y_min,line_list_array);
	
	        // 绘制横坐标刻度
	        drawXMark.apply(this,[ctx,k_height,oc_time_arr]);
	    };
	    // 绘制分时图坐标轴最左边刻度
	    function drawXYLine(ctx,y_max,y_min,line_list_array){
	        // var sepe_num = line_list_array.length;
	        ctx.fillStyle = '#b1b1b1';
	        ctx.strokeStyle = '#ccc';
	        ctx.textAlign = 'right';
	
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	            if(i == 0){
	                ctx.moveTo(this.options.padding_left, Math.round(item.y));
	                ctx.lineTo(ctx.canvas.width, Math.round(item.y));
	                ctx.stroke();
	            }
	            // 绘制左侧纵坐标刻度
	            ctx.fillText(common.format_unit(item.num/1,2), this.options.padding_left-10, item.y);
	
	            if(this.options.bothmark){
	                // 绘制右侧纵坐标刻度
	                ctx.fillText(common.format_unit(item.num/1,2), ctx.canvas.width - 10, item.y);
	            }
	            
	            
	        }
	
	    }
	
	    /*绘制横坐标刻度值*/
	    function drawXMark(ctx,k_height,oc_time_arr){
	        // var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        ctx.beginPath();
	        ctx.textAlign = 'center';
	        ctx.fillStyle = '#b1b1b1';
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        // var y_date = this.options.c_1_height;
	        var tempDate;
	        // var timeSpacing = (this.options.width * dpr - padding_left) / oc_time_arr.length + padding_left;
	        var arr_length = oc_time_arr.length;
	
	        for(var i = 0;i<arr_length;i++) {
	            tempDate = oc_time_arr[i];
	            if(tempDate.show == undefined ? true : tempDate.show){
	                if(i < arr_length - 1){
	                    ctx.fillText(tempDate.value.split('-')[0] + "-" + tempDate.value.split('-')[1]+'-'+tempDate.value.split('-')[2], i * (k_width - padding_left) / (arr_length-1) + padding_left, this.options.c_1_height+20);
	                    // ctx.fillText(tempDate.value.split('-')[1]+'-'+tempDate.value.split('-')[2], i * (k_width - padding_left) / (arr_length-1) + padding_left, this.options.c_1_height+40);
	                }
	            }
	
	            if(tempDate.showline == undefined ? true : tempDate.showline && (i == 0 || i == arr_length - 1)){
	                ctx.strokeStyle = '#ccc';
	                ctx.moveTo(i * (k_width - padding_left) / (arr_length-1) + padding_left,0);
	                ctx.lineTo(i * (k_width - padding_left) / (arr_length-1) + padding_left,this.options.c_1_height);
	            }
	
	        }
	
	        // 绘制坐标刻度
	        ctx.stroke();
	    }
	    
	    /*Y轴标识线列表*/
	    function getLineList(y_max, y_min, sepe_num, k_height) {
	        var ratio = (y_max - y_min) / (sepe_num-1);
	        var result = [];
	        for (var i = 0; i < sepe_num; i++) {
	            result.push({
	                num:  (y_min + i * ratio),
	                x: 0,
	                y: k_height - (i / (sepe_num-1)) * k_height
	            });
	        }
	        return result;
	    }
	
	    return DrawXY;
	})();
	
	module.exports = DrawXY;

/***/ },
/* 31 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制折线
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	/*继承*/
	var extend = __webpack_require__(6);
	/*主题*/
	var theme = __webpack_require__(7);
	/*工具*/
	var common = __webpack_require__(8);
	var DrawLine = (function(){
		function DrawLine(options){
			// 设置默认参数
	        this.defaultoptions = theme.drawLine;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        // 绘图
	        this.draw();
		};
		
		// 绘图
		DrawLine.prototype.draw = function(){
	
			var ctx = this.options.context;
			ctx.lineWidth = 1 * this.options.dpr + 1;
			// 折线数据
			var series = this.options.series;
			// 横坐标数据
			// var xaxis = this.options.xaxis;
			for(var i = 0,line;line = series[i]; i++){
				// 填充颜色
				ctx.fillStyle = line.color == undefined ? "#333" : line.color;
				// 画笔颜色
		        ctx.strokeStyle = line.color == undefined ? "#333" : line.color;
	        	drawLine.apply(this,[ctx,line]);
		        			
				if(line.showpoint){
					drawPoint.apply(this,[ctx,line]);
				}
				
			}
			if(this.options.showflag){
				drawLineMark.apply(this,[ctx,series]);
			}
		};
		
		// 绘制折线
		function drawLine(ctx,line){
			// 保存画笔状态
			ctx.save();
	
			var arr = line.data;
	        var arr_length = arr.length;
	
			ctx.beginPath();
	
			for(var i = 0,item;item = arr[i]; i++){
				 var x = ((ctx.canvas.width - this.options.padding_left)/(arr_length-1)) * (i) + this.options.padding_left;
				 var y = common.get_y.call(this,item);
				 if(i == 0){
				 	ctx.moveTo(this.options.padding_left,y);
				 }else if(i == arr_length - 1){
				 	ctx.lineTo(x,y);
				 }else{
				 	ctx.lineTo(x,y);
				 }
			}
			
			// ctx.fill();
			ctx.stroke();
			// 恢复画笔状态
			ctx.restore();
		}
	
		// 绘制折线节点（连接点）
		function drawPoint(ctx,line){
			// 保存画笔状态
			ctx.save();
	
			var arr = line.data;
	        var arr_length = arr.length;
	
	        // 节点（折线连接点半径）
	        var pointRadius = this.options.pointRadius;
	
			for(var i = 0,item;item = arr[i]; i++){
				 ctx.beginPath();
	        	 var x = ((ctx.canvas.width - this.options.padding_left)/(arr_length-1)) * (i) + this.options.padding_left;
				 var y = common.get_y.call(this,item);
				 if(i == 0){
				 	ctx.arc(x, y, pointRadius, 0, Math.PI * 2, true); 
				 	ctx.fill();
				 }else if(i == arr_length - 1){
				 	
				 }else{
				 	ctx.arc(x, y, pointRadius, 0, Math.PI * 2, true); 
				 	ctx.fill();
				 }
			 	 
			}
			// 恢复画笔状态
			ctx.restore();
		}
	
	
	    // 绘制折线标识
	    function drawLineMark(ctx,series){
	    	// 保存画笔状态
			ctx.save();
			var dpr = this.options.dpr;
			var x_middle = ctx.canvas.width/2;
			var wh = this.options.lineMarkWidth * dpr;
			var x_start = 0;
			var y_start = ctx.canvas.height * (7/9 - 1/18);
	
			for(var i = 0,line;line = series[i]; i++){
				ctx.beginPath();
				
				// 画笔颜色
		        ctx.strokeStyle = '#cadef8';
		        var mark_offset = (Math.floor(i/2)) * (wh + 7 * dpr);
		        var text_offset = this.options.font_size * this.options.dpr + (wh-this.options.font_size * this.options.dpr)/2;
				if(i == 0){
					// 填充颜色
					ctx.fillStyle = line.color;
					ctx.rect(x_start + 20,y_start,wh,wh);
					ctx.fill();
					// 填充颜色
					ctx.fillStyle = '#333';
					ctx.fillText(line.name, x_start + wh + 80, y_start + text_offset);
				}else if((i + 1) % 2 == 0){
					// 填充颜色
					ctx.fillStyle = line.color;
			 		ctx.rect(x_middle,y_start + mark_offset,wh,wh);
			 		ctx.fill();
			 		// 填充颜色
					ctx.fillStyle = '#333';
	        		ctx.fillText(line.name, x_middle + wh + 60, y_start + mark_offset + text_offset);
		    	}else{
		    		// 填充颜色
					ctx.fillStyle = line.color;
		    		ctx.rect(x_start + 20,y_start + mark_offset,wh,wh);
		    		ctx.fill();
		    		ctx.fillStyle = '#333';
		    		ctx.fillText(line.name, x_start + wh + 80, y_start + mark_offset + text_offset);
		    	}
			}
			// 恢复画笔状态
			ctx.restore();
	    }
	
		return DrawLine;
	})();
	
	module.exports = DrawLine;

/***/ },
/* 32 */
/***/ function(module, exports) {

	
	    var extend,
	        _extend,
	        _isObject;
	
	    _isObject = function(o){
	        return Object.prototype.toString.call(o) === '[object Object]';
	    }
	
	    _extend = function self(destination, source) {
	        var property;
	        for (property in destination) {
	            //if (destination.hasOwnProperty(property)) {
	            if ( typeof destination[property] != 'undefined') {
	                // 若destination[property]和sourc[property]都是对象，则递归
	                try {
	                   if (_isObject(destination[property]) && _isObject(source[property])) {
	                        self(destination[property], source[property]);
	                    }; 
	                    // 若sourc[property]已存在，则跳过
	                    if (source.hasOwnProperty(property)) {
	                        continue;
	                    } else {
	                        source[property] = destination[property];
	                    }
	                } catch (error) {
	                    
	                }
	                
	
	
	            }
	        }
	    }
	
	    extend = function(){
	        var arr = arguments,
	            result = {},
	            i;
	
	        if (!arr.length) return {};
	
	        for (i = arr.length - 1; i >= 0; i--) {
	            if (_isObject(arr[i])) {
	                _extend(arr[i], result);
	            };
	        }
	
	        arr[0] = result;
	        return result;
	    }
	
	    module.exports = extend;


/***/ },
/* 33 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制季度柱状图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 * }
	 *
	 */
	
	// 绘制坐标轴
	var DrawXY = __webpack_require__(34);
	// 主题
	var theme = __webpack_require__(7);
	// 绘制季度柱状图
	var DrawBar = __webpack_require__(35);
	// 拓展，合并，复制
	var extend = __webpack_require__(32);
	// 水印
	var watermark = __webpack_require__(17);
	// 添加通用工具
	var common = __webpack_require__(8);
	
	var ChartBarQuarter = (function() {
	
	    // 构造函数
	    function ChartBarQuarter(options) {
	        this.defaultoptions = theme.defaulttheme;
	        this.options = extend(this.defaultoptions, options);
	        
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.onChartLoaded = options.onChartLoaded == undefined ? function(op) {
	
	        } : options.onChartLoaded;
	
	    }
	
	    // 初始化
	    ChartBarQuarter.prototype.init = function() {
	
	        this.options.type = "bar-quarter";
	        var canvas = document.createElement("canvas");
	        
	        // 去除画布上粘贴效果
	        //this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable", "on");
	        this.container.style.position = "relative";
	        // 画布
	        try {
	            var ctx = canvas.getContext('2d');
	        } catch (error) {
	            canvas=window.G_vmlCanvasManager.initElement(canvas);
		        var ctx = canvas.getContext('2d');
	        }
	
	
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	
	
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	
	        // 设备像素比
	        var dpr = this.options.dpr = 1;
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / 5 / 4;
	        // 画布内容向坐偏移的距离
	        this.options.c_1_height = 4 * canvas.height / 5;
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0", this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr;
	        this.options.yearUnitSpacing = "0.2";
	        this.options.quarterUnitSpacing = "0.4";
	
	        // 加水印
	        watermark.apply(this,[this.options.context,90,20,82,20]);
	    };
	
	    // 绘图
	    ChartBarQuarter.prototype.draw = function(callback) {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        // 显示loading效果
	        // inter.showLoading();
	        // var _this = this;
	        // 折线数据
	        var series = this.options.series;
	        var canvas = this.options.canvas;
	        var getMaxMinValue = getMaxMark(series);
	        if (getMaxMinValue.min < 0) {
	            this.options.isLessZero = true;
	        }
	        this.options.data = {};
	        this.options.data.max = getMaxMinValue.max;
	        this.options.data.min = getMaxMinValue.min;
	        this.options.padding_left = this.options.context.measureText("+1000").width + 10;
	        this.options.yearUnit = getYearRect.call(this, canvas.width - this.options.padding_left, this.options.series.length);
	        this.options.quarterUnit = getQuarterRect.call(this, this.options.yearUnit.bar_w, 4);
	
	        // 绘制坐标轴
	        new DrawXY(this.options);
	        // 绘制季度柱状图
	        new DrawBar(this.options);
	        //添加交互
	        this.addInteractive();
	
	    };
	    // 单位绘制区域
	    function getYearRect(width, num) {
	        var rect_w = width / num;
	        var bar_w = rect_w * (1 - this.options.yearUnitSpacing);
	        return {
	            rect_w: rect_w,
	            bar_w: bar_w
	        };
	    }
	
	    // 单位绘制区域
	    function getQuarterRect(width, num) {
	        var rect_w = width / num;
	        var bar_w = rect_w * (1 - this.options.quarterUnitSpacing);
	        return {
	            rect_w: rect_w,
	            bar_w: bar_w
	        };
	    }
	
	    // 将鼠标坐标转换为Canvas坐标
	    function windowToCanvas(canvas, x, y) {
	        // var box = canvas.getBoundingClientRect();
	        return {
	            // x:(x-box.left)*(canvas.width/box.width),
	            // y:(y-box.top)*(canvas.height/box.height)
	
	            x: x * this.options.dpr,
	            y: y * this.options.dpr
	        };
	    }
	
	    // 将Canvas坐标转换为鼠标坐标
	    function canvasToWindow(canvas, x, y) {
	        var box = canvas.getBoundingClientRect();
	        // 相对于窗口
	        // return {
	        //     x:(x *(box.width/canvas.width)+box.left),
	        //     y:(y *(box.height/canvas.height)+box.top + this.options.canvas_offset_top/this.options.dpr)
	        // };
	        return {
	            x: x / this.options.dpr,
	            // x:x * (box.width/canvas.width),
	            y: (y + this.options.canvas_offset_top) * (box.height / canvas.height)
	        };
	    }
	
	    // 图表y轴坐标计算
	    function get_y(y) {
	        if (!this.options.isLessZero) {
	            return this.options.c_1_height - (this.options.c_1_height * (y - this.options.data.min) / (this.options.data.max - this.options.data.min));
	        } else {
	            return this.options.c_1_height / 2 - (this.options.c_1_height / 2 * (-y) / (this.options.data.max));
	        }
	    }
	
	    // 图表x轴坐标计算
	    function get_x(year_num, quarter_num) {
	        var canvas = this.options.context.canvas;
	        var yearUnit = this.options.yearUnit;
	        var quarterUnit = this.options.quarterUnit;
	        var total = this.options.series.length;
	        var padding_left = this.options.padding_left;
	        var year_sepe = this.options.yearUnit.rect_w - this.options.yearUnit.bar_w;
	        var quarter_sepe = this.options.quarterUnit.rect_w - this.options.quarterUnit.bar_w;
	        // var dpr = this.options.dpr;
	        return yearUnit.rect_w * year_num + padding_left + quarterUnit.rect_w * quarter_num + year_sepe / 2 + quarter_sepe / 2;
	    }
	
	    //通过clientX获得交互需要的tips的坐标和虚线中x坐标
	    function getCoordinateByClient(clientX) {
	        var canvasX = clientX * this.options.dpr;
	        //被返回的两个数据
	        var result = {};
	
	        //需要用到的参数
	        var paddingLeft = this.options.padding_left,
	            yearUnit = this.options.yearUnit,
	            quarterUnit = this.options.quarterUnit,
	            canvas = this.options.canvas,
	            num = this.options.series.length,
	            series = this.options.series;
	
	        // 求得鼠标所指的位置属于哪一年的哪一个季度
	        var numYear = Math.floor((canvasX - paddingLeft) / yearUnit.rect_w);
	        if (numYear < 0) {
	            numYear = 0;
	        }
	        var numQuarter = Math.floor((canvasX - paddingLeft - numYear * yearUnit.rect_w - (yearUnit.rect_w - yearUnit.bar_w) / 2) / quarterUnit.rect_w);
	        if (numQuarter < 0) {
	            numQuarter = 0;
	        } else if (numQuarter > 3) {
	            numQuarter = 3;
	        }
	        // 绘制的虚线的x坐标
	        result.midddleLine = get_x.call(this, numYear, numQuarter) + quarterUnit.bar_w / 2;
	        //绘制tips的坐标
	        result.tipsX = result.midddleLine + 3 * quarterUnit.bar_w / 4;
	        result.tipsY = get_y.call(this, -series[numYear].data[numQuarter]);
	        if (canvasX > canvas.width / 2) {
	            result.tipsX = result.midddleLine - 3 * quarterUnit.bar_w / 4;
	        }
	        if (this.options.series[numYear].data[numQuarter] < 0) {
	            result.tipsY -= 25;
	        }
	        result.midddleLineHeight = result.tipsY;
	
	        result.content = this.options.series[numYear].data[numQuarter];
	        result.arr = numYear + ":" + numQuarter;
	
	        return result;
	    }
	
	    ChartBarQuarter.prototype.addInteractive = function() {
	        var canvas = this.options.canvas;
	        var yearUnit = this.options.yearUnit;
	        var _that = this;
	        var tips = document.createElement("div");
	        var middleLine = document.createElement("div");
	        var coordinateCanvas, coordinateWindow = {};
	        //用于状态记录
	        var status = "x:x";
	        //用于canvas与windows相互转化
	        var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        var offSetTop = this.options.canvas_offset_top;
	        var yHeight = this.options.c_1_height;
	        var timeId;
	
	        // tips.setAttribute("class", "web-tips");
	        tips.className = "web-tips";
	        middleLine.className = "web-middleLine";
	        // middleLine.setAttribute("class", "web-middleLine");
	        _that.container.appendChild(tips);
	        _that.container.appendChild(middleLine);
	
	        common.addEvent.call(_that, canvas, 'mousemove', function(e) {
	
	            var winX, winY;
	            //浏览器检测，获取到相对元素的x和y
	            if (e.layerX) {
	                winX = e.layerX;
	                winY = e.layerY;
	            } else if (e.x) {
	                winX = e.x;
	                winY = e.y;
	            }
	
	            //当超出坐标系框就不显示交互
	            if (winX >= padding_left && winX < (canvas.width -  (yearUnit.rect_w - yearUnit.bar_w) / 2) && (winY >= offSetTop && winY * dpr < (offSetTop * dpr + yHeight))) {
	                tips.style.display = "inline-block";
	                middleLine.style.display = "inline-block";
	            } else {
	                tips.style.display = "none";
	                middleLine.style.display = "none";
	            }
	            //canvas中是坐标与屏幕坐标之间的相互转换
	            coordinateCanvas = getCoordinateByClient.call(_that, winX);
	            if (status !== coordinateCanvas.arr) {
	                coordinateWindow.midddleLine = common.canvasToWindow.call(_that, canvas, coordinateCanvas.midddleLine, 0);
	                coordinateWindow.tips = common.canvasToWindow.call(_that, canvas, coordinateCanvas.tipsX, coordinateCanvas.tipsY);
	                //绘制tips
	                tips.innerHTML = coordinateCanvas.content;
	                if (winX > canvas.width / 2) {
	                    tips.style.left = (coordinateCanvas.tipsX - tips.clientWidth) + "px";
	                } else {
	                    tips.style.left = (coordinateCanvas.tipsX - tips.style.width) + "px";
	                }
	                // alert(coordinateWindow.tips.y);
	                tips.style.top = (coordinateCanvas.tipsY * dpr + tips.clientHeight) + "px";
	                // var text = createTextNode(coordinateCanvas.content);
	                // tips.appendChild(text);
	                //绘制中线
	                middleLine.style.height = yHeight + "px";
	                middleLine.style.left = coordinateWindow.midddleLine.x + "px";
	                middleLine.style.top = offSetTop + "px";
	                status = coordinateCanvas.arr;
	            }
	
	        });
	
	    };
	
	    // 重绘
	    ChartBarQuarter.prototype.reDraw = function() {
	            // 删除canvas画布
	            this.clear();
	            // 初始化
	            this.init();
	            this.draw();
	        }
	        // 删除canvas画布
	    ChartBarQuarter.prototype.clear = function(cb) {
	        if (this.container) {
	            this.container.innerHTML = "";
	        } else {
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	
	    // 获取数组中的最大值
	    function getMaxMark(series) {
	        var max = 0,
	            min = 0,
	            seriesLength = series.length,
	            tempObj = {};
	        for (var i = 0; i < seriesLength; i++) {
	            for (var j = 0; j < series[i].data.length; j++) {
	                max = Math.max(max, series[i].data[j]);
	                min = Math.min(min, series[i].data[j]);
	            }
	        }
	        if (max < Math.abs(min)) {
	            max = Math.abs(min) + Math.abs(min) / 16;
	        } else {
	            max = max + max / 16;
	        }
	        tempObj.max = max;
	        tempObj.min = min;
	        return tempObj;
	    }
	
	    return ChartBarQuarter;
	})();
	
	module.exports = ChartBarQuarter;


/***/ },
/* 34 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制直角坐标系
	 */
	 var extend = __webpack_require__(32);
	 /*主题*/
	 var theme = __webpack_require__(7);
	 var common = __webpack_require__(8);
	 var DrawXY = (function(){
	    //构造方法
	    function DrawXY(options){
	        /*设置默认参数*/
	        this.defaultoptions = theme.draw_xy;
	        this.options = extend(this.defaultoptions, options);
	        
	        /*绘图*/
	        this.draw();
	    };
	    /*绘图*/
	    DrawXY.prototype.draw = function(){
	        // var xAxisData = this.options.xaxis;
	        // var yAxisData = this.options.series;
	        // var type = this.options.type;
	        // var dpr = this.options.dpr;
	        var ctx = this.options.context;
	        /*Y轴上的最大值*/
	        var y_max = this.options.data.max;
	        /*Y轴上的最小值*/
	        var y_min = 0;
	
	        /*Y轴上分隔线数量*/
	        var sepe_num = 5;
	        /*开盘收盘时间数组*/
	        var oc_time_arr = this.options.xaxis;
	
	        /*K线图的高度*/
	        var k_height = this.options.c_1_height;
	        /*Y轴标识线列表*/
	        var line_list_array = getLineList(y_max, y_min, sepe_num, k_height);
	        // if(this.options.type == 'quarter-line') {
	            addGradient.call(this);
	        // }
	
	        drawXYLine.call(this,ctx,y_max,y_min,line_list_array);
	
	        // 绘制横坐标刻度
	        drawXMark.apply(this,[ctx,k_height,oc_time_arr]);
	    };
	    // 绘制分时图坐标轴最左边刻度
	    function drawXYLine(ctx,y_max,y_min,line_list_array){
	        // var sepe_num = line_list_array.length;
	        ctx.fillStyle = '#000';
	        ctx.strokeStyle = '#eeeeee';
	        ctx.textAlign = 'right';
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	            ctx.moveTo(this.options.padding_left, Math.round(item.y));
	            ctx.lineTo(ctx.canvas.width, Math.round(item.y));
	            var absPoint = Math.max(this.options.data.max,Math.abs(this.options.data.min));
	            absPoint = absPoint.toFixed(0);
	            // 绘制纵坐标刻度
	            if(this.options.data.min < 0) {
	               if(i == 0){
	
	                ctx.fillText(common.format_unit(-absPoint +i * absPoint / 2,0), this.options.padding_left - 10, item.y);
	            }
	            else {
	                ctx.fillText(common.format_unit(-absPoint +i * absPoint / 2,0), this.options.padding_left - 10, item.y + 10);
	            }
	        }
	        else {
	         if(i == 0){
	
	            ctx.fillText(common.format_unit((i*absPoint / 4).toFixed(0),0), this.options.padding_left - 10, item.y);
	        }
	        else {
	            ctx.fillText(common.format_unit((i*this.options.data.max / 4).toFixed(0),0), this.options.padding_left - 10, item.y +10);
	        }
	    }
	
	    ctx.stroke();
	}
	
	}
	
	/*绘制横坐标刻度值*/
	function drawXMark(ctx,k_height,oc_time_arr){
	        // var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        ctx.beginPath();
	        ctx.strokeStyle = "#9f9f9f";
	        ctx.rect(padding_left,0,ctx.canvas.width -padding_left,this.options.c_1_height);
	        ctx.stroke();
	        ctx.closePath();
	        ctx.beginPath();
	        ctx.textAlign = 'left';
	        ctx.fillStyle = '#000';
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        var tempDate;
	        var arr_length = oc_time_arr.length;
	        for(var i = 0;i<arr_length;i++) {
	            tempDate = oc_time_arr[i].value;
	            ctx.fillText(tempDate, i * (k_width - padding_left) / (arr_length) +padding_left + (((k_width - padding_left) / (arr_length) - ctx.measureText(tempDate).width)/2), this.options.c_1_height+30);      
	        }
	        ctx.stroke();
	        ctx.closePath();
	
	
	
	    }
	
	    function addGradient(){
	        var sepGradientLen = (this.options.canvas.width - this.options.padding_left) / this.options.series.length;
	        var ctx = this.options.context;
	        for(var i = 0;i < this.options.series.length;i++) {
	            if(i % 2 == 0) {
	             ctx.beginPath();
	             var grad  = ctx.createLinearGradient(0,0,0,this.options.c_1_height);
	             grad.addColorStop(0,'rgba(255,255,255,0)');
	             grad.addColorStop(1,'rgba(245,245,245,1)');
	             ctx.fillStyle = grad;
	             ctx.rect(this.options.padding_left + i * sepGradientLen,0,sepGradientLen,this.options.c_1_height);
	             ctx.fill();
	             ctx.closePath();
	         }
	
	     }
	 }
	
	 /*Y轴标识线列表*/
	 function getLineList(y_max, y_min, sepe_num, k_height) {
	    var ratio = (y_max - y_min) / (sepe_num-1);
	    var result = [];
	    for (var i = 0; i < sepe_num; i++) {
	        result.push({
	            num:  (y_min + i * ratio),
	            x: 0,
	            y: k_height - (i / (sepe_num-1)) * k_height
	        });
	    }
	    return result;
	}
	
	return DrawXY;
	})();
	
	module.exports = DrawXY;

/***/ },
/* 35 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制K线
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	/*继承*/
	var extend = __webpack_require__(32);
	/*主题*/
	var theme = __webpack_require__(7);
	/*工具*/
	var common = __webpack_require__(8);
	var DrawBar = (function(){
	    function DrawBar(options){
	        // 设置默认参数
	        this.defaultoptions = theme.drawLine;
	        this.options = extend(this.defaultoptions, options);
	        
	        // 绘图
	        this.draw();
	    };
	    
	    // 绘图
	    DrawBar.prototype.draw = function(){
	
	        var ctx = this.options.context;
	        ctx.lineWidth = 1 * this.options.dpr + 1;
	        // 折线数据
	        var series = this.options.series;
	        // 横坐标数据
	        var xaxis = this.options.xaxis;
	
	        for(var i = 0,se;se = series[i]; i++){
	           
	            var bar_arr = se.data;
	
	            for(var j = 0,bar;bar = bar_arr[j]; j++){
	                ctx.beginPath();
	                // 填充颜色
	                ctx.fillStyle = xaxis[i].colors[j] == undefined ? "#333" : xaxis[i].colors[j];
	                // 画笔颜色
	                ctx.strokeStyle = xaxis[i].colors[j] == undefined ? "#333" : xaxis[i].colors[j];
	                var x = get_x.apply(this,[i,j]);
	                var y = get_y.call(this,bar);
	                if(!this.options.isLessZero){
	                    ctx.rect(x,y,this.options.quarterUnit.bar_w,this.options.c_1_height - y);
	                }else{
	                    ctx.rect(x,this.options.c_1_height/2,this.options.quarterUnit.bar_w,this.options.c_1_height/2 - y);
	                }
	                ctx.fill();
	            }
	            
	        }
	     
	    };
	
	    // 图表y轴坐标计算
	    function get_y(y) {
	        if(!this.options.isLessZero){
	            return this.options.c_1_height - (this.options.c_1_height * (y - this.options.data.min)/(this.options.data.max - this.options.data.min));
	        }else{
	            return this.options.c_1_height/2 - (this.options.c_1_height/2 * (-y)/(this.options.data.max));        
	        }
	    }
	    // 图表x轴坐标计算
	    function get_x(year_num,quarter_num) {
	        var canvas = this.options.context.canvas;
	        var yearUnit = this.options.yearUnit;
	        var quarterUnit = this.options.quarterUnit;
	        var total = this.options.series.length;
	        var padding_left = this.options.padding_left;
	        var year_sepe = this.options.yearUnit.rect_w - this.options.yearUnit.bar_w;
	        var quarter_sepe = this.options.quarterUnit.rect_w - this.options.quarterUnit.bar_w;
	        // var dpr = this.options.dpr;
	        return yearUnit.rect_w * year_num + padding_left + quarterUnit.rect_w * quarter_num + year_sepe/2 + quarter_sepe/2;
	    }
	
	    return DrawBar;
	})();
	
	module.exports = DrawBar;

/***/ },
/* 36 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制季度折线图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	
	 * }
	 *
	 */
	
	// 绘制坐标轴
	var DrawXY = __webpack_require__(34);
	// 主题
	var theme = __webpack_require__(7);
	// 绘制季度折线图
	var DrawLine = __webpack_require__(37);
	// 拓展，合并，复制
	var extend = __webpack_require__(32);
	// 水印
	var watermark = __webpack_require__(17);
	// 添加通用工具
	var common = __webpack_require__(8);
	
	var ChartBarQuarter = (function() {
	
	    // 构造函数
	    function ChartBarQuarter(options) {
	        this.defaultoptions = theme.defaulttheme;
	        this.options = extend(this.defaultoptions, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.onChartLoaded = options.onChartLoaded == undefined ? function(op) {
	
	        } : options.onChartLoaded;
	
	    }
	
	    // 初始化
	    ChartBarQuarter.prototype.init = function() {
	
	        this.options.type = "quarter-line";
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        // this.container.style = "-moz-user-select:none;-webkit-user-select:none;";
	        // this.container.setAttribute("unselectable", "on");
	        this.container.style.position = "relative";
	        // 画布
	        try {
	            var ctx = canvas.getContext('2d');
	        } catch (error) {
	            canvas = window.G_vmlCanvasManager.initElement(canvas);
	            var ctx = canvas.getContext('2d');
	        }
	
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr = 1;
	
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / 5 / 4;
	        // 画布内容向坐偏移的距离
	        this.options.c_1_height = 4 * canvas.height / 5;
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0", this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr;
	        this.options.yearUnitSpacing = "0.2";
	        this.options.quarterUnitSpacing = "0.4";
	
	        // 加水印
	        watermark.apply(this,[this.options.context,90,20,82,20]);
	    };
	
	    // 绘图
	    ChartBarQuarter.prototype.draw = function(callback) {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        // 显示loading效果
	        // inter.showLoading();
	        // var _this = this;
	        // 折线数据
	        var series = this.options.series;
	        var canvas = this.options.canvas;
	        var getMaxMinValue = getMaxMark(series);
	        if (getMaxMinValue.min < 0) {
	            this.options.isLessZero = true;
	        }
	        this.options.data = {};
	        this.options.data.max = getMaxMinValue.max;
	        this.options.data.min = getMaxMinValue.min;
	        this.options.padding_left = this.options.context.measureText("+10000").width + 10;;
	        this.options.yearUnit = getYearRect.call(this, canvas.width - this.options.padding_left, this.options.series.length);
	        this.options.quarterUnit = getQuarterRect.call(this, this.options.yearUnit.bar_w, 4);
	
	        // 绘制坐标轴
	        new DrawXY(this.options);
	        // 绘制季度折线图
	        new DrawLine(this.options);
	        //添加交互
	        this.addInteractive();
	
	    };
	    // 单位绘制区域
	    function getYearRect(width, num) {
	        var rect_w = width / num;
	        var bar_w = rect_w * (1 - this.options.yearUnitSpacing);
	        return {
	            rect_w: rect_w,
	            bar_w: bar_w
	        };
	    }
	
	    // 单位绘制区域
	    function getQuarterRect(width, num) {
	        var rect_w = width / num;
	        var bar_w = rect_w * (1 - this.options.quarterUnitSpacing);
	        return {
	            rect_w: rect_w,
	            bar_w: bar_w
	        };
	    }
	
	    // 将鼠标坐标转换为Canvas坐标
	    function windowToCanvas(canvas, x, y) {
	        // var box = canvas.getBoundingClientRect();
	        return {
	            // x:(x-box.left)*(canvas.width/box.width),
	            // y:(y-box.top)*(canvas.height/box.height)
	
	            x: x * this.options.dpr,
	            y: y * this.options.dpr
	        };
	    }
	    // 将Canvas坐标转换为鼠标坐标
	    function canvasToWindow(canvas, x, y) {
	        var box = canvas.getBoundingClientRect();
	        // 相对于窗口
	        // return {
	        //     x:(x *(box.width/canvas.width)+box.left),
	        //     y:(y *(box.height/canvas.height)+box.top + this.options.canvas_offset_top/this.options.dpr)
	        // };
	        return {
	            x: x / this.options.dpr,
	            // x:x * (box.width/canvas.width),
	            y: (y + this.options.canvas_offset_top) * (box.height / canvas.height)
	        };
	    }
	    // 图表y轴坐标计算
	    function get_y(y) {
	        if (!this.options.isLessZero) {
	            return this.options.c_1_height - (this.options.c_1_height * (y - this.options.data.min) / (this.options.data.max - this.options.data.min));
	        } else {
	            return this.options.c_1_height / 2 - (this.options.c_1_height / 2 * (-y) / (this.options.data.max));
	        }
	    }
	    // 图表x轴坐标计算
	    function get_x(year_num, quarter_num) {
	        var canvas = this.options.context.canvas;
	        var quarterUnit = this.options.quarterUnit;
	        var total = this.options.series.length;
	        var padding_left = this.options.padding_left;
	        // var dpr = this.options.dpr;
	
	        return (canvas.width - padding_left) / total * year_num + padding_left + quarterUnit.rect_w * quarter_num + quarterUnit.rect_w / 2;
	    }
	
	    //通过clientX获得交互需要的tips的坐标和虚线中x坐标
	    function getCoordinateByClient(clientX) {
	        var canvasX = windowToCanvas.call(this, this.options.canvas, clientX, 0).x;
	        //被返回的两个数据
	        var result = {};
	
	        //需要用到的参数
	        var paddingLeft = this.options.padding_left,
	            yearUnit = this.options.yearUnit,
	            quarterUnit = this.options.quarterUnit,
	            canvas = this.options.canvas,
	            num = this.options.series.length;
	
	        // 求得鼠标所指的位置属于哪一年的哪一个季度
	        var numYear = Math.floor((canvasX - paddingLeft) / yearUnit.rect_w);
	        if (numYear < 0) {
	            numYear = 0;
	        }
	        var numQuarter = Math.floor((canvasX - paddingLeft - numYear * yearUnit.rect_w - (yearUnit.rect_w - yearUnit.bar_w) / 2) / quarterUnit.rect_w);
	        if (numQuarter < 0) {
	            numQuarter = 0;
	        } else if (numQuarter > 3) {
	            numQuarter = 3;
	        }
	
	        // 绘制的虚线的x坐标
	        result.midddleLine = get_x.call(this, numYear, numQuarter) + 3 * quarterUnit.bar_w / 4;
	        //绘制tips的坐标
	        result.tipsX = result.midddleLine + quarterUnit.bar_w / 2;
	        result.tipsY = get_y.call(this, -this.options.series[numYear].data[numQuarter]);
	        if (clientX > canvas.width / 2) {
	            result.tipsX = result.midddleLine - quarterUnit.bar_w / 2;
	        }
	
	
	        result.midddleLineHeight = result.tipsY;
	
	        result.content = this.options.series[numYear].data[numQuarter];
	        result.arr = numYear + ":" + numQuarter;
	
	        return result;
	    }
	
	
	    //添加交互
	    ChartBarQuarter.prototype.addInteractive = function() {
	        var canvas = this.options.canvas;
	        var yearUnit = this.options.yearUnit;
	        var _that = this;
	        var tips = document.createElement("div");
	        var middleLine = document.createElement("div");
	        var interactiveInfo, coordinateWindow = {};
	        //用于状态记录
	        var status = "x:x";
	        //用于canvas与windows相互转化
	        var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        var offSetTop = this.options.canvas_offset_top;
	        var yHeight = this.options.c_1_height;
	        var timeId;
	
	        tips.className =  "web-tips";
	        middleLine.className = "web-middleLine";
	
	        _that.container.appendChild(tips);
	        _that.container.appendChild(middleLine);
	
	        common.addEvent.call(_that, canvas, "mousemove", function(e) {
	            var winX, winY;
	            //浏览器检测，获取到相对元素的x和y
	            if (e.layerX) {
	                winX = e.layerX;
	                winY = e.layerY;
	            } else if (e.x) {
	                winX = e.x;
	                winY = e.y;
	            }
	            //当超出坐标系框就不显示交互
	            if (winX >= padding_left && winX < (canvas.width -  (yearUnit.rect_w - yearUnit.bar_w) / 2) && (winY >= offSetTop && winY * dpr < (offSetTop * dpr + yHeight))) {
	                tips.style.display = "inline-block";
	                middleLine.style.display = "inline-block";
	            } else {
	                tips.style.display = "none";
	                middleLine.style.display = "none";
	            }
	            //获取交互的信息，包括tips的坐标，middline的坐标和tips的内容
	            interactiveInfo = getCoordinateByClient.call(_that, winX);
	
	            if (status !== interactiveInfo.arr) {
	                coordinateWindow.midddleLine = canvasToWindow.call(_that, canvas, interactiveInfo.midddleLine, 0);
	                coordinateWindow.tips = canvasToWindow.call(_that, canvas, interactiveInfo.tipsX, interactiveInfo.tipsY);
	                //绘制tips
	                tips.innerHTML = interactiveInfo.content;
	                if (winX > canvas.width / 2) {
	                    tips.style.left = (coordinateWindow.tips.x - tips.clientWidth) + "px";
	                } else {
	                    tips.style.left = (coordinateWindow.tips.x - tips.style.width) + "px";
	                }
	                tips.style.top = (interactiveInfo.tipsY * dpr + tips.clientHeight) + "px";
	
	                //绘制中线
	                middleLine.style.height = yHeight + "px";
	                middleLine.style.left = coordinateWindow.midddleLine.x + "px";
	                middleLine.style.top = offSetTop + "px";
	                status = interactiveInfo.arr;
	            }
	        });
	
	    };
	
	    // 重绘
	    ChartBarQuarter.prototype.reDraw = function() {
	            // 删除canvas画布
	            this.clear();
	            // 初始化
	            this.init();
	            this.draw();
	        }
	        // 删除canvas画布
	    ChartBarQuarter.prototype.clear = function(cb) {
	        if (this.container) {
	            this.container.innerHTML = "";
	        } else {
	            document.getElementById(this.options.container).innerHTML = "";
	        }
	        if (cb) {
	            cb();
	        };
	    }
	
	    // 获取数组中的最大值
	    function getMaxMark(series) {
	        var max = 0,
	            min = 0,
	            seriesLength = series.length,
	            tempObj = {};
	        for (var i = 0; i < seriesLength; i++) {
	            for (var j = 0; j < series[i].data.length; j++) {
	                max = Math.max(max, series[i].data[j]);
	                min = Math.min(min, series[i].data[j]);
	            }
	        }
	        if (max < Math.abs(min)) {
	            max = Math.abs(min) + Math.abs(min) / 16;
	        } else {
	            max = max + max / 16;
	        }
	        tempObj.max = max;
	        tempObj.min = min;
	        return tempObj;
	    }
	
	    return ChartBarQuarter;
	})();
	
	module.exports = ChartBarQuarter;


/***/ },
/* 37 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制折线图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 * }
	 *
	 */
	
	/*继承*/
	var extend = __webpack_require__(6);
	/*主题*/
	var theme = __webpack_require__(7);
	/*工具*/
	var common = __webpack_require__(8);
	var DrawQuarterLine = (function(){
	    function DrawQuarterLine(options){
	        // 设置默认参数
	        this.defaultoptions = theme.drawLine;
	        this.options = {};
	        extend(false,this.options, this.defaultoptions, options);
	        // 绘图  
	        this.draw();
	    };
	    
	    // 绘图
	    DrawQuarterLine.prototype.draw = function(){
	
	        var ctx = this.options.context;
	        ctx.lineWidth = 1 * this.options.dpr;
	        // 折线数据
	        var series = this.options.series;
	        // 横坐标数据
	        var xaxis = this.options.xaxis;
	        ctx.beginPath();
	        // 画笔颜色
	        ctx.strokeStyle = this.options.line.color == undefined ? "#333" : this.options.line.color;
	
	        for(var i = 0,se;se = series[i]; i++){
	           
	            var line_arr = se.data;
	
	            for(var j = 0,line;line = line_arr[j]; j++){
	                
	                var x = get_x.apply(this,[i,j]);
	                var y = get_y.call(this,line);
	                if(i == 0 && j == 0){
	                    ctx.moveTo(x,y);
	                }else{
	                    ctx.lineTo(x,y);
	                }
	        
	            }
	        }
	        ctx.stroke();
	
	        if(this.options.point && this.options.point.show){
	            drawPoint.apply(this,[ctx,series,this.options.point.color]);
	        }
	     
	    };
	
	    // 绘制折线节点（连接点）
	    function drawPoint(ctx,series,color){
	        // 保存画笔状态
	        ctx.save();
	
	        // 横坐标数据
	        var xaxis = this.options.xaxis;
	        // 节点（折线连接点半径）
	        var pointRadius = this.options.point.pointradius;
	        // 填充颜色
	        ctx.fillStyle = color == undefined ? "#333" : color;
	
	        for(var i = 0,se;se = series[i]; i++){
	            var line_arr = se.data;
	            for(var j = 0,line;line = line_arr[j]; j++){
	                ctx.beginPath();
	                var x = get_x.apply(this,[i,j]);
	                var y = get_y.call(this,line);
	                ctx.arc(x, y, pointRadius, 0, Math.PI * 2, true); 
	                ctx.fill();
	            }
	            
	        }
	
	        // 恢复画笔状态
	        ctx.restore();
	    }
	
	    // 图表y轴坐标计算
	    function get_y(y) {
	        if(!this.options.isLessZero){
	            return this.options.c_1_height - (this.options.c_1_height * (y - this.options.data.min)/(this.options.data.max - this.options.data.min));
	        }else{
	            return this.options.c_1_height/2 - (this.options.c_1_height/2 * (y)/(this.options.data.max));  
	        }
	    }
	    // 图表x轴坐标计算
	    function get_x(year_num,quarter_num) {
	        var canvas = this.options.context.canvas;
	        var yearUnit = this.options.yearUnit;
	        var quarterUnit = this.options.quarterUnit;
	        var total = this.options.series.length;
	        var padding_left = this.options.padding_left;
	        var year_sepe = this.options.yearUnit.rect_w - this.options.yearUnit.bar_w;
	        var quarter_sepe = this.options.quarterUnit.rect_w - this.options.quarterUnit.bar_w;
	        // var dpr = this.options.dpr;
	        return yearUnit.rect_w * year_num + padding_left + quarterUnit.rect_w * quarter_num + year_sepe;
	    }
	
	    return DrawQuarterLine;
	})();
	
	module.exports = DrawQuarterLine;

/***/ },
/* 38 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制web分时图
	 *
	 */
	
	// 绘制坐标轴
	var DrawXY = __webpack_require__(39);
	// 主题
	var theme = __webpack_require__(7);
	// 获取分时图数据
	var GetDataTime = __webpack_require__(41);
	var getChangePointData = __webpack_require__(43);
	// 工具
	var common = __webpack_require__(44);
	var draw_dash = __webpack_require__(40);
	// 拓展，合并，复制
	var extend = __webpack_require__(32);
	// 交互效果
	var Interactive = __webpack_require__(45);
	// 水印
	var watermark = __webpack_require__(17);
	
	var ChartTime = (function() {
	
	    // 构造函数
	    function ChartTime(options) {
	        this.defaultoptions = theme.draw_xy_web;
	        this.options = {};
	        // this.options = extend(this.defaultoptions, options);
	        this.options = extend(this.defaultTheme, this.options, this.defaultoptions, options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.onChartLoaded = options.onChartLoaded == undefined ? function(op) {
	
	        } : options.onChartLoaded;
	
	    }
	
	    // 初始化
	    ChartTime.prototype.init = function() {
	
	        this.options.chartType = "TL";
	        var canvas = document.createElement("canvas");
	
	        this.container.style.position = "relative";
	        // 画布
	        try {
	            var ctx = canvas.getContext('2d');
	        } catch (error) {
	            canvas = window.G_vmlCanvasManager.initElement(canvas);
	            var ctx = canvas.getContext('2d');
	        }
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr;
	
	        // 容器中添加画布
	        this.container.appendChild(canvas);
	
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	        // 画布向下偏移的距离
	        this.options.canvas_offset_top = canvas.height / 8;
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / 8;
	        // 缩放默认值
	        this.options.scale_count = 0;
	        // 画布上第一个图表的高度
	        this.options.c_k_height = this.options.c_1_height = canvas.height * 0.5;
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 画布上部内间距
	        ctx.translate("0", this.options.canvas_offset_top);
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr;
	        ctx.strokeStyle = 'rgba(230,230,230, 1)';
	
	        this.options.padding = {};
	        this.options.padding.left = ctx.measureText("10000").width + 20;
	        this.options.padding.right = ctx.measureText("10000").width;
	        this.options.padding.top = 0;
	        this.options.padding.bottom = 0;
	
	
	    };
	
	    // 绘图
	    ChartTime.prototype.draw = function(callback) {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        // 初始化交互
	        var inter = this.options.interactive = new Interactive(this.options);
	        // 显示loading效果
	        inter.showLoading();
	        var _this = this;
	        var param = {
	            code: this.options.code,
	            type: this.options.type,
	            isCR: this.options.isCR
	        };
	        try {
	
	            GetDataTime(param,
	                function(error, data) {
	                    if (error) {
	                        // 暂无数据
	                        inter.showNoData();
	                        // 隐藏loading效果
	                        inter.hideLoading();
	                    } else {
	                        if (data) {
	                            dataCallback.apply(_this, [data]);
	                        } else {
	                            dataCallback.apply(_this, [
	                                []
	                            ]);
	                        }
	                        /*绑定事件*/
	                        bindEvent.call(_this, _this.options.context);
	                        // 传入的回调函数
	                        if (callback) {
	                            callback();
	                        }
	                    }
	                });
	        } catch (e) {
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	
	    };
	    // 重绘
	    ChartTime.prototype.reDraw = function() {
	            // 删除canvas画布
	            this.clear();
	            // 初始化
	            this.init();
	            dataCallback.call(this);
	        }
	        /*删除canvas画布*/
	    ChartTime.prototype.clear = function(cb) {
	            if (this.container) {
	                this.container.innerHTML = "";
	            } else {
	                document.getElementById(this.options.container).innerHTML = "";
	            }
	            if (cb) {
	                cb();
	            };
	        }
	        /*回调函数*/
	    function dataCallback(data) {
	
	        this.options.data = data == undefined ? this.options.data : data;
	
	        // 图表交互
	        var inter = this.options.interactive;
	
	        try {
	            if (!data || !data.data || data.data.length == 0) {
	                // 隐藏loading效果
	                // inter.hideLoading();
	                // 暂无数据
	                // inter.showNoData();
	                // return;
	            }
	
	            // 保留的小数位
	            this.options.pricedigit = data.pricedigit;
	            // 获取单位绘制区域
	            var rect_unit = common.get_rect.apply(this, [this.options.context.canvas, this.options.data.total]);
	            this.options.rect_unit = rect_unit;
	
	            // 绘制坐标轴
	            new DrawXY(this.options);
	            //绘制分时图
	            draw_line.call(this);
	            //绘制平均成本线
	            draw_avg.call(this);
	            //绘制交易量
	            draw_v.call(this);
	            //绘制盘口动态
	            draw_positionChange.call(this);
	            // 隐藏loading效果
	            inter.hideLoading();
	            inter.showTipsTime(0, 0, data.data, data.data.length - 1);
	            // 图表加载完成时间
	            this.onChartLoaded(this);
	
	        } catch (e) {
	            // 暂无数据
	            // inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	            console.log(e);
	        }
	
	        // 加水印
	        watermark.apply(this, [this.options.context, 170, 20 - this.options.canvas.height / 8]);
	
	        return true;
	    }
	
	    // 绑定事件
	    function bindEvent(ctx) {
	        var _this = this;
	        var timer_s, timer_m;
	        var canvas = ctx.canvas;
	        var inter = this.options.interactive;
	
	        var delayed = false;
	        var delaytouch = this.options.delaytouch = true;;
	
	        // if(!delaytouch){
	        common.addEvent.call(_this, canvas, "mousemove", function(event) {
	            dealEvent.apply(_this, [inter, event]);
	            try {
	                event.preventDefault();
	            } catch (e) {
	                event.returnValue = false;
	            }
	        });
	
	        common.addEvent.call(_this, canvas, "mouseleave", function(event) {
	            inter.hide();
	            try {
	                event.preventDefault();
	            } catch (e) {
	                event.returnValue = false;
	            }
	        });
	
	        common.addEvent.call(_this, canvas, "mouseenter", function(event) {
	            dealEvent.apply(_this, [inter, event]);
	            try {
	                event.preventDefault();
	            } catch (e) {
	                event.returnValue = false;
	            }
	        });
	
	        // }
	
	    }
	    // 处理交互事件
	    function dealEvent(inter, eventposition) {
	        inter.show();
	        // 画布对象
	        var canvas = this.options.canvas;
	        // 分时行情数据
	        var time_data = this.options.data.data;
	        // 单位绘制区域
	        var rect_unit = this.options.rect_unit;
	        // 单位绘图区域的宽度
	        var rect_w = rect_unit.rect_w;
	        // K线柱体的宽度
	        // var bar_w = rect_unit.bar_w;
	        // 鼠标事件位置
	        var w_x = (eventposition.clientX - this.container.getBoundingClientRect().left);
	        var w_y = (eventposition.clientY - this.container.getBoundingClientRect().top);
	
	        // 鼠标在画布中的坐标
	        var c_pos = common.windowToCanvas.apply(this, [canvas, w_x, w_y]);
	        var c_x = (c_pos.x * 1.0).toFixed(0);
	        // var c_y = (c_pos.y).toFixed(0);
	
	        // 当前点在数组中的下标
	        var index = Math.floor((c_x - this.options.padding.left) / rect_w);
	
	        if (time_data[index]) {
	            // 显示十字指示线的
	            var cross = common.canvasToWindow.apply(this, [canvas, time_data[index].cross_x, time_data[index].cross_y]);
	            var cross_w_x = cross.x;
	            var cross_w_y = cross.y;
	            inter.crossTime(canvas, cross_w_x, cross_w_y);
	            /*显示交互数据*/
	            inter.showTipsTime(cross_w_x, cross_w_y, time_data, index);
	        }
	
	    }
	    //绘制分时图折线
	    function draw_line() {
	        var ctx = this.options.context;
	        var data = this.options.data;
	        var data_arr = data.data;
	
	        drawStroke.apply(this, [ctx, data_arr]);
	        drawFill.apply(this, [ctx, data_arr]);
	
	        /*绘制分时线*/
	        function drawStroke(ctx, data_arr) {
	            ctx.beginPath();
	            ctx.strokeStyle = "#639EEA";
	
	            var arrs = [];
	            for (var i = 0, item; item = data_arr[i]; i++) {
	                var point = {};
	                var x = common.get_x.call(this, i + 1);
	                var y = common.get_y.call(this, item.price);
	                ctx.lineTo(x, y);
	                item.cross_x = x;
	                item.cross_y = y;
	            }
	            ctx.stroke();
	        }
	        /*分时线填充渐变色*/
	        function drawFill(ctx, data_arr) {
	            var y_min = common.get_y.call(this, this.options.data.min);
	            /* 指定渐变区域 */
	            var grad = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
	            /* 指定几个颜色 */
	            grad.addColorStop(0, 'rgba(200,234,250,0.7)');
	            grad.addColorStop(1, 'rgba(255,255,255,0)');
	            var data_arr_length = data_arr.length;
	
	            ctx.beginPath();
	            ctx.fillStyle = grad;
	            ctx.moveTo(this.options.padding.left, y_min);
	            for (var i = 0, item; item = data_arr[i]; i++) {
	                var x = common.get_x.call(this, i + 1);
	                var y = common.get_y.call(this, item.price);
	                if (i == data_arr_length - 1) {
	                    ctx.lineTo(x, y_min);
	                } else {
	                    ctx.lineTo(x, y);
	                }
	            }
	            ctx.fill();
	        }
	
	    }
	    //绘制平均成本
	    function draw_avg() {
	        var ctx = this.options.context;
	        var data = this.options.data;
	        ctx.save();
	        this.options.avg_cost_color = theme.draw_line.avg_cost_color;
	        var color = this.options.avg_cost_color;
	        var data_arr = data.data;
	        // var w = this.options.width - 30;
	        ctx.beginPath();
	        ctx.lineWidth = 1;
	        ctx.strokeStyle = color;
	        ctx.fillStyle = '';
	        for (var i = 0; i < data_arr.length; i++) {
	            var x = common.get_x.call(this, i + 1);
	            var y = common.get_y.call(this, data_arr[i].avg_cost);
	            if (i == 0) {
	                ctx.moveTo(x, y);
	            } else {
	                ctx.lineTo(x, y);
	            }
	        }
	        ctx.stroke();
	        ctx.restore();
	    }
	
	    //绘制成交量
	    function draw_v() {
	
	        var that = this;
	        drawVTime.call(that);
	        /*绘制分时图成交量*/
	        function drawVTime() {
	            var ctx = this.options.context;
	            var data = this.options.data;
	            /*成交量数组*/
	            var data_arr = data.data;
	            /*最大成交量*/
	            var v_max = (data.v_max).toFixed(0);
	
	            var v_height = ctx.canvas.height / 4;
	
	            var v_base_height = v_height * 0.9;
	            var y_v_bottom = ctx.canvas.height - this.options.canvas_offset_top;
	            var y_v_top = y_v_bottom - v_height;
	            /*获取单位矩形对象*/
	            var rect_unit = this.options.rect_unit;
	
	            var bar_w = rect_unit.bar_w;
	            /*K线柱体的颜色*/
	            var up_color = this.options.up_color;
	            var down_color = this.options.down_color;
	            //标识最大成交量
	            ctx.beginPath();
	            ctx.strokeStyle = '#999';
	            var padding_left = this.options.padding.left;
	            var padding_right = this.options.padding.right;
	
	            ctx.lineWidth = 1;
	            //写字
	            ctx.fillStyle = "#666";
	            for (var i = 0; i < 3; i++) {
	                ctx.fillText(common.format_unit(Math.floor(v_max / 3 * (3 - i))), 10, y_v_top + v_height / 3 * i + 10);
	                if (i != 0) {
	                    draw_dash(ctx, padding_left, y_v_top + v_height / 3 * i, ctx.canvas.width - padding_right, y_v_top + v_height / 3 * i, 5);
	                }
	            }
	            ctx.fill();
	            ctx.strokeStyle = 'rgba(230,230,230, 1)';
	            ctx.lineWidth = 1;
	            ctx.rect(this.options.padding.left + 0.5, y_v_top - 0.5, ctx.canvas.width - this.options.padding.left - 2 - this.options.padding.right, v_height);
	            ctx.stroke();
	            for (var i = 0, item; item = data_arr[i]; i++) {
	                var volume = item.volume;
	                var is_up = item.up;
	                var bar_height = volume / v_max * v_base_height;
	                var x = common.get_x.call(this, i + 1);
	                var y = y_v_bottom - bar_height;
	
	                ctx.beginPath();
	                ctx.moveTo(x, y);
	
	                if (i == 0) {
	                    if (is_up) {
	                        ctx.fillStyle = up_color;
	                        ctx.strokeStyle = up_color;
	                    } else {
	                        ctx.fillStyle = down_color;
	                        ctx.strokeStyle = down_color;
	                    }
	                } else {
	                    if (item.price >= data_arr[i - 1].price) {
	                        ctx.fillStyle = up_color;
	                        ctx.strokeStyle = up_color;
	                    } else {
	                        ctx.fillStyle = down_color;
	                        ctx.strokeStyle = down_color;
	                    }
	                }
	
	                ctx.rect(x - bar_w / 2, y, bar_w, bar_height);
	                ctx.stroke();
	                ctx.fill();
	            }
	
	        }
	    }
	
	    //绘制盘口异动的流程逻辑函数
	    function draw_positionChange() {
	        // debugger;
	        //所有盘口移动的状态对应的图标
	
	        var _that = this;
	        var changeIconHeight = _that.options.canvas_offset_top+_that.options.c_1_height - 40;
	        getChangePointData(this.options.code, function(error, data) {
	            if (error) {} else {
	                if (data[0].state === "false") {
	                    return; }
	                //分时数据
	                var timeData_arr = _that.options.data.data;
	                var timeIndex = Math.floor(timeData_arr.length/242-1)*242;
	                //两个并行的循环，找到绘制盘口异动的点
	                for (var i = data.length - 1; i >= 0; i--) {
	                    var item = data[i].split(",");
	                    //异动的相关信息
	                    var positionChangeItem = {
	                        changeTime : item[1],
	                        changeName : item[2],
	                        changeType : item[3],
	                        changeInfo : item[4],
	                        isProfit : item[5]
	                    };
	
	                    var changeTime = item[1];
	                    var changeImg = "../modules/images/" + typeToImgMap(item[3]);
	                    
	                    for (; timeIndex < timeData_arr.length; timeIndex++) {
	                        //如果检测到该时间点上有盘口异动，就绘制盘口异动图标
	                        if (changeTime == _that.options.data.data[timeIndex].time) {
	                            drawIcon(_that.container, common.get_x.call(_that, timeIndex + 1), changeIconHeight, changeImg, positionChangeItem)//绘制盘口异动
	                            break;
	                        }
	                    }
	                }
	            }
	        });
	
	        //绘制盘口动态的图标,并且添加交互
	        function drawIcon(container, x, y, imgUrl, info) {
	            
	            var img = document.createElement("img");
	            img.setAttribute("src", imgUrl);
	            img.style.position = "absolute";
	            img.style.top = "100px";
	            container.appendChild(img);
	            img.style.left = x  + "px";
	            img.style.top = y  + "px";
	            img.title = info.changeName+":"+info.changeType+":"+info.changeInfo;
	
	            common.addEvent(img, 'mouseover', function(e){console.log("hellow")});
	        }
	
	    }
	
	
	    //一个类型图片的映射
	    function typeToImgMap(type) {
	        var img;
	        switch (type) {
	            case "火箭发射": img = "icom_08.gif"; break;
	            case "快速下跌": img = "icom_11.gif"; break;
	            case "封涨停板": img = "icom_41.gif"; break;
	            case "封跌停板": img = "icom_43.gif"; break;
	            case "机构买单": img = "icom_45.gif"; break;
	            case "机构卖单": img = "icom_47.gif"; break;
	            case "快速反弹": img = "icom_14.gif"; break;
	            case "高台跳水": img = "icom_16.gif"; break;
	            case "大笔买入": img = "icom_19.gif"; break;
	            case "大笔卖出": img = "icom_21.gif"; break;
	            case "有大买盘": img = "icom_23.gif"; break;
	            case "有大卖盘": img = "icom_25.gif"; break;
	            case "向上缺口": img = "icom_58.gif"; break;
	            case "向下缺口": img = "icom_55.gif"; break;
	            case "竟价上涨": img = "icom_27.gif"; break;
	            case "竞价下跌": img = "icom_29.gif"; break;
	            case "高开5日线": img = "icom_03.gif"; break;
	            case "低开5日线": img = "icom_05.gif"; break;
	            case "60日新高": img = "icom_32.gif"; break;
	            case "60日新低": img = "icom_34.gif"; break;
	            case "打开跌停板": img = "icom_50.gif"; break;
	            case "打开涨停板": img = "icom_52.gif"; break;
	            case "大幅上涨": img = "icom_36.gif"; break;
	            case "大幅下跌": img = "icom_38.gif"; break;
	        }
	
	        return img;
	    }
	
	    return ChartTime;
	})();
	
	module.exports = ChartTime;


/***/ },
/* 39 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制直角坐标系
	 * 包括绘制网格
	 */
	
	/*绘制虚线*/
	var draw_dash = __webpack_require__(40);
	var extend = __webpack_require__(32);
	/*主题*/
	var theme = __webpack_require__(7);
	
	var DrawXY = (function() {
	    //构造方法
	    function DrawXY(options) {
	        /*设置默认参数*/
	        this.defaultoptions = theme.draw_xy_web;
	        this.options = {};
	        this.options = extend(this.options, this.defaultoptions, options);
	        /*绘图*/
	        this.draw();
	    };
	    /*绘图*/
	    DrawXY.prototype.draw = function() {
	        var data = this.options.data;
	        var ctx = this.options.context;
	        var type = this.options.type;
	        // var dpr = this.options.dpr;
	
	        /*Y轴上的最大值*/
	        var y_max = data.max;
	        /*Y轴上的最小值*/
	        var y_min = data.min;
	
	        /*Y轴上分隔线数量*/
	        var sepe_num = this.options.sepe_num;
	        /*开盘收盘时间数组*/
	        var oc_time_arr = data.timeStrs;
	
	        /*分时图的高度*/
	        var k_height = this.options.c_1_height;
	        /*Y轴标识线列表*/
	        var line_list_array = getLineList(y_max, y_min, sepe_num, k_height);
	
	        drawXYTime.call(this, ctx, y_max, y_min, line_list_array);
	
	        // 绘制横坐标刻度
	        drawXMark.apply(this, [ctx, k_height, oc_time_arr]);
	    };
	    // 绘制分时图坐标轴
	    function drawXYTime(ctx, y_max, y_min, line_list_array) {
	        var _this = this;
	        var sepe_num = line_list_array.length;
	        var padding_left = this.options.padding.left;
	        var padding_right = this.options.padding.right;
	        for (var i = 0, item; item = line_list_array[i]; i++) {
	            ctx.beginPath();
	            /*绘制y轴上的x轴方向分割*/
	            if (i < (sepe_num - 1) / 2) {
	                if (i == 0) {
	                    ctx.strokeStyle = 'rgba(230,230,230, 1)';
	                    ctx.moveTo(padding_left, Math.round(item.y));
	                    ctx.lineTo(ctx.canvas.width - padding_right, Math.round(item.y));
	                }
	                ctx.fillStyle = '#007F24';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	                draw_dash(ctx, padding_left, Math.round(item.y), ctx.canvas.width - padding_right, Math.round(item.y), 5);
	            } else if (i > (sepe_num - 1) / 2) {
	                if (i == (sepe_num - 1)) {
	                    ctx.strokeStyle = 'rgba(230,230,230, 1)';
	                    ctx.moveTo(padding_left, Math.round(item.y));
	                    ctx.lineTo(ctx.canvas.width - padding_right, Math.round(item.y));
	                }
	                ctx.fillStyle = '#FF0A16';
	                ctx.strokeStyle = 'rgba(230,230,230, 1)';
	                draw_dash(ctx, padding_left, Math.round(item.y), ctx.canvas.width - padding_right, Math.round(item.y), 5);
	            } else {
	                ctx.fillStyle = '#333333';
	                ctx.strokeStyle = '#cadef8';
	                ctx.moveTo(padding_left, Math.round(item.y));
	                ctx.lineTo(ctx.canvas.width - padding_right, Math.round(item.y));
	            }
	
	            // 绘制纵坐标刻度
	            if (isNaN(item.num)) {
	                ctx.fillText("0.00", 0, item.y);
	            } else {
	                var num = (item.num * 1.0).toFixed(this.options.pricedigit);
	                ctx.fillText(num, 0, item.y);
	            }
	            ctx.stroke();
	            // 绘制纵坐标涨跌幅
	            drawYPercent.call(_this, ctx, y_max, y_min, item);
	        }
	
	    }
	    /*绘制纵坐标涨跌幅*/
	    function drawYPercent(ctx, y_max, y_min, obj) {
	        /*纵坐标中间值*/
	        var y_middle = (y_max + y_min) / 2;
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        /*纵坐标刻度涨跌幅*/
	        if (y_middle) {
	            var percent = ((obj.num - y_middle) / y_middle * 100).toFixed(2) + "%";
	        } else {
	            var percent = "0.00%";
	        }
	        /*绘制纵坐标刻度百分比*/
	        ctx.fillText(percent, k_width - ctx.measureText(percent).width, obj.y);
	        ctx.stroke();
	    }
	    /*绘制横坐标刻度值*/
	    function drawXMark(ctx, k_height, oc_time_arr) {
	        // var dpr = this.options.dpr;
	        var padding_left = this.options.padding.left;
	        var padding_right = this.options.padding.right;
	        var y_min = this.options.c_1_height;
	        var y_max = this.options.c_1_height + ctx.canvas.height;
	        ctx.beginPath();
	        ctx.fillStyle = '#999';
	        /*画布宽度*/
	        var k_width = ctx.canvas.width;
	        var y_date = k_height + ctx.canvas.height / 8 / 2;
	        /*绘制x轴上的y轴方向分割*/
	        var len = 0;
	        /*通过type判断，是一日分时还是多日分时，以及判断是不是有盘前数据，根据判断结果画不同的横坐标时间点*/
	        var timeStrLen = oc_time_arr.length;
	        /*每个下标刻度之间的宽度*/
	        var itemDistance;
	        /*是否为一天分时*/
	        var isR = false;
	        /*是否包含盘前数据*/
	        var isCR = this.options.isCR || false;
	        /*盘前数据占据的宽度*/
	        var crSpace = 0;
	        if (this.options.type.toLowerCase() != 'r') {
	            itemDistance = (k_width - padding_left - padding_right) / (timeStrLen);
	        } else {
	            if (isCR) {
	                //盘前数据在坐标上的宽度
	                crSpace = (k_width - padding_left - padding_right) / ((timeStrLen - 2) * 4 + 1);
	                itemDistance = crSpace * 4;
	            } else {
	                itemDistance = (k_width - padding_left - padding_right) / (timeStrLen - 1);
	            }
	            isR = true;
	        }
	        /*绘制x轴上的时间点*/
	        if (!isCR) {
	            len = 2 * timeStrLen;
	            for (var i = 0; i < timeStrLen; i++) {
	                //时间转换，如果为日期，装换为xx月xx日， 否则为原样
	                var itemTime = (isR ? oc_time_arr[i] : (new Date(oc_time_arr[i]).getMonth() + 1) + "月" +
	                    new Date(oc_time_arr[i]).getDate() + "日");
	                if (i == 0) {
	                    isR ? ctx.fillText(itemTime, padding_left, y_date) : 0;
	                } else if (i == timeStrLen - 1 && isR) {
	                    ctx.fillText(itemTime, padding_left + itemDistance * i - ctx.measureText(itemTime).width, y_date);
	                } else {
	                    ctx.fillText(itemTime, padding_left + itemDistance * i - ctx.measureText(itemTime).width / 2, y_date);
	                }
	            }
	        } else {
	            len = 2 * (timeStrLen-1) + 1;
	            for (var i = 0; i < timeStrLen; i++) {
	                var itemTime = oc_time_arr[i];
	                if (i == 0) {
	                    ctx.fillText(itemTime, padding_left, y_date);
	                } else if (i == 1) {
	                    ctx.fillText(itemTime, padding_left + crSpace, y_date);
	                } else if (i == timeStrLen - 1) {
	                    ctx.fillText(itemTime, padding_left + crSpace + itemDistance * (i - 1) - ctx.measureText(itemTime).width, y_date);
	                } else {
	                    ctx.fillText(itemTime, padding_left + crSpace + itemDistance * (i - 1) - ctx.measureText(itemTime).width / 2, y_date);
	                }
	            }
	        }
	
	
	        var v_height = ctx.canvas.height / 4;
	
	        var v_base_height = v_height * 0.9;
	
	        var y_v_bottom = ctx.canvas.height - this.options.canvas_offset_top;
	        var y_v_top = y_v_bottom - v_height;
	        var itemWidth = (k_width - padding_left - padding_right) / len;
	        for (var i = 0; i <= len; i++) {
	
	            if (i != 0 && i != len) {
	                var x;
	                //如果是盘前
	                if (isCR) {
	                    if (i == 1) {
	                        x = crSpace + padding_left;
	                        ctx.fillStyle = "#efefef";
	                        ctx.fillRect(padding_left, 0, crSpace, y_min);
	                    } else {
	                        x = padding_left + (i - 1) * itemDistance/2 + crSpace;
	                    }
	                }else{
	                    x = padding_left + i * itemWidth;
	                }
	                draw_dash(ctx, x, y_min, x, 0, 5);
	                draw_dash(ctx, x, y_v_bottom, x, y_v_top, 5);
	            } else {
	                ctx.moveTo(Math.floor(padding_left + i * itemWidth), y_min);
	                ctx.lineTo(Math.floor(padding_left + i * itemWidth), 0);
	            }
	
	        }
	
	        ctx.stroke();
	    }
	
	    /*Y轴标识线列表*/
	    function getLineList(y_max, y_min, sepe_num, k_height) {
	        var ratio = (y_max - y_min) / (sepe_num - 1);
	        var result = [];
	        for (var i = 0; i < sepe_num; i++) {
	            result.push({
	                num: (y_min * 1.0 + i * ratio),
	                x: 0,
	                y: k_height - (i / (sepe_num - 1)) * k_height
	            });
	        }
	        return result;
	    }
	
	
	
	    return DrawXY;
	})();
	
	module.exports = DrawXY;


/***/ },
/* 40 */
/***/ function(module, exports) {

	function drawDashLine(ctx, x1, y1, x2, y2, dashLength){
	    // 保存画笔状态
	    ctx.save();
	    var dashLen = dashLength === undefined ? 5 : dashLength,
	    xpos = x2 - x1, //得到横向的宽度;
	    ypos = y2 - y1, //得到纵向的高度;
	    numDashes = Math.floor(Math.sqrt(xpos * xpos + ypos * ypos) / dashLen); 
	    //利用正切获取斜边的长度除以虚线长度，得到要分为多少段;
	    for(var i=0; i < numDashes; i++){
	       if(i % 2 === 0){
	           ctx.moveTo(Math.round(x1 + (xpos/numDashes) * i)+0.5, y1 + (ypos/numDashes) * i); 
	           //有了横向宽度和多少段，得出每一段是多长，起点 + 每段长度 * i = 要绘制的起点；
	        }else{
	            ctx.lineTo(Math.round(x1 + (xpos/numDashes) * i)+0.5, y1 + (ypos/numDashes) * i);
	        }
	     }
	    ctx.stroke();
	    // 恢复画笔状态
	    ctx.restore();
	}
	
	module.exports = drawDashLine;

/***/ },
/* 41 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * web端分时图数据
	 *
	 *	返回数据：result = {
	 *			name:股票名称，
	 *			code: 股票编码,
	 *			yc: 昨收价,
	 *			high: 最高价,
	 *			low: 最低价,
	 *			v_max: 成交量最大值,
	 *			timeStrs: ["09:30","10:30","11:30/13:00","14:00","15:00"] 时间点数组,
	 *			data:[	
	 *				time(时间), price(价格), up(涨跌), percent(涨跌百分比), avg_cost(均价)
	 *			]
	 *	}
	 * 
	 */
	
	var jsonp = __webpack_require__(12);
	
	var dealData = __webpack_require__(42);
	
	var fix = __webpack_require__(8).fixed;
	
	/**
	 * 获取不同时间段的分时数据（默认当日）
	 * @param  {[type]}   id       [description]
	 * @param  {Function} callback [description]
	 * @return {[type]}            [description]
	 */
	function getData(options, callback) {
	    var url = "http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js";
	    var callbackStr = "fsData" + (new Date()).getTime().toString().substring(0, 10);
	    var urlData = {
	        id: options.code,
	        TYPE: options.type || 'R',
	        js: callbackStr + '((x))',
	        'rtntype': 5,
	        isCR: options.isCR || false
	    };
	
	    jsonp(url, urlData, callbackStr, function(json) {
	
	
	        var error;
	        if (json) { 
	        	error = false;
	            var result = dealData(json, urlData.isCR, options.type); 
	        } else { 
	        	error = true; 
	        }
	        callback(error, result);
	    });
	}
	
	module.exports = getData;


/***/ },
/* 42 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * web分时的数据处理
	 */
	var coordinate = __webpack_require__(11); //处理数据
	var fix = __webpack_require__(8).fixed;
	/**
	 * 对分时图做的数据处理方便调用
	 * @param  {[type]} json [description]
	 * @return {[type]}      [description]
	 */
	function dealData(json, isCR, type) {
	    var yc = json.info.yc;
	    var result = {};
	    result.v_max = 0;
	
	    result.yc = json.info.yc;
	    result.pricedigit = (json.info.pricedigit).split('.')[1].length;
	    result.currentPrice = json.info.c;
	    result.high = json.info.h;
	    result.low = json.info.l;
	    result.code = json.code;
	    result.timeStrs = [];
	    result.data = [];
	    result.total = json.info.total%242 == 0 ? json.info.total : Math.floor(json.info.total/242+1)*242;
	    var timeStrs = [];
	    if(isCR){
	        result.total = result.total*1 + 15;
	        timeStrs.push("09:15");
	    }
	    //横坐标的时间列表
	    
	    var ticks = (json.info.ticks).split('|');
	    if (ticks.length === 7) {
	        //早上开始时间
	        var AM_start = ticks[3];
	        timeStrs.push(toFormDateTime(AM_start));
	        var AM_middle = Math.floor((ticks[3] * 1.0 + ticks[4] * 1.0) / 2);
	        timeStrs.push(toFormDateTime(AM_middle));
	        var AM_end = ticks[4];
	        var PM_start = ticks[5];
	        timeStrs.push(toFormDateTime(AM_end) + "/" + toFormDateTime(PM_start));
	        var PM_middle = Math.floor((ticks[5] * 1.0 + ticks[6] * 1) / 2);
	        timeStrs.push(toFormDateTime(PM_middle));
	        var PM_end = ticks[6];
	        timeStrs.push(toFormDateTime(PM_end));
	    }
	
	    var dateStrs = [];
	    //计算每个数据点
	    for (var i = 0, item; item = json.data[i]; i++) {
	        var point = {};
	        var dataItem = item.split(",");
	        //成交量的最大值
	        result.v_max = Math.max(dataItem[2]*1.0, result.v_max); 
	
	        //涨跌百分比
	        point.up = (dataItem[1] - yc) > 0 ? true : false;
	        point.percent = (Math.abs(dataItem[1] - yc) / yc * 100).toFixed(2);
	
	        //每个点的时间（小时：分钟），价格，均价
	        point.time = dataItem[0].split(" ")[1];
	        point.dateTime = dataItem[0].split(" ")[0];
	        point.price = dataItem[1];
	        point.avg_cost = dataItem[3];
	        point.volume = dataItem[2]*1.0;
	        result.high = Math.max(result.high, point.price);
	        result.low = Math.min(result.low, point.price);
	        if(point.dateTime != dateStrs[dateStrs.length-1]){
	            dateStrs.push(point.dateTime);
	        }
	        result.data.push(point);
	    }
	
	    //判断不同的请求种类，返回不同的时间数组
	    if(type == 'r'){
	        result.timeStrs = timeStrs;
	    }else{
	        result.timeStrs = dateStrs;
	    }
	
	    //坐标的最大最小值
	    result.max = coordinate(result.high, result.low, result.yc).max;
	    //坐标的最小值
	    result.min = coordinate(result.high, result.low, result.yc).min;
	
	
	    return result;
	}
	
	var toFormDateTime = function(ticks) {
	    return fix(Math.floor(ticks / 3600), 2) + ":" + fix(Math.floor((ticks / 60) % 60), 2);
	}
	
	module.exports = dealData;


/***/ },
/* 43 */
/***/ function(module, exports, __webpack_require__) {

	var jsonp = __webpack_require__(12);
	/**
	 * 返回盘口异动的数据
	 * @param  string   code     股票代码
	 * @param  {Function} callback [description]
	 * @return {[type]}            [description]
	 */
	function getData(code, callback){
	    var url = "http://nuyd.eastmoney.com/EM_UBG_PositionChangesInterface/api/js";
	    var callbackStr = "changeData" + (new Date()).getTime().toString().substring(0, 10);
	    var urlData = {
	        id: code,
	        style:  "top",
	        js:  callbackStr+'([(x)])',
	        num: 5,
	        ac: "normal",
	        check:"itntcd",
	        cd : callbackStr
	    };
	
	    jsonp(url, urlData, callbackStr, function(json) {
	        // debugger;
	        var error;  
	        if (json) { 
	            error = false;
	        } else { 
	            error = true; 
	        }
	        callback(error, json);
	    });
	
	    /*var url = "http://nuyd.eastmoney.com/EM_UBG_PositionChangesInterface/api/js?style=top&num=5&ac=normal&check=itntcd&js=[(x)]&cb=var%20dataChange=&id=6018111";
	    var scri = document.createElement("script");
	
	    scri.setAttribute("src", url);
	
	    var htmlE = document.getElementsByTagName('html')[0];
	
	    htmlE.appendChild(scri);
	
	    scri.onload = function(){
	        callback(false, dataChange);
	
	    }*/
	//http://nuyd.eastmoney.com/EM_UBG_PositionChangesInterface/api/js?id=6018111&style=top&js=changeData1472543155((x))&num=5&ac=normal&check=itntcd&cb=changeData1472543155&changeData1472543155=changeData1472543155
	
	}
	
	module.exports = getData;

/***/ },
/* 44 */
/***/ function(module, exports) {

	var common = {
	    // 由股票代码判断股票上市场所，1(沪市)或2(深市)或5(港股)
	    getMktByCode: function(code) {
	        if (code.Length < 3)
	            return code + "1";
	        var one = code.substr(0, 1);
	        var three = code.substr(0, 3);
	        if (one == "5" || one == "6" || one == "9") {
	            return code + "1";
	        } else {
	            if (three == "009" || three == "126" || three == "110" || three == "201" || three == "202" || three == "203" || three == "204") {
	                return code + "1";
	            } else {
	                return code + "2";
	            }
	        }
	    },
	    // 数字标准化，字符串输出，例如：9----->09
	    fixed: function(str, len) {
	        var i = 0;
	        str = str.toString();
	        var result = str;
	        for (i = 0; i < len - str.length; i++) {
	            result = '0' + result;
	        }
	
	        return result;
	    },
	    // 日期标准化，字符串输出，例如: 20121112---->2012-11-12
	    transform: function(str) {
	        return str.replace(/(\d{4})(\d{2})(\d{2})/g, function(whole, a, b, c) {
	            return a + "-" + b + "-" + c;
	        });
	    },
	    // 将鼠标坐标转换为Canvas坐标
	    windowToCanvas: function(canvas, x, y) {
	        // var box = canvas.getBoundingClientRect();
	        return {
	            // x:(x-box.left)*(canvas.width/box.width),
	            // y:(y-box.top)*(canvas.height/box.height)
	
	            x: x * this.options.dpr,
	            y: y * this.options.dpr
	        };
	    },
	    // 将Canvas坐标转换为鼠标坐标
	    canvasToWindow: function(canvas, x, y) {
	        var box = canvas.getBoundingClientRect();
	        // 相对于窗口
	        // return {
	        //     x:(x *(box.width/canvas.width)+box.left),
	        //     y:(y *(box.height/canvas.height)+box.top + this.options.canvas_offset_top/this.options.dpr)
	        // };
	        return {
	            x: x / this.options.dpr,
	            // x:x * (box.width/canvas.width),
	            y: (y + this.options.canvas_offset_top) * (Math.abs(box.bottom - box.top) / canvas.height)
	        };
	    },
	    // 图表y轴坐标计算
	    get_y: function(y) {
	
	        var max = (this.options.currentData && this.options.currentData.max) || this.options.data.max;
	        var min = (this.options.currentData && this.options.currentData.min) || this.options.data.min;
	        return this.options.c_k_height - (this.options.c_k_height * (y - min) / (max - min));
	    },
	    // 图表x轴坐标计算
	    get_x: function(x) {
	        var canvas = this.options.context.canvas;
	        var type = this.options.chartType;
	        var rect_w = this.options.rect_unit.rect_w;
	        var num = (this.options.currentData && this.options.currentData.data.length) || this.options.data.data.length;
	        var total = (this.options.currentData && this.options.currentData.total) || this.options.data.total;
	        var padding_left = this.options.padding.left;
	        var padding_right = this.options.padding.right;
	        // var dpr = this.options.dpr;
	
	        if (type == "TL") {
	            return (canvas.width - padding_left - padding_right) / total * x + padding_left;
	        } else {
	            return (canvas.width - padding_left - padding_right) / num * x + padding_left - (rect_w / 2);
	        }
	
	    },
	    // 图表x轴坐标计算
	    get_rect: function(canvas, num) {
	        var rect_w = (canvas.width - this.options.padding.left - this.options.padding.right) / num;
	        var bar_w = rect_w * (1 - this.options.spacing);
	        return {
	            rect_w: rect_w,
	            bar_w: bar_w
	        };
	    },
	    // 格式化数据单位  
	    format_unit: function(value, num) {
	        num = num == undefined ? 2 : num;
	        var flag = false;
	        if(value < 0){
	            value = Math.abs(value);
	            flag = true;
	        }
	
	        if(flag){
	            if (value < 10000) {
	                return (value/1).toFixed(num) * -1;
	            } else if (value >= 10000 && value < 100000000) {
	                return (value / 10000).toFixed(num) * -1 + "万";
	            } else if (value >= 100000000) {
	                return (value / 100000000).toFixed(num) * -1 + "亿";
	            } else {
	                return (value/1).toFixed(num) * -1;
	            }
	
	        }else{
	            if (value < 10000) {
	                return (value/1).toFixed(num);
	            } else if (value >= 10000 && value < 100000000) {
	                return (value / 10000).toFixed(num) + "万";
	            } else if (value >= 100000000) {
	                return (value / 100000000).toFixed(num) + "亿";
	            } else {
	                return (value/1).toFixed(num);
	            }
	        }
	        
	    },
	    /**
	     * 兼容性的事件添加
	     * @param {[type]}   obj  对哪个元素添加
	     * @param {[type]}   type 事件类型
	     * @param {Function} fn   事件触发的处理函数
	     */
	    addEvent: function(obj, type, fn) {
	        if (obj.attachEvent) {
	            obj['e' + type + fn] = fn;
	            obj[type + fn] = function() { obj['e' + type + fn](window.event); }
	            obj.attachEvent('on' + type, obj[type + fn]);
	        } else
	            obj.addEventListener(type, fn, false);
	    },
	    removeEvent: function(obj, type, fn) {
	        if (obj.detachEvent) {
	            obj.detachEvent('on' + type, obj[type + fn]);
	            obj[type + fn] = null;
	        } else
	            obj.removeEventListener(type, fn, false);
	    }
	
	};
	module.exports = common;


/***/ },
/* 45 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 图表交互
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     type:    "TL"(分时图),"DK"(日K线图),"WK"(周K线图),"MK"(月K线图)
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 *     canvas_offset_top:   画布中坐标轴向下偏移量
	 *     padding_left:    画布左侧边距
	 *     k_v_away:    行情图表（分时图或K线图）和成交量图表的间距
	 *     scale_count:     缩放默认值
	 *     c_1_height:  行情图表（分时图或K线图）的高度
	 *     rect_unit:   分时图或K线图单位绘制区域
	 *
	 * 	   cross: 	十字指示线dom对象
	 * 	   mark_ma: 	均线标识dom对象
	 * 	   scale: 	缩放dom对象
	 * }
	 *
	 */
	
	// 拓展，合并，复制
	var extend = __webpack_require__(32);
	// 工具
	var common = __webpack_require__(44);
	// 主题
	var theme = __webpack_require__(7);
	
	var Interactive = (function() {
	
	    // 构造函数
	    function Interactive(options) {
	        this.defaultoptions = theme.interactive;
	        this.options = {};
	        this.options = extend(this.options, this.defaultoptions, options);
	    }
	
	    // 鼠标十字标识线
	    Interactive.prototype.cross = function(canvas, w_x, w_y) {
	        var c_box = canvas.getBoundingClientRect();
	        var dpr = this.options.dpr;
	
	        if (!this.options.cross) {
	            this.options.cross = {};
	            /*Y轴标识线*/
	            var y_line = document.createElement("div");
	            y_line.className = "cross-y";
	            y_line.style.height = this.options.c4_y_top - this.options.c1_y_top + "px";
	            y_line.style.top = this.options.c1_y_top + "px";
	            this.options.cross.y_line = y_line;
	
	            /*X轴标识线*/
	            var x_line = document.createElement("div");
	            x_line.className = "cross-x";
	            x_line.style.width = canvas.width / dpr + "px";
	            this.options.cross.x_line = x_line;
	            /*X轴和Y轴标示线相交点*/
	            var point = document.createElement("div");
	            point.className = "cross-p";
	            point.style.width = "2px";
	            point.style.height = "2px";
	            point.style.borderRadius = point.style.width;
	            point.style.backgroundColor = this.options.point_color;
	            this.options.cross.point = point;
	            /*创建文档碎片*/
	            var frag = document.createDocumentFragment();
	            // if(this.options.type == "TL"){
	            if (this.options.crossline) {
	                frag.appendChild(x_line);
	                frag.appendChild(y_line);
	                frag.appendChild(point);
	            } else {
	                frag.appendChild(y_line);
	            }
	            document.getElementById(this.options.container).appendChild(frag);
	        }
	        var y_line = this.options.cross.y_line;
	        if (y_line) {
	            y_line.style.left = w_x + "px";
	        }
	        var x_line = this.options.cross.x_line;
	        if (x_line) {
	            x_line.style.top = w_y + "px";
	        }
	        var point = this.options.cross.point;
	        if (point) {
	            var p_w = this.options.point_width;
	            point.style.left = w_x - p_w / 2 + "px";
	            point.style.top = w_y - p_w / 2 + "px";
	        }
	    }
	
	    // 鼠标十字标识线(webTime)
	    Interactive.prototype.crossTime = function(canvas, w_x, w_y) {
	        var c_box = canvas.getBoundingClientRect();
	        var dpr = this.options.dpr;
	        var padding_left = this.options.padding.left;
	        var offsetTop = this.options.canvas_offset_top;
	        var canvasHeight = this.options.canvas.height;
	        var containerId = this.options.container;
	
	        if (!this.options.cross) {
	            this.options.cross = {};
	            /*Y轴标识线*/
	            var y_line = document.createElement("div");
	            y_line.className = "cross-y";
	            y_line.style.height = canvasHeight - offsetTop + "px";
	            y_line.style.top = offsetTop + "px";
	            this.options.cross.y_line = y_line;
	
	            /*X轴标识线*/
	            var x_line = document.createElement("div");
	            x_line.className = "cross-x";
	            x_line.style.width = canvas.width + "px";
	            this.options.cross.x_line = x_line;
	            /*创建文档碎片*/
	            var frag = document.createDocumentFragment();
	            if (this.options.crossline) {
	                frag.appendChild(x_line);
	                frag.appendChild(y_line);
	            } else {
	                frag.appendChild(y_line);
	            }
	            document.getElementById(containerId).appendChild(frag);
	        }
	        var y_line = this.options.cross.y_line;
	        if (this.options.cross.y_line) {
	            y_line.style.left = w_x + "px";
	        }
	        var x_line = this.options.cross.x_line;
	        if (this.options.cross.x_line) {
	            x_line.style.top = w_y + "px";
	        }
	    }
	
	    Interactive.prototype.showTipsTime = function(cross_w_x, cross_w_y, time_data, index){
	        /*将要用到的各种参数*/
	        var canvas = this.options.canvas;
	        var padding_left = this.options.padding.left;
	        var padding_right = this.options.padding.right;
	        var offsetTop = this.options.canvas_offset_top;
	        var c_1_height = this.options.c_1_height;
	        var containerId = this.options.container;
	        var map = ['周一', '周二', '周三', '周四','周五', '周六', '周日'];
	        var itemData;
	        if(index < 0){
	            itemData = time_data[0];
	        }else if(index > time_data.length-1){
	            itemData = time_data[time_data.length-1];
	        }else{
	            itemData = time_data[index];
	        }
	        var topText = itemData.dateTime.substring(5)+" "+ itemData.time + " "+
	                                map[(new Date(itemData.dateTime)).getDay()]+" 最新价:"+itemData.price+
	                                " 成交量:"+ common.format_unit(itemData.volume.toFixed(0), 2)+"(手) 成交额:"+ 
	                                common.format_unit(itemData.volume*itemData.price*100, 2) + " 均价:"+ itemData.avg_cost;
	
	        // debugger;
	        if(!this.options.webTimeTips){
	            var y_left, y_right, x_bottom, x_top;
	            var frag = document.createDocumentFragment();
	            /*y轴上左边的提示*/
	            y_left = document.createElement("div");
	            y_left.setAttribute("id", "time_y_left");
	            y_left.className = "time-tips-coordinate";
	            /*y轴上右边的提示*/
	            y_right = document.createElement("div");
	            y_right.setAttribute("id", "time_y_right");
	            y_right.className = "time-tips-coordinate";
	            y_right.style.left = canvas.width - padding_right + "px";
	            /*x轴底部的时间提示*/
	            x_bottom = document.createElement("div");
	            x_bottom.setAttribute("id", "time_x_bottom");
	            x_bottom.className = "time-tips-coordinate";
	            /*x轴顶部的时间提示*/
	            x_top = document.createElement("div");
	            x_top.setAttribute("id", "time_x_top");
	            x_top.className = "time-tips-top";
	            x_top.style.top = offsetTop - 18 + "px";
	            x_top.style.left = padding_left + "px";
	            this.options.webTimeTips = {};
	            this.options.webTimeTips.time_y_left = y_left;
	            this.options.webTimeTips.time_y_right = y_right;
	            this.options.webTimeTips.time_x_top = x_top;
	            this.options.webTimeTips.time_x_bottom = x_bottom;
	
	            frag.appendChild(y_left)
	            frag.appendChild(y_right)
	            frag.appendChild(x_bottom)
	            frag.appendChild(x_top)
	            document.getElementById(containerId).appendChild(frag);
	
	            //跟随鼠标变化需要更改的纵坐标上的的提示*/
	            y_left.style.top = cross_w_y + "px";
	            y_left.innerHTML = itemData.price;
	            y_right.style.top = cross_w_y + "px";
	            y_right.innerHTML = itemData.percent;
	            
	            //跟随鼠标变化需要更改的横坐标上的的提示*/
	            x_bottom.innerHTML = itemData.time;
	            x_bottom.style.left = cross_w_x - x_bottom.clientWidth/2 + "px";
	            x_top.innerHTML = topText;
	            x_top.style.display = 'block';
	        }else{
	            var y_left = document.getElementById("time_y_left");
	            var y_right = document.getElementById("time_y_right");
	            var x_bottom = document.getElementById("time_x_bottom");
	            var x_top = document.getElementById("time_x_top");
	            //跟随鼠标变化需要更改的纵坐标上的的提示*/
	            y_left.style.top = cross_w_y + "px";
	            y_left.innerHTML = itemData.price;
	            y_left.style.left = padding_left - y_left.clientWidth + 'px';
	            y_left.style.display = 'block';
	            y_right.style.top = cross_w_y + "px";
	            y_right.style.display = 'block';
	            y_right.innerHTML = itemData.percent;
	            
	            //跟随鼠标变化需要更改的横坐标上的的提示*/
	            x_bottom.style.left = cross_w_x + "px";
	            x_bottom.style.display = 'block';
	            x_bottom.innerHTML = itemData.time;
	            if(cross_w_x < padding_left + x_bottom.clientWidth/2){
	                x_bottom.style.left = padding_left + "px";
	            }else if(cross_w_x > canvas.width - padding_right - x_bottom.clientWidth/2){
	                x_bottom.style.left = canvas.width - padding_right - x_bottom.clientWidth + "px";
	            }else{
	                x_bottom.style.left = cross_w_x - x_bottom.clientWidth/2 + "px";
	            }
	            x_bottom.style.top = c_1_height + offsetTop - x_bottom.clientHeight + "px";
	            
	            x_top.style.display = 'block';
	            x_top.innerHTML = topText;
	        }
	    };
	
	    //         /*创建文档碎片*/
	    //         var frag = document.createDocumentFragment();
	
	    //         /*5日均线*/
	    //         var ma_5_data = document.createElement('span');
	    //         ma_5_data.className = "span-m5";
	    //         ma_5_data.style.position = "absolute";
	    //         ma_5_data.style.left = 0;
	    //         if (obj_5) {
	    //             ma_5_data.innerText = "MA5: " + obj_5.value;
	    //         } else {
	    //             if (this.default_m5) {
	    //                 ma_5_data.innerText = "MA5: " + this.default_m5.value;
	    //             } else {
	    //                 ma_5_data.innerText = "MA5: -";
	    //             }
	    //         }
	    //         this.options.mark_ma.ma_5_data = ma_5_data;
	
	    //         /*10日均线*/
	    //         var ma_10_data = document.createElement('span');
	    //         ma_10_data.id = "ma_10_data";
	    //         ma_10_data.className = "span-m10";
	    //         ma_10_data.style.position = "absolute";
	    //         ma_10_data.style.left = this.options.padding.left + this.options.drawWidth * 1 / 3 - 50 + "px";
	    //         if (obj_10) {
	    //             ma_10_data.innerText = "MA10: " + obj_10.value;
	    //         } else {
	    //             if (this.default_m10) {
	    //                 ma_10_data.innerText = "MA10: " + this.default_m10.value;
	    //             } else {
	    //                 ma_10_data.innerText = "MA10: -";
	    //             }
	    //         }
	    //         this.options.mark_ma.ma_10_data = ma_10_data;
	
	    //         /*20日均线*/
	    //         var ma_20_data = document.createElement('span');
	    //         ma_20_data.id = "ma_20_data";
	    //         ma_20_data.className = "span-m20";
	    //         ma_20_data.style.position = "absolute";
	    //         ma_20_data.style.left = this.options.padding.left + this.options.drawWidth * 2 / 3 - 50 + "px";
	    //         if (obj_20) {
	    //             ma_20_data.innerText = "MA20: " + obj_20.value;
	    //         } else {
	    //             if (this.default_m20) {
	    //                 ma_20_data.innerText = "MA20: " + this.default_m20.value;
	    //             } else {
	    //                 ma_20_data.innerText = "MA20: -";
	    //             }
	    //         }
	    //         this.options.mark_ma.ma_20_data = ma_20_data;
	
	    //         /*30日均线*/
	    //         var ma_30_data = document.createElement('span');
	    //         ma_30_data.id = "ma_30_data";
	    //         ma_30_data.className = "span-m30";
	    //         ma_30_data.style.position = "absolute";
	    //         // ma_30_data.style.left = this.options.padding.left + this.options.drawWidth * 3/4 + "px";
	    //         ma_30_data.style.left = this.options.padding.left + this.options.drawWidth - 120 + "px";
	    //         if (obj_30) {
	    //             ma_30_data.innerText = "MA30: " + obj_30.value;
	    //         } else {
	    //             if (this.default_m30) {
	    //                 ma_30_data.innerText = "MA30: " + this.default_m30.value;
	    //             } else {
	    //                 ma_30_data.innerText = "MA30: -";
	    //             }
	    //         }
	    //         this.options.mark_ma.ma_30_data = ma_30_data;
	
	    //         frag.appendChild(ma_5_data);
	    //         frag.appendChild(ma_10_data);
	    //         frag.appendChild(ma_20_data);
	    //         frag.appendChild(ma_30_data);
	    //         div_mark.appendChild(frag);
	
	    //         document.getElementById(this.options.container).appendChild(div_mark);
	    //         // div_tip.style.left = w_pos.x - 300 + "px";
	    //     } else {
	
	    //         var div_mark = this.options.mark_ma.mark_ma;
	    //         if (obj_5) {
	    //             this.options.mark_ma.ma_5_data.innerText = "MA5: " + obj_5.value;
	    //         } else {
	    //             if (this.default_m5) {
	    //                 this.options.mark_ma.ma_5_data.innerText = "MA5: " + this.default_m5.value;
	    //             } else {
	    //                 this.options.mark_ma.ma_5_data.innerText = "MA5: -";
	    //             }
	    //         }
	
	    //         if (obj_10) {
	    //             this.options.mark_ma.ma_10_data.innerText = "MA10: " + obj_10.value;
	    //         } else {
	    //             if (this.default_m10) {
	    //                 this.options.mark_ma.ma_10_data.innerText = "MA10: " + this.default_m10.value;
	    //             } else {
	    //                 this.options.mark_ma.ma_10_data.innerText = "MA10: -";
	    //             }
	    //         }
	
	    //         if (obj_20) {
	    //             this.options.mark_ma.ma_20_data.innerText = "MA20: " + obj_20.value;
	    //         } else {
	    //             if (this.default_m20) {
	    //                 this.options.mark_ma.ma_20_data.innerText = "MA20: " + this.default_m20.value;
	    //             } else {
	    //                 this.options.mark_ma.ma_20_data.innerText = "MA20: -";
	    //             }
	    //         }
	    //         if (obj_30) {
	    //             this.options.mark_ma.ma_30_data.innerText = "MA30: " + obj_30.value;
	    //         } else {
	    //             if (this.default_m30) {
	    //                 this.options.mark_ma.ma_30_data.innerText = "MA30: " + this.default_m30.value;
	    //             } else {
	    //                 this.options.mark_ma.ma_30_data.innerText = "MA30: -";
	    //             }
	    //         }
	
	    //     }
	
	    // }
	
	
	    Interactive.prototype.markMA = function(canvas, type, datas, start, end, index) {
	
	        var colors = ["#6e9fe9", "#ffba42", "#fe59fe", "#ff7e58"];
	        if (!this.options.markMAContainer) {
	            //创建并添加最下方一系列技术指标的外部包含div
	            this.options.markMAContainer = document.createElement("div");
	            var markMAContainer = this.options.markMAContainer;
	            markMAContainer.setAttribute("id", "markMAContainer");
	            // debugger;
	            markMAContainer.style.position = "absolute";
	            markMAContainer.style.fontFamily = "Microsoft Yahei";
	            markMAContainer.style.fontWeight = "lighter";
	            markMAContainer.style.fontSize = "14px";
	            markMAContainer.style.top = "5px";
	            markMAContainer.style.left = this.options.padding.left + "px";
	            
	            /*创建文档碎片*/
	            var frag = document.createDocumentFragment();
	            var co = 0;
	            this.options.markUPTType = type;
	            for (var item in datas) {
	                var temp = datas[item][datas[item].length - 1];
	                var span = document.createElement('span');
	                span.innerHTML = item.toUpperCase() + ": " + temp.value;
	                span.style.width = "100px";
	                span.style.color = colors[co];
	                co++;
	                span.style.marginRight = "30px";
	                span.setAttribute("id", item + "_mark");
	                frag.appendChild(span);
	                }
	
	                markMAContainer.appendChild(frag);
	                this.options[type] = {};
	                this.options[type].defaultMaHtml = markMAContainer.innerHTML;
	                document.getElementById(this.options.container).appendChild(markMAContainer);
	            } else {
	
	            var markMAContainer = this.options.markMAContainer;
	
	            //判断是不是第一次，是否需要创建元素
	            if (!this.options[type]) {
	                //作为是否切换技术指标的依据
	                this.options.markUPTType = type;
	                //清空markTContainer里面的所有span
	                var spans = markMAContainer.getElementsByTagName("span");
	                var len = spans.length;
	
	                // for (var i = 0; i < len; i++) {
	                //     markMAContainer.removeChild(spans[0]);
	                // }
	
	                markMAContainer.innerHTML = "";
	                // debugger;
	                var dataObj = [];
	
	                for (var item in datas) {
	                    dataObj.push({ value: datas[item].slice(start,end), name: item });
	                }
	                /*创建文档碎片*/
	                var m_frag = document.createDocumentFragment();
	                var frag = document.createDocumentFragment();
	                //添加元素
	                var co = 0;
	                if(!this.options[type] || !this.options[type].defaultMaHtml){
	                    for (var item in datas) {
	                        var temp = datas[item][datas[item].length - 1];
	                        var span = document.createElement('span');
	                        span.innerHTML = item.toUpperCase() + ": " + temp.value;
	                        span.style.width = "100px";
	                        span.style.color = colors[co];
	                        co++;
	                        span.style.marginRight = "30px";
	                        span.setAttribute("id", item + "_mark");
	                        frag.appendChild(span);
	                    }
	
	                    markMAContainer.appendChild(frag);
	
	                    this.options[type] = {};
	                    this.options[type].defaultMaHtml = markMAContainer.innerHTML;
	                    markMAContainer.innerHTML = "";
	                }
	
	                for (var i = 0; i < dataObj.length; i++) {
	                    var span = document.createElement('span');
	                    // if(dataObj[i].value[index].value){
	                    //     var text = dataObj[i].value[index].value;
	                    // }else{
	                    //     var text = "-"
	                    // }
	                    span.innerHTML = dataObj[i].name.toUpperCase() + ": " + dataObj[i].value[index].value;
	                    span.style.width = "100px";
	                    span.style.color = colors[i];
	                    span.style.marginRight = "30px";
	                    span.setAttribute("id", dataObj[i].name + "_mark");
	                    m_frag.appendChild(span);
	            }
	                /*添加到包含元素上*/
	                markMAContainer.appendChild(m_frag);
	            } else {
	
	                var dataObj = [];
	                for (var item in datas) {
	                    dataObj.push({ value: datas[item].slice(start,end), name: item });
	                }
	                //更改内容
	                for (var i = 0; i < dataObj.length; i++) {
	                    var span = document.getElementById(dataObj[i].name + "_mark");
	                    try {
	                        span.innerHTML = dataObj[i].name.toUpperCase() + ": " + dataObj[i].value[index].value;
	                    } catch (e) {
	                        // markMAContainer.removeChild(span);
	                        if(dataObj[i].value[index].value == null || dataObj[i].value[index].value == undefined){
	                            span.innerText = dataObj[i].name.toUpperCase() + ": -";
	            } else {
	                            var span = document.createElement('span');
	                            span.innerHTML = dataObj[i].name.toUpperCase() + ": " + dataObj[i].value[index].value;
	                            span.style.width = "100px";
	                            span.style.color = colors[i];
	                            span.style.marginRight = "30px";
	                            span.setAttribute("id", dataObj[i].name + "_mark");
	                            markMAContainer.appendChild(span);
	                }
	
	                }
	            }
	
	                }
	            }
	
	
	
	    }
	
	    Interactive.prototype.markVMA = function(canvas, volume, obj_5, obj_10) {
	
	        // 绘制移动平均线标识
	        // var c_box = canvas.getBoundingClientRect();
	        // var dpr = this.options.dpr;
	        if (!this.options.mark_v_ma) {
	            this.options.mark_v_ma = {};
	
	            // 成交量均线
	            var v_div_mark = document.createElement("div");
	            v_div_mark.className = "mark-ma";
	            v_div_mark.style.left = this.options.padding.left + "px";
	            v_div_mark.style.top = this.options.c2_y_top + "px";
	            this.options.mark_v_ma.mark_v_ma = v_div_mark;
	
	            /*创建文档碎片*/
	            var v_frag = document.createDocumentFragment();
	
	            // 成交量5日均线
	            var v_volume = document.createElement('span');
	            v_volume.className = "span-m30";
	            v_volume.style.position = "absolute";
	            v_volume.style.left = "10px";
	            this.options.mark_v_ma.v_volume = v_volume;
	            if (volume) {
	                this.options.mark_v_ma.v_volume.innerText = "VOLUME: " + common.format_unit(volume, 2);
	            } else {
	                if (this.default_volume) {
	                    this.options.mark_v_ma.v_volume.innerText = "VOLUME: " + common.format_unit(this.default_volume.volume, 2);
	                } else {
	                    this.options.mark_v_ma.v_volume.innerText = "VOLUME: -";
	                }
	            }
	
	            // 成交量5日均线
	            var v_ma_5 = document.createElement('span');
	            v_ma_5.className = "span-m20";
	            v_ma_5.style.position = "absolute";
	            v_ma_5.style.left = "160px";
	            this.options.mark_v_ma.v_ma_5 = v_ma_5;
	            if (obj_5) {
	                this.options.mark_v_ma.v_ma_5.innerText = "MA5: " + common.format_unit(obj_5.value, 2);
	            } else {
	                if (this.default_vm5) {
	                    this.options.mark_v_ma.v_ma_5.innerText = "MA5: " + common.format_unit(this.default_vm5.value, 2);
	                } else {
	                    this.options.mark_v_ma.v_ma_5.innerText = "MA5: -";
	                }
	            }
	
	            // 成交量10日均线
	            var v_ma_10 = document.createElement('span');
	            v_ma_10.className = "span-m5";
	            v_ma_10.style.position = "absolute";
	            // v_ma_10.style.left = this.options.padding.left + this.options.drawWidth * 1/3 - 50 + "px";
	            v_ma_10.style.left = "310px";
	            this.options.mark_v_ma.v_ma_10 = v_ma_10;
	            if (obj_10) {
	                this.options.mark_v_ma.v_ma_10.innerText = "MA10: " + common.format_unit(obj_10.value, 2);
	            } else {
	                if (this.default_vm10) {
	                    this.options.mark_v_ma.v_ma_10.innerText = "MA10: " + common.format_unit(this.default_vm10.value, 2);
	                } else {
	                    this.options.mark_v_ma.v_ma_10.innerText = "MA10: -";
	                }
	            }
	
	            v_frag.appendChild(v_volume);
	            v_frag.appendChild(v_ma_5);
	            v_frag.appendChild(v_ma_10);
	            v_div_mark.appendChild(v_frag);
	
	            document.getElementById(this.options.container).appendChild(v_div_mark);
	            // div_tip.style.left = w_pos.x - 300 + "px";
	        } else {
	            var mark_v_ma = this.options.mark_v_ma.mark_v_ma;
	
	            if (volume) {
	                this.options.mark_v_ma.v_volume.innerText = "VOLUME: " + common.format_unit(volume, 2);
	            } else {
	                if (this.default_volume) {
	                    this.options.mark_v_ma.v_volume.innerText = "VOLUME: " + common.format_unit(this.default_volume.volume, 2);
	                } else {
	                    this.options.mark_v_ma.v_volume.innerText = "VOLUME: -";
	                }
	            }
	
	            if (obj_5) {
	                this.options.mark_v_ma.v_ma_5.innerText = "MA5: " + common.format_unit(obj_5.value, 2);
	            } else {
	                if (this.default_vm5) {
	                    this.options.mark_v_ma.v_ma_5.innerText = "MA5: " + common.format_unit(this.default_vm5.value, 2);
	                } else {
	                    this.options.mark_v_ma.v_ma_5.innerText = "MA5: -";
	                }
	            }
	
	            if (obj_10) {
	                this.options.mark_v_ma.v_ma_10.innerText = "MA10: " + common.format_unit(obj_10.value, 2);
	            } else {
	                if (this.default_vm10) {
	                    this.options.mark_v_ma.v_ma_10.innerText = "MA10: " + common.format_unit(this.default_vm10.value, 2);
	                } else {
	                    this.options.mark_v_ma.v_ma_10.innerText = "MA10: -";
	                }
	            }
	
	
	        }
	
	    }
	
	    Interactive.prototype.markT = function(canvas, type, datas, start, end, index) {
	        var colors = ["#6e9fe9", "#ffba42", "#fe59fe", "#ff7e58"];
	        if (!this.options.markTContainer) {
	            //创建并添加最下方一系列技术指标的外部包含div
	            this.options.markTContainer = document.createElement("div");
	            var markTContainer = this.options.markTContainer;
	            markTContainer.setAttribute("id", "markTContainer");
	            // debugger;
	            markTContainer.style.position = "absolute";
	            markMAContainer.style.fontFamily = "Microsoft Yahei";
	            markMAContainer.style.fontWeight = "lighter";
	            markMAContainer.style.fontSize = "14px";
	            markTContainer.style.top = this.options.c3_y_top + 5 + "px";
	            markTContainer.style.left = this.options.padding.left + 10 + "px";
	
	            /*创建文档碎片*/
	            var frag = document.createDocumentFragment();
	            var co = 0;
	            this.options.markTType = type;
	            for (var item in datas) {
	                var temp = datas[item][datas[item].length - 1];
	                var span = document.createElement('span');
	                span.innerHTML = item.toUpperCase() + ": " + temp.value;
	                span.style.width = "100px";
	                span.style.color = colors[co];
	                co++;
	                span.style.marginRight = "30px";
	                span.setAttribute("id", item + "_mark");
	                frag.appendChild(span);
	            }
	
	            markTContainer.appendChild(frag);
	            this.options[type] = {};
	            this.options[type].defaultTHtml = markTContainer.innerHTML;
	
	            document.getElementById(this.options.container).appendChild(markTContainer);
	        } else {
	            var markTContainer = this.options.markTContainer;
	
	        //判断是不是第一次，是否需要创建元素
	        if (this.options.markTType != type) {
	            //作为是否切换技术指标的依据
	            this.options.markTType = type;
	            //清空markTContainer里面的所有span
	            var spans = markTContainer.getElementsByTagName("span");
	            var len = spans.length;
	            for (var i = 0; i < len; i++) {
	                markTContainer.removeChild(spans[0]);
	            }
	            // debugger;
	            var dataObj = [];
	            for (var item in datas) {
	                dataObj.push({ value: datas[item].slice(start, end), name: item });
	            }
	            /*创建文档碎片*/
	            var m_frag = document.createDocumentFragment();
	            var frag = document.createDocumentFragment();
	                //添加元素
	                var co = 0;
	                if(!this.options[type] || !this.options[type].defaultTHtml){
	                    for (var item in datas) {
	                        var temp = datas[item][datas[item].length - 1];
	                        var span = document.createElement('span');
	                        span.innerHTML = item.toUpperCase() + ": " + temp.value;
	                        span.style.width = "100px";
	                        span.style.color = colors[co];
	                        co++;
	                        span.style.marginRight = "30px";
	                        span.setAttribute("id", item + "_mark");
	                        frag.appendChild(span);
	                    }
	
	                    markTContainer.appendChild(frag);
	
	                    this.options[type] = {};
	                    this.options[type].defaultTHtml = markTContainer.innerHTML;
	                    markTContainer.innerHTML = "";
	                }
	
	            //添加元素
	            for (var i = 0; i < dataObj.length; i++) {
	                var span = document.createElement('span');
	                    span.innerHTML = dataObj[i].name.toUpperCase() + ": " + dataObj[i].value[index].value;
	                span.style.width = "100px";
	                span.style.color = colors[i];
	                span.style.marginRight = "20px";
	                span.setAttribute("id", dataObj[i].name + "_mark");
	                m_frag.appendChild(span);
	            }
	            /*添加到包含元素上*/
	            markTContainer.appendChild(m_frag);
	        } else {
	            var dataObj = [];
	            for (var item in datas) {
	                dataObj.push({ value: datas[item].slice(start, end), name: item });
	            }
	            //更改内容
	            for (var i = 0; i < dataObj.length; i++) {
	                var span = document.getElementById(dataObj[i].name + "_mark");
	                try {
	                    span.innerHTML = dataObj[i].name.toUpperCase() + ": " + dataObj[i].value[index].value;
	                } catch (e) {
	                    // markTContainer.removeChild(span);
	                    if(dataObj[i].value[index].value == null || dataObj[i].value[index].value == undefined){
	                    	span.innerText = dataObj[i].name.toUpperCase() + ": -";
	                    }else{
	                    	var span = document.createElement('span');
		                    span.innerHTML = dataObj[i].name.toUpperCase() + ": " + dataObj[i].value[index];
		                    span.style.width = "100px";
		                    span.style.color = colors[i];
	
		                    span.style.marginRight = "20px";
		                    span.setAttribute("id", dataObj[i].name + "_mark");
		                    markTContainer.appendChild(span);
	                    }
	                    
	                }
	            }
	
	        }
	        }
	
	        
	
	    }
	
	    // 缩放
	    Interactive.prototype.scale = function(canvas) {
	        /*K线图表右下角相对于父容器的位置*/
	        var w_pos = common.canvasToWindow.apply(this, [canvas, canvas.width, this.options.c_k_height]);
	        if (!this.options.scale) {
	            this.options.scale = {};
	            /*创建外部包裹元素*/
	            var scale_div = document.createElement("div");
	            scale_div.className = "scale-div";
	            scale_div.style.left = canvas.width - this.options.padding.right - 120 + "px";
	            scale_div.style.top = w_pos.y - 40 + "px";
	            this.options.scale.scale = scale_div;
	
	            /*创建文档碎片*/
	            var frag = document.createDocumentFragment();
	
	            /*创建减号*/
	            var minus_button = document.createElement('span');
	            minus_button.className = "span-minus";
	            this.options.scale.minus = minus_button;
	
	            /*创建加号*/
	            var plus_button = document.createElement('span');
	            plus_button.className = "span-plus";
	            this.options.scale.plus = plus_button;
	
	            frag.appendChild(minus_button);
	            frag.appendChild(plus_button);
	            scale_div.appendChild(frag);
	            document.getElementById(this.options.container).appendChild(scale_div);
	        }
	    }
	
	    // Tip显示行情数据
	    Interactive.prototype.showTip = function(canvas, x, obj) {
	        // var c_box = canvas.getBoundingClientRect();
	        var type = this.options.type;
	        if (!this.options.tip) {
	            this.options.tip = {};
	            // 创建外部包裹元素
	            var div_tip = document.createElement("div");
	            div_tip.className = "web-show-tip";
	
	            this.options.tip.tip = div_tip;
	            div_tip.style.top = this.options.c1_y_top + 30 + "px";
	
	            // 创建文档碎片
	            var frag = document.createDocumentFragment();
	
	            // 创建收盘价格
	            var date_data = document.createElement('div');
	            date_data.className = "web-tip-first-line";
	            this.options.tip.date_data = date_data;
	            date_data.innerText = obj.date_time;
	
	
	            //组建一行数据
	            var tipsLine = function(type, name) {
	                var data_name = document.createElement('div');
	                data_name.className = "web-tip-line-left";
	                data_name.innerText = name;
	
	                var data_data = document.createElement('div');
	                data_data.className = "web-tip-line-right";
	                this.options.tip[type] = data_data;
	
	                var web_tip_line_container = document.createElement("div");
	                web_tip_line_container.className = "web-tip-line-container";
	                web_tip_line_container.appendChild(data_name);
	                web_tip_line_container.appendChild(data_data);
	
	                return web_tip_line_container;
	            }
	
	            // 创建百分比
	            var percent = document.createElement('span');
	            this.options.tip.percent = percent;
	
	            // 创建股数
	            var count = document.createElement('span');
	            this.options.tip.count = count;
	
	            // 创建时间
	            var time = document.createElement('span');
	            this.options.tip.time = time;
	
	
	            frag.appendChild(date_data);
	            //添加各项数据
	            frag.appendChild(tipsLine.call(this, "open", "开盘"));
	            frag.appendChild(tipsLine.call(this, "height", "最高"));
	            frag.appendChild(tipsLine.call(this, "low", "最低"));
	            frag.appendChild(tipsLine.call(this, "close", "收盘"));
	            frag.appendChild(tipsLine.call(this, "percent", "涨跌幅"));
	            frag.appendChild(tipsLine.call(this, "priceChange", "涨跌额"));
	            frag.appendChild(tipsLine.call(this, "count", "成交量"));
	            // frag.appendChild(tipsLine.call(this, "count", "成交金额"));
	            // frag.appendChild(tipsLine.call(this, "count", "振幅"));
	            // frag.appendChild(tipsLine.call(this, "count", "换手率"));
	            div_tip.appendChild(frag);
	            document.getElementById(this.options.container).appendChild(div_tip);
	            this.options.tip.div_tip_width = div_tip.clientWidth;
	
	            percent.className = percent.className;
	            count.className = count.className;
	            time.className = time.className;
	
	        } else {
	            var tip_obj = this.options.tip;
	            var div_tip = this.options.tip.tip;
	            var volume = obj.volume;
	
	            tip_obj.close.innerText = obj.close;
	            tip_obj.open.innerText = obj.open;
	            tip_obj.height.innerText = obj.highest;
	            tip_obj.low.innerText = obj.lowest;
	            tip_obj.percent.innerText = obj.percent + '%';
	            tip_obj.count.innerText = common.format_unit(volume);
	            tip_obj.priceChange.innerText = obj.priceChange;
	            tip_obj.date_data.innerHTML = obj.date_time;
	            // tip_obj.time.innerText = obj.date_time.replace(/-/g, "/");
	
	        }
	
	
	
	        if (x <= (canvas.width / this.options.dpr / 2)) {
	            div_tip.style.left = (canvas.width - this.options.padding.right) / this.options.dpr - this.options.tip.div_tip_width - 3 + "px";
	        } else if (x >= (canvas.width / this.options.dpr / 2)) {
	            div_tip.style.left = this.options.padding.left / this.options.dpr + "px";
	        } else {}
	
	        // if(x <= (div_tip.clientWidth/2 + this.options.padding_left/this.options.dpr)){
	        //     div_tip.style.left = this.options.padding_left/this.options.dpr + "px";
	        // }else if(x >= (canvas.width/this.options.dpr - div_tip.clientWidth/2)){
	        //     div_tip.style.left = canvas.width/this.options.dpr - div_tip.clientWidth + "px";
	        // }else{
	        //     div_tip.style.left = x - div_tip.clientWidth/2 + "px";
	        // }
	    }
	
	    // 标记上榜日
	    Interactive.prototype.markPoint = function(x, date, canvas, scale_count) {
	        if (scale_count >= 0) {
	            // K线图表右下角相对于父容器的位置
	            var c1_pos = common.canvasToWindow.apply(this, [canvas, canvas.width, this.options.c_1_height]);
	            // 上榜日标记的横坐标
	            var p_pos = common.canvasToWindow.apply(this, [canvas, x, this.options.c_1_height]);
	
	            // 创建外部包裹元素
	            var markPoint = document.createElement("div");
	
	            markPoint.className = "mark-point";
	            var imgUrl = this.options.markPoint.imgUrl;
	            // 上榜日标识宽度
	            var imgWidth = this.options.markPoint.width == undefined ? 15 : this.options.markPoint.width + "px";
	            // 上榜日标识高度
	            var imgHeight = this.options.markPoint.height == undefined ? 15 : this.options.markPoint.height + "px";
	            if (imgUrl) {
	                markPoint.style.background = "url(" + imgUrl + ") no-repeat center center/" + imgWidth + " " + imgHeight + " #cccccc";
	                markPoint.style.background = "url(" + imgUrl + ") no-repeat center center/" + imgWidth + " " + imgHeight + " #cccccc";
	            }
	
	            if (this.options.markPoint.width && this.options.markPoint.height) {
	                markPoint.style.width = imgWidth;
	                markPoint.style.height = imgHeight;
	            } else {
	                markPoint.style.width = imgWidth;
	                markPoint.style.height = imgHeight;
	                // markPoint.style.borderRadius = "5px";
	            }
	            markPoint.setAttribute("data-point", date);
	            if (!this.options.pointsContainer) {
	                var pointsContainer = document.createElement("div");
	                this.options.pointsContainer = pointsContainer;
	                document.getElementById(this.options.container).appendChild(this.options.pointsContainer);
	            }
	            this.options.pointsContainer.appendChild(markPoint);
	            // 定位上榜日标识点的位置
	            markPoint.style.left = p_pos.x - markPoint.clientWidth / 2 + "px";
	            markPoint.style.top = c1_pos.y - 30 + "px";
	
	        }
	
	    }
	
	    // 显示交互效果
	    Interactive.prototype.show = function() {
	
	        if (this.options.cross) {
	            var x_line = this.options.cross.x_line;
	            if (x_line) {
	                x_line.style.display = "block";
	            }
	            var y_line = this.options.cross.y_line;
	            if (y_line) {
	                y_line.style.display = "block";
	            }
	            var point = this.options.cross.point;
	            if (point) {
	                point.style.display = "block";
	            }
	        }
	
	        if (this.options.tip) {
	            var tip = this.options.tip.tip;
	            if (tip) {
	                tip.style.display = "block";
	            }
	
	        }
	
	        if(this.options.webTimeTips){
	            var time_y_left = this.options.webTimeTips.time_y_left;
	            if(time_y_left){
	                time_y_left.style.display = 'block';
	            }
	            var time_y_right = this.options.webTimeTips.time_y_right;
	            if(time_y_right){
	                time_y_right.style.display = 'block';
	            }
	            var time_x_bottom = this.options.webTimeTips.time_x_bottom;
	            if(time_x_bottom){
	                time_x_bottom.style.display = 'block';
	            }
	        }
	
	
	
	    }
	
	    // 隐藏交互效果
	    Interactive.prototype.hide = function() {
	
	        if (this.options.cross) {
	            var x_line = this.options.cross.x_line;
	            if (x_line) {
	                x_line.style.display = "none";
	            }
	            var y_line = this.options.cross.y_line;
	            if (y_line) {
	                y_line.style.display = "none";
	            }
	            var point = this.options.cross.point;
	            if (point) {
	                point.style.display = "none";
	            }
	            
	        }
	
	        if(this.options.markMAContainer){
	            this.options.markMAContainer.innerHTML = this.options[this.options.markUPTType].defaultMaHtml;
	                }
	
	        if(this.options.markTContainer){
	            this.options.markTContainer.innerHTML = this.options[this.options.markTType].defaultTHtml;
	                }
	
	
	        // if (this.options.mark_ma) {
	        //     var ma_5_data = this.options.mark_ma.ma_5_data;
	        //     if (ma_5_data) {
	        //         if (this.default_m5) {
	        //             ma_5_data.innerText = "MA5: " + this.default_m5.value;
	        //         } else {
	        //             ma_5_data.innerText = "MA5: -";
	        //         }
	        //     }
	        //     var ma_10_data = this.options.mark_ma.ma_10_data;
	        //     if (ma_10_data) {
	        //         if (this.default_m10) {
	        //             ma_10_data.innerText = "MA10: " + this.default_m10.value;
	        //         } else {
	        //             ma_10_data.innerText = "MA10: -";
	        //         }
	        //     }
	        //     var ma_20_data = this.options.mark_ma.ma_20_data;
	        //     if (ma_20_data) {
	        //         if (this.default_m20) {
	        //             ma_20_data.innerText = "MA20: " + this.default_m20.value;
	        //         } else {
	        //             ma_20_data.innerText = "MA20: -";
	        //         }
	        //     }
	
	        //     var ma_30_data = this.options.mark_ma.ma_30_data;
	        //     if (ma_30_data) {
	        //         if (this.default_m20) {
	        //             ma_30_data.innerText = "MA30: " + this.default_m30.value;
	        //         } else {
	        //             ma_30_data.innerText = "MA30: -";
	        //         }
	        //     }
	
	        // }
	
	        if (this.options.mark_v_ma) {
	
	            // 成交量5日均线
	            var v_volume = this.options.mark_v_ma.v_volume;
	            if (v_volume) {
	                if (this.default_volume) {
	                    this.options.mark_v_ma.v_volume.innerText = "VOLUME: " + common.format_unit(this.default_volume.volume, 2);
	                } else {
	                    this.options.mark_v_ma.v_volume.innerText = "VOLUME: -";
	                }
	            }
	
	
	            // 成交量5日均线
	            var v_ma_5 = this.options.mark_v_ma.v_ma_5;
	            if (v_ma_5) {
	                if (this.default_vm5) {
	                    this.options.mark_v_ma.v_ma_5.innerText = "MA5: " + common.format_unit(this.default_vm5.value, 2);
	                } else {
	                    this.options.mark_v_ma.v_ma_5.innerText = "MA5: -";
	                }
	            }
	
	            // 成交量10日均线
	            var v_ma_10 = this.options.mark_v_ma.v_ma_10;
	            if (v_ma_10) {
	                if (this.default_vm10) {
	                    this.options.mark_v_ma.v_ma_10.innerText = "MA10: " + common.format_unit(this.default_vm10.value, 2);
	                } else {
	                    this.options.mark_v_ma.v_ma_10.innerText = "MA10: -";
	                }
	            }
	
	        }
	
	        if (this.options.tip) {
	            var tip = this.options.tip.tip;
	            if (tip) {
	                tip.style.display = "none";
	            }
	
	        }
	
	        if(this.options.webTimeTips){
	            var time_y_left = this.options.webTimeTips.time_y_left;
	            if(time_y_left){
	                time_y_left.style.display = 'none';
	            }
	            var time_y_right = this.options.webTimeTips.time_y_right;
	            if(time_y_right){
	                time_y_right.style.display = 'none';
	            }
	            var time_x_bottom = this.options.webTimeTips.time_x_bottom;
	            if(time_x_bottom){
	                time_x_bottom.style.display = 'none';
	            }
	        }
	
	    }
	
	    // 显示loading效果
	    Interactive.prototype.showLoading = function() {
	
	        if (this.options.loading) {
	            this.options.loading.style.display = "block";
	        } else {
	            // 获取图表容器
	            var chart_container = document.getElementById(this.options.container);
	            // var chart_container_height = chart_container.offsetHeight;
	            // loading提示信息
	            var loading_notice = document.createElement("div");
	            loading_notice.className = "loading-chart";
	            loading_notice.innerText = "加载中...";
	            loading_notice.style.height = this.options.height - 100 + "px";
	            loading_notice.style.width = this.options.width + "px";
	            // loading_notice.style.paddingTop = chart_container_height / 2 + "px";
	            loading_notice.style.paddingTop = "100px";
	            // 把提示信息添加到图表容器中
	            this.options.loading = loading_notice;
	            chart_container.appendChild(loading_notice);
	        }
	
	    }
	
	    // 隐藏loading效果
	    Interactive.prototype.hideLoading = function() {
	        this.options.loading.style.display = "none";
	    }
	
	    // 暂无数据
	    Interactive.prototype.showNoData = function() {
	
	        if (this.options.noData) {
	            this.options.noData.style.display = "block";
	        } else {
	            //获取图表容器
	            var noData_container = document.getElementById(this.options.container);
	            // var noData_container_height = noData_container.offsetHeight;
	            //无数据时提示信息
	            var noData_notice = document.createElement("div");
	            noData_notice.className = "loading-chart";
	            noData_notice.innerText = "暂无数据";
	            noData_notice.style.height = this.options.height - 100 + "px";
	            noData_notice.style.width = this.options.width + "px";
	
	            noData_notice.style.paddingTop = "100px";
	            //把提示信息添加到图表容器中
	            this.options.noData = noData_notice;
	            noData_container.appendChild(noData_notice);
	        }
	
	    }
	
	    return Interactive;
	})();
	
	module.exports = Interactive;


/***/ },
/* 46 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制手机K线图
	 *
	 * this:{
	 *     container:画布的容器
	 *     interactive:图表交互
	 * }
	 * this.options:{
	 *     data:    行情数据
	 *     canvas:  画布对象
	 *     ctx:     画布上下文
	 * }
	 *
	 */
	 
	// 绘制坐标轴
	var DrawXY = __webpack_require__(47);
	// 主题
	var theme = __webpack_require__(7);
	// 获取K线图数据
	var GetDataK = __webpack_require__(48); 
	// 获取技术指标数据
	var GetTeacData = __webpack_require__(50); 
	// 绘制K线图
	var DrawK = __webpack_require__(52); 
	// 绘制rsi指标
	var DrawRSI = __webpack_require__(53);
	// 绘制kdj指标
	var DrawKDJ = __webpack_require__(54);
	// 绘制wr指标
	var DrawWR = __webpack_require__(55);
	// 绘制dmi指标
	var DrawDMI = __webpack_require__(56);
	// 绘制bias指标
	var DrawBIAS = __webpack_require__(57);
	// 绘制obv指标
	var DrawOBV = __webpack_require__(58);
	// 绘制cci指标
	var DrawCCI = __webpack_require__(59);
	// 绘制roc指标
	var DrawROC = __webpack_require__(60);
	// 绘制expma指标
	var DrawEXPMA = __webpack_require__(61);
	// 绘制sar指标
	var DrawSAR = __webpack_require__(62);
	// 绘制boll指标
	var DrawBOLL = __webpack_require__(63);
	// 绘制bbi指标
	var DrawBBI = __webpack_require__(64);
	// 绘制macd指标
	var DrawMACD = __webpack_require__(65);
	// 工具
	var common = __webpack_require__(44); 
	// 交互效果
	var Interactive = __webpack_require__(45); 
	// 滑块
	var slideBar = __webpack_require__(66);
	// 拓展，合并，复制
	var extend = __webpack_require__(32);
	// 水印
	var watermark = __webpack_require__(17);
	/*绘制网格虚线*/
	var DrawDashLine = __webpack_require__(40);
	
	var ChartK = (function() {
	
	    function ChartK(options) {
	        this.defaultoptions = theme.chartK;
	        // this.options = {};
	        // extend(true, this.options, theme.defaulttheme, this.defaultoptions, options);
	        this.options = extend(theme.defaulttheme,this.defaultoptions,options);
	
	        // 图表容器
	        this.container = document.getElementById(options.container);
	        // 图表加载完成事件
	        this.options.onChartLoaded = options.onChartLoaded == undefined ? function(op){
	
	        }:options.onChartLoaded;
	    }
	
	    /*初始化*/
	    ChartK.prototype.init = function() {
	        this.options.type = this.options.type == undefined ? "K" : this.options.type;
	        var canvas = document.createElement("canvas");
	        // 去除画布上粘贴效果
	        this.container.style.position = "relative";
	        // 兼容IE6-IE9
	        try {
	            var ctx = canvas.getContext('2d');
	        } catch (error) {
	            canvas = window.G_vmlCanvasManager.initElement(canvas);
	            var ctx = canvas.getContext('2d');
	        }
	        this.options.canvas = canvas;
	        this.options.context = ctx;
	        // 设备像素比
	        var dpr = this.options.dpr = 1;
	        // 容器中添加画布
	        this.container.innerHTML = "";
	        this.container.appendChild(canvas);
	        // 画布的宽和高
	        canvas.width = this.options.width * dpr;
	        canvas.height = this.options.height * dpr;
	
	        // 画布向下偏移的距离
	        // this.options.canvas_offset_top = canvas.height / 8;
	        // 画布内容向坐偏移的距离
	        this.options.padding_left = theme.defaulttheme.padding_left * dpr;
	        // 行情图表（分时图或K线图）和成交量图表的间距
	        this.options.k_v_away = canvas.height / 8;
	        // 缩放默认值
	        this.options.scale_count = this.options.scale_count == undefined ? false : this.options.scale_count;
	        
	
	        canvas.style.width = this.options.width + "px";
	        canvas.style.height = this.options.height + "px";
	        canvas.style.border = "0";
	
	        // 前后复权，默认不复权
	        this.options.authorityType = this.options.authorityType == undefined ? "" : this.options.authorityType;
	        
	        // 画笔参数设置
	        ctx.font = (this.options.font_size * this.options.dpr) + "px Arial";
	        ctx.lineWidth = 1 * this.options.dpr;
	        ctx.strokeStyle = 'rgba(230,230,230, 1)';
	        ctx.fillStyle = '#333';
	        this.options.color = {};
	        this.options.color.strokeStyle = 'rgba(230,230,230, 1)';
	        this.options.color.fillStyle = '#333';
	        this.options.color.m5Color = "#f4cb15";
	        this.options.color.m10Color = "#ff5b10";
	        this.options.color.m20Color = "#488ee6";
	        this.options.color.m30Color = "#fe59fe";
	
	        this.options.padding = {};
	        this.options.padding.left = ctx.measureText("1000").width + 10;
	        this.options.padding.right = 100;
	        this.options.padding.top = 0;
	        this.options.padding.bottom = 0;
	        this.options.drawWidth = canvas.width - this.options.padding.left - this.options.padding.right;
	
	        this.options.y_sepe_num = 20;
	        this.options.x_sepe_num = 10;
	
	        this.options.unit_height = canvas.height * 1 / this.options.y_sepe_num;
	        this.options.unit_width = canvas.width * 1 / this.options.x_sepe_num;
	        this.options.c1_y_top = canvas.height * 1 / this.options.y_sepe_num;
	        this.options.c2_y_top = canvas.height * 10 / this.options.y_sepe_num;
	        this.options.c3_y_top = canvas.height * 14 / this.options.y_sepe_num;
	        this.options.c4_y_top = canvas.height * 18 / this.options.y_sepe_num;
	
	        // K线区域的高度
	        this.options.c_k_height = canvas.height * 8 / this.options.y_sepe_num;
	        // 成交量区域的高度
	        this.options.c_v_height = canvas.height * 3 / this.options.y_sepe_num;
	        this.options.v_base_height = this.options.c_v_height * 0.9;
	        // 技术指标区域的高度
	        this.options.c_t_height = canvas.height * 2 / this.options.y_sepe_num;
	
	
	        this.options.margin = {};
	        this.options.margin.left = 0;
	        this.options.margin.top = canvas.height * 1 / this.options.y_sepe_num;
	
	        // 移动坐标轴
	        ctx.translate("0",this.options.margin.top);
	
	        // 加水印
	        watermark.apply(this,[this.options.context,90 + this.options.padding.right,20,82,20]);
	        
	    };
	
	    // 绘图
	    ChartK.prototype.draw = function(callback) {
	        var _this = this;
	        // 删除canvas画布
	        _this.clear();
	        // 初始化
	        _this.init();
	
	        // 初始化交互
	        var inter = _this.options.interactive = new Interactive(_this.options);
	        // 显示loading效果
	        inter.showLoading();
	
	        var type = _this.options.type;
	        try{
	            GetDataK(getParamsObj.call(_this),function(data){
	
	                var flag = dataCallback.apply(_this,[data]);
	                if(flag){
	                    // K线图均线数据标识
	                    // inter.markMA(_this.options.canvas);
	                    // 成交量均线数据标识
	                    inter.markVMA(_this.options.canvas);
	
	                    // 缩放
	                    // inter.scale(_this.options.canvas);
	                    // 绑定事件
	                    bindEvent.call(_this,_this.options.context);
	                }
	                // 传入的回调函数
	                if(callback){
	                    callback(_this.options);
	                }
	            });
	            
	
	        }catch(e){
	            // 暂无数据
	            inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	
	        drawT.apply(this,[]);
	        drawKT.apply(this);
	        // this.drawRSI();
	        // this.drawKDJ();
	        // this.drawWR();
	        // this.drawDMI();
	        // this.drawBIAS();
	        // this.drawOBV();
	        // this.drawCCI();
	        // this.drawROC();
	
	    };
	    // 重绘
	    ChartK.prototype.reDraw = function() {
	        // 删除canvas画布
	        this.clear();
	        // 初始化
	        this.init();
	        dataCallback.call(this);
	    }
	    // 删除canvas画布
	    ChartK.prototype.clear = function(cb) {
	        try{
	            var ctx = this.options.context;
	            ctx.clearRect(0,0,this.options.padding.left + this.options.drawWidth,this.options.c4_y_top);
	        }catch(e){
	            this.container.innerHTML = "";
	        }
	
	    }
	
	    // 获取上榜日标识dom
	    ChartK.prototype.getMarkPointsDom = function(cb) {
	        var points =  this.options.interactive.options.pointsContainer.children;
	        return points;
	    }
	
	    function slideBarCallback(start,end){
	        this.clear();
	
	        this.options.start = start;
	        this.options.end = end;
	
	        var canvas = this.options.canvas;
	        this.options.currentData = sliceData(this.options.data,start,end);
	        var current_arr_length = this.options.currentData.data.length;
	        
	
	        // 获取单位绘制区域
	        var rect_unit = common.get_rect.apply(this,[canvas,current_arr_length]);
	        this.options.rect_unit = rect_unit;
	
	        this.options.drawXY.options.currentData = this.options.currentData;
	
	        this.options.drawXY.options.XMark = getXMARK.apply(this,[this.options.currentData.data]);
	        this.options.drawXY.drawXYK();
	        this.options.drawXY.drawXYV();
	        this.options.drawXY.drawXYT();
	
	        var up_t = this.options.up_t;
	        var down_t = this.options.down_t;
	
	        if(up_t == "junxian"){
	            this.drawMA(start,end);
	        }else if(up_t == "sar"){
	            this.drawSAR(start,end);
	        }else if(up_t == "boll"){
	            this.drawBOLL(start,end);
	        }else if(up_t == "bbi"){
	            this.drawBBI(start,end);
	        }else if(up_t == "expma"){
	            this.drawEXPMA(start,end);
	        }
	
	        if(down_t == "rsi"){
	            this.drawRSI(start,end);
	        }else if(down_t == "kdj"){
	            this.drawKDJ(start,end);
	        }else if(down_t == "macd"){
	            this.drawMACD(start,end);
	        }else if(down_t == "wr"){
	            this.drawWR(start,end);
	        }else if(down_t == "dmi"){
	            this.drawDMI(start,end);
	        }else if(down_t == "bias"){
	            this.drawBIAS(start,end);
	        }else if(down_t == "obv"){
	            this.drawOBV(start,end);
	        }else if(down_t == "cci"){
	            this.drawCCI(start,end);
	        }else if(down_t == "roc"){
	            this.drawROC(start,end);
	        }
	
	        drawV.apply(this);
	        // 绘制成交量均线
	        this.drawVMA();
	        this.drawK();
	    }
	
	    //绘制k线图的各种指标
	    function drawKT(){
	        var _this = this;
	        //首先绘制出div
	        var pad = document.createElement("div");
	        pad.className = "kt-pad";
	        var frag = document.createDocumentFragment();
	        var kt_title = document.createElement("div");
	        kt_title.className = "kt-title";
	        kt_title.innerHTML = "主图指标";
	        frag.appendChild(kt_title);
	        //
	        var appendLine = function(name,id, frag, isDefault){
	            var container = document.createElement("div");
	            container.className = "kt-line";
	            var radioWrap = document.createElement('div');
	            radioWrap.className = "kt-radio-wrap";
	            var radio = document.createElement("div");
	            radio.setAttribute("id",id);
	            radio.className = isDefault ?   "kt-radio kt-radio-choose"  : "kt-radio";
	            radioWrap.appendChild(radio);
	
	            container.appendChild(radioWrap);
	            var nameText = document.createElement("div");
	            nameText.className = "kt-name";
	            nameText.innerHTML = name;
	            container.appendChild(nameText);
	            //添加点击事件
	            common.addEvent(container, "click", function(e){
	                var targetElement;
	                var currentTarget = e.srcElement || e.target;
	
	                switch(currentTarget.className){
	                    case "kt-line":
	                        targetElement = currentTarget.children[0].children[0];
	                        break;
	                    case "kt-radio-wrap":
	                        targetElement = currentTarget.children[0];
	                        break;
	                    case "kt-radio":
	                        targetElement = currentTarget;
	                        break;
	                    case "kt-name":
	                        targetElement = currentTarget.parentNode.children[0].children[0];
	                        break;
	                }
	                var preEle = document.getElementById(_this.options.up_t);
	                preEle.className = "kt-radio";
	                targetElement.className = "kt-radio kt-radio-choose";
	
	                if(targetElement.id == "junxian"){
	                    _this.options.up_t = "junxian";
	                    _this.drawMA(_this.options.start, _this.options.end);
	                }else if(targetElement.id == "expma"){
	                    _this.options.up_t = "expma";
	                    _this.drawEXPMA(_this.options.start, _this.options.end);
	                }else if(targetElement.id == "sar"){
	                    _this.options.up_t = "sar";
	                    _this.drawSAR(_this.options.start, _this.options.end);
	                }else if(targetElement.id == "boll"){
	                    _this.options.up_t = "boll";
	                    _this.drawBOLL(_this.options.start, _this.options.end);
	                }else if(targetElement.id == "bbi"){
	                    _this.options.up_t = "bbi";
	                    _this.drawBBI(_this.options.start, _this.options.end);
	                }
	
	            });
	
	            frag.appendChild(container);
	        };
	        //添加各种kt指标进pad
	        appendLine("均线", "junxian", frag, true);
	        appendLine("EXPMA", "expma", frag);
	        appendLine("SAR", "sar", frag);
	        appendLine("BOLL", "boll", frag);
	        appendLine("BBI", "bbi", frag);
	
	        pad.appendChild(frag);
	        this.container.appendChild(pad);
	        
	        pad.style.top = this.options.c1_y_top + "px";
	        pad.style.left = this.options.canvas.width - this.options.padding.right + "px";
	        
	    }
	
	    // 绘制技术指标
	    function drawT(){
	        var _this = this;
	        var ctx = this.options.context;
	        var canvas = this.options.canvas;
	        var div_tech = document.createElement("div");
	        div_tech.className = "tech-index";
	        div_tech.style.width = this.options.drawWidth;
	        div_tech.style.left = this.options.padding.left + "px";
	        div_tech.style.top = canvas.height * 17 / this.options.y_sepe_num + "px";
	
	        // rsi指标
	        var rsi = document.createElement("div");
	        rsi.setAttribute("id","rsi");
	        rsi.className = "tech-index-item current";
	        rsi.innerText = "RSI";
	        rsi.style.width = this.options.drawWidth / 9 + "px";
	        rsi.style.height = this.options.unit_height + "px";
	        rsi.style.lineHeight = this.options.unit_height + "px";
	
	        // kdj指标
	        var kdj = document.createElement("div");
	        kdj.setAttribute("id","kdj");
	        kdj.className = "tech-index-item";
	        kdj.innerText = "KDJ";
	        kdj.style.width = this.options.drawWidth / 9 + "px";
	        kdj.style.height = this.options.unit_height + "px";
	        kdj.style.lineHeight = this.options.unit_height + "px";
	
	        // macd指标
	        var macd = document.createElement("div");
	        macd.setAttribute("id","macd");
	        macd.className = "tech-index-item";
	        macd.innerText = "MACD";
	        macd.style.width = this.options.drawWidth / 9 + "px";
	        macd.style.height = this.options.unit_height + "px";
	        macd.style.lineHeight = this.options.unit_height + "px";
	
	        // wr指标
	        var wr = document.createElement("div");
	        wr.setAttribute("id","wr");
	        wr.className = "tech-index-item";
	        wr.innerText = "WR";
	        wr.style.width = this.options.drawWidth / 9 + "px";
	        wr.style.height = this.options.unit_height + "px";
	        wr.style.lineHeight = this.options.unit_height + "px";
	
	        // dmi指标
	        var dmi = document.createElement("div");
	        dmi.setAttribute("id","dmi");
	        dmi.className = "tech-index-item";
	        dmi.innerText = "DMI";
	        dmi.style.width = this.options.drawWidth / 9 + "px";
	        dmi.style.height = this.options.unit_height + "px";
	        dmi.style.lineHeight = this.options.unit_height + "px";
	
	        // bias指标
	        var bias = document.createElement("div");
	        bias.setAttribute("id","bias");
	        bias.className = "tech-index-item";
	        bias.innerText = "BIAS";
	        bias.style.width = this.options.drawWidth / 9 + "px";
	        bias.style.height = this.options.unit_height + "px";
	        bias.style.lineHeight = this.options.unit_height + "px";
	
	        // obv指标
	        var obv = document.createElement("div");
	        obv.setAttribute("id","obv");
	        obv.className = "tech-index-item";
	        obv.innerText = "OBV";
	        obv.style.width = this.options.drawWidth / 9 + "px";
	        obv.style.height = this.options.unit_height + "px";
	        obv.style.lineHeight = this.options.unit_height + "px";
	
	        // cci指标
	        var cci = document.createElement("div");
	        cci.setAttribute("id","cci");
	        cci.className = "tech-index-item";
	        cci.innerText = "CCI";
	        cci.style.width = this.options.drawWidth / 9 + "px";
	        cci.style.height = this.options.unit_height + "px";
	        cci.style.lineHeight = this.options.unit_height + "px";
	
	        // roc指标
	        var roc = document.createElement("div");
	        roc.setAttribute("id","roc");
	        roc.className = "tech-index-item";
	        roc.innerText = "ROC";
	        roc.style.width = this.options.drawWidth / 9 + "px";
	        roc.style.height = this.options.unit_height + "px";
	        roc.style.lineHeight = this.options.unit_height + "px";
	
	        div_tech.appendChild(rsi);
	        div_tech.appendChild(kdj);
	        div_tech.appendChild(macd);
	        div_tech.appendChild(wr);
	        div_tech.appendChild(dmi);
	        div_tech.appendChild(bias);
	        div_tech.appendChild(obv);
	        div_tech.appendChild(cci);
	        div_tech.appendChild(roc);
	        this.container.appendChild(div_tech);
	
	        var current = rsi;
	
	        common.addEvent.call(_this, rsi, "click",function(event){
	            _this.drawRSI();
	            current.className = current.className.replace(" current","");
	            current = rsi;
	            current.className = current.className + " current";
	        });
	
	        common.addEvent.call(_this, kdj, "click",function(event){
	            _this.drawKDJ();
	            current.className = current.className.replace(" current","");
	            current = kdj;
	            current.className = current.className + " current";
	        });
	
	        common.addEvent.call(_this, macd, "click",function(event){
	            _this.drawMACD();
	            current.className = current.className.replace(" current","");
	            current = macd;
	            current.className = current.className + " current";
	        });
	
	        common.addEvent.call(_this, wr, "click",function(event){
	            _this.drawWR();
	            current.className = current.className.replace(" current","");
	            current = wr;
	            current.className = current.className + " current";
	        });
	
	        common.addEvent.call(_this, dmi, "click",function(event){
	            _this.drawDMI();
	            current.className = current.className.replace(" current","");
	            current = dmi;
	            current.className = current.className + " current";
	        });
	
	        common.addEvent.call(_this, bias, "click",function(event){
	            _this.drawBIAS();
	            current.className = current.className.replace(" current","");
	            current = bias;
	            current.className = current.className + " current";
	        });
	
	        common.addEvent.call(_this, obv, "click",function(event){
	            _this.drawOBV();
	            current.className = current.className.replace(" current","");
	            current = obv;
	            current.className = current.className + " current";
	        });
	
	        common.addEvent.call(_this, cci, "click",function(event){
	            _this.drawCCI();
	            current.className = current.className.replace(" current","");
	            current = cci;
	            current.className = current.className + " current";
	        });
	
	        common.addEvent.call(_this, roc, "click",function(event){
	            _this.drawROC();
	            current.className = current.className.replace(" current","");
	            current = roc;
	            current.className = current.className + " current";
	        });
	
	    }
	
	    // 绘制成交量
	    function drawV(){
	
	        var ctx = this.options.context;
	        var data = this.options.currentData;
	        /*成交量数组*/
	        var data_arr = data.data;
	        /*Y轴上的最大值*/
	        // var y_max = data.max;
	        /*Y轴上的最小值*/
	        // var y_min = data.min;
	        /*最大成交量*/
	        var v_max = (data.v_max/1).toFixed(0);
	
	        /*K线图表的高度*/
	        // var c_k_height = this.options.c_k_height;
	        //成交量图表的高度
	        // var v_height = ctx.canvas.height - c_k_height - this.options.k_v_away - this.options.margin.top;
	        var v_height = ctx.canvas.height * 3 / this.options.y_sepe_num;
	
	        var v_base_height = this.options.v_base_height;
	
	        var c2_y_top = this.options.c2_y_top;
	        var y_v_bottom = this.options.c2_y_top + v_height;
	
	        /*获取单位矩形对象*/
	        var rect_unit = this.options.rect_unit;
	
	        /*单位绘图矩形画布的宽度*/
	        // var rect_w = rect_unit.rect_w;
	        /*K线柱体的宽度*/
	        var bar_w = rect_unit.bar_w;
	        /*K线柱体的颜色*/
	        var up_color = this.options.up_color;
	        var down_color =this.options.down_color;
	
	        //标识最大成交量
	        // markVMax.apply(this,[ctx,v_max,c2_y_top]);
	
	        ctx.lineWidth = 1;
	        for(var i = 0,item; item = data_arr[i]; i++){
	
	            var volume = item.volume;
	            var is_up = item.up;
	            var bar_height = volume/v_max * v_base_height;
	            var x = common.get_x.call(this,i + 1);
	            var y = y_v_bottom - bar_height;
	
	            ctx.beginPath();
	            ctx.moveTo(x,y);
	
	            if(is_up){
	                ctx.fillStyle = up_color;
	                ctx.strokeStyle = up_color;
	            }else{
	                ctx.fillStyle = down_color;
	                ctx.strokeStyle = down_color;
	            }
	
	            ctx.rect(x - bar_w/2,y,bar_w,bar_height);
	            ctx.stroke();
	            ctx.fill();
	
	        }
	
	    }
	
	    // 绘制成交量均线
	    ChartK.prototype.drawVMA = function(){
	
	        var data = this.options.currentData;
	        var ctx = this.options.context;
	        // 图表交互
	        var inter = this.options.interactive;
	        var v_ma_5 = data.v_ma_5;
	        var v_ma_10 = data.v_ma_10;
	        var v_max = (data.v_max/1).toFixed(0);
	        var v_base_height = this.options.v_base_height;
	        var c2_y_top = this.options.c2_y_top;
	
	
	        this.options.v_ma_5 = getMAData.apply(this,[ctx,v_ma_5, this.options.color.m20Color]);
	        this.options.v_ma_10 = getMAData.apply(this,[ctx,v_ma_10, this.options.color.m5Color]);
	        
	        inter.default_volume = data.data[data.data.length - 1];
	        inter.default_vm5 = v_ma_5[v_ma_5.length - 1];
	        inter.default_vm10 = v_ma_10[v_ma_10.length - 1];
	
	        function getMAData(ctx,data_arr,color) {
	            var ma_data = [];
	            ctx.save();
	            ctx.beginPath();
	            ctx.strokeStyle = color;
	            for(var i = 0;i < data_arr.length; i++){
	                var item = data_arr[i];
	                if(item){
	                     var x = common.get_x.call(this,i + 1);
	                     var y = (1 - item.value / v_max) * v_base_height + c2_y_top;
	                     //横坐标和均线数据
	                     ma_data.push(item);
	                     if(i == 0){
	                        ctx.moveTo(x,y);
	                     }else{
	                        ctx.lineTo(x,y);
	                     }
	                }
	                 
	            }
	            ctx.stroke();
	            ctx.restore();
	            return ma_data;
	        }
	
	        // 标识最大成交量
	        function markVMax(ctx,v_max,y_v_end){
	            ctx.beginPath();
	            ctx.fillStyle = '#999';
	            ctx.fillText(common.format_unit(v_max),0,y_v_end + 10);
	            ctx.stroke();
	        }
	
	        // 获取最大成交量
	        function getVMax(data){
	            if(data.data[0]){
	                var max = data.data[0].volume;
	            }else{
	                var max = 0;
	            }
	            
	            for(var i = 0,item = data.data;i<data.data.length;i++) {
	                if(max<item[i].volume)
	                {
	                    max=item[i].volume;
	                }
	            }
	            return max;
	        }
	    }
	
	    // 绘制均线和rsi指标
	    function init_ma_rsi(){
	
	        var _this = this;
	        this.clearK();
	        this.options.drawXY.drawXYK();
	        this.drawK();
	
	        var inter = this.options.interactive;
	
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = "ma|rsi";
	        this.options.up_t = "junxian";
	        this.options.down_t = "rsi";
	
	        GetTeacData(params, function(data) {
	
	            _this.options.junxian = {};
	            /*5日均线数据*/
	            _this.options.junxian.ma5 = data.five_average;
	            /*10日均线数据*/
	            _this.options.junxian.ma10 = data.ten_average;
	            /*20日均线数据*/
	            _this.options.junxian.ma20 = data.twenty_average;
	            /*30日均线数据*/
	            _this.options.junxian.ma30 = data.thirty_average;
	
	            _this.options.rsi = {};
	            _this.options.rsi.rsi6 = data.rsi6;
	            _this.options.rsi.rsi12 = data.rsi12;
	            _this.options.rsi.rsi24 = data.rsi24;
	
	            temp_ma.apply(_this,[]);
	            temp_rsi.apply(_this,[]);
	
	            inter.markMA(_this.options.canvas, "junxian", _this.options["junxian"], _this.options.start, _this.options.end, "");
	            inter.markT(_this.options.canvas, "rsi", _this.options["rsi"], _this.options.start, _this.options.end, "");
	        });
	
	        function temp_rsi(){
	            var rsi6 = this.options.rsi.rsi6;
	            var rsi12 = this.options.rsi.rsi12;
	            var rsi24 = this.options.rsi.rsi24;
	            var start = this.options.start;
	            var end = this.options.end;
	            DrawRSI.apply(this,[this.options.context,rsi6.slice(start,end),rsi12.slice(start,end),rsi24.slice(start,end)]);
	        }
	
	        function temp_ma(){
	            var _this = this;
	            var ctx = _this.options.context;
	            var data = _this.options.junxian;
	            var start = _this.options.start;
	            var end = _this.options.end;
	            // 图表交互
	            var inter = _this.options.interactive;
	            /*5日均线数据*/
	            var five_average = data.ma5.slice(start, end);
	            /*10日均线数据*/
	            var ten_average = data.ma10.slice(start, end);
	            /*20日均线数据*/
	            var twenty_average = data.ma20.slice(start, end);
	            /*30日均线数据*/
	            var thirty_average = data.ma30.slice(start, end);
	
	            // var v_ma_5 = data.v_ma_5;
	            // var v_ma_10 = data.v_ma_10;
	
	            inter.default_m5 = five_average[five_average.length - 1];
	            inter.default_m10 = ten_average[ten_average.length - 1];
	            inter.default_m20 = twenty_average[twenty_average.length - 1];
	            inter.default_m30 = thirty_average[thirty_average.length - 1];
	
	            // inter.default_volume = data.data[data.data.length - 1];
	            // inter.default_vm5 = v_ma_5[v_ma_5.length - 1];
	            // inter.default_vm10 = v_ma_10[v_ma_10.length - 1];
	
	            getMAData.apply(_this, [ctx, five_average, this.options.color.m5Color]);
	            getMAData.apply(_this, [ctx, ten_average, this.options.color.m10Color]);
	            getMAData.apply(_this, [ctx, twenty_average, this.options.color.m20Color]);
	            getMAData.apply(_this, [ctx, thirty_average, this.options.color.m30Color]);
	        }
	        
	
	        function getMAData(ctx, data_arr, color) {
	
	            // 保存画笔状态
	            ctx.save();
	            var ma_data = [];
	            ctx.beginPath();
	            ctx.strokeStyle = color;
	            var flag = false;
	            for (var i = 0; i < data_arr.length; i++) {
	                var item = data_arr[i];
	                if (item && item.value) {
	                    var x = common.get_x.call(this, i + 1);
	                    var y = common.get_y.call(this, item.value);
	                    //横坐标和均线数据
	                    ma_data.push(item);
	                    if(i == 0){
	                       ctx.moveTo(x,y);
	                    }else if(y > this.options.c_k_height || y < 0){
	                       ctx.moveTo(x,y);
	                       flag = true;
	                    }else{
	                        if(flag){
	                            ctx.moveTo(x,y);
	                        }else{
	                            ctx.lineTo(x,y);
	                        }
	                        flag = false;
	                    }
	                    // ctx.lineTo(x, y);
	                }
	                ctx.lineTo(x,y);
	            }
	
	            ctx.stroke();
	            ctx.restore();
	
	            return ma_data;
	        }
	
	    }
	
	    // 绘制K线均线
	    ChartK.prototype.drawMA = function(start, end){
	        
	        var _this = this;
	
	        this.clearK();
	        this.options.drawXY.drawXYK();
	        this.drawK();
	
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = "ma";
	
	        if(this.options.junxian){
	            data = _this.options.junxian;
	            temp_ma.apply(_this,[]);
	        } else {
	             GetTeacData(params, function(data) {
	                _this.options.junxian = {};
	                /*5日均线数据*/
	                _this.options.junxian.ma5 = data.five_average;
	                /*10日均线数据*/
	                _this.options.junxian.ma10 = data.ten_average;
	                /*20日均线数据*/
	                _this.options.junxian.ma20 = data.twenty_average;
	                /*30日均线数据*/
	                _this.options.junxian.ma30 = data.thirty_average;
	
	                temp_ma.apply(_this,[]);
	            });
	        }
	
	        function temp_ma(){
	            var _this = this;
	            var ctx = _this.options.context;
	            var data = _this.options.junxian;
	
	            // 图表交互
	            var inter = _this.options.interactive;
	            /*5日均线数据*/
	            var five_average = data.ma5.slice(start, end);
	            /*10日均线数据*/
	            var ten_average = data.ma10.slice(start, end);
	            /*20日均线数据*/
	            var twenty_average = data.ma20.slice(start, end);
	            /*30日均线数据*/
	            var thirty_average = data.ma30.slice(start, end);
	
	            // var v_ma_5 = data.v_ma_5;
	            // var v_ma_10 = data.v_ma_10;
	
	            inter.default_m5 = five_average[five_average.length - 1];
	            inter.default_m10 = ten_average[ten_average.length - 1];
	            inter.default_m20 = twenty_average[twenty_average.length - 1];
	            inter.default_m30 = thirty_average[thirty_average.length - 1];
	
	            // inter.default_volume = data.data[data.data.length - 1];
	            // inter.default_vm5 = v_ma_5[v_ma_5.length - 1];
	            // inter.default_vm10 = v_ma_10[v_ma_10.length - 1];
	
	            getMAData.apply(_this, [ctx, five_average, this.options.color.m5Color]);
	            getMAData.apply(_this, [ctx, ten_average, this.options.color.m10Color]);
	            getMAData.apply(_this, [ctx, twenty_average, this.options.color.m20Color]);
	            getMAData.apply(_this, [ctx, thirty_average, this.options.color.m30Color]);
	        }
	        
	
	        function getMAData(ctx, data_arr, color) {
	
	            // 保存画笔状态
	            ctx.save();
	            var ma_data = [];
	            ctx.beginPath();
	            ctx.strokeStyle = color;
	            var flag = false;
	            for (var i = 0; i < data_arr.length; i++) {
	                var item = data_arr[i];
	                if (item && item.value) {
	                    var x = common.get_x.call(this, i + 1);
	                    var y = common.get_y.call(this, item.value);
	                    //横坐标和均线数据
	                    ma_data.push(item);
	                    if(i == 0){
	                       ctx.moveTo(x,y);
	                    }else if(y > this.options.c_k_height || y < 0){
	                       ctx.moveTo(x,y);
	                       flag = true;
	                    }else{
	                        if(flag){
	                            ctx.moveTo(x,y);
	                        }else{
	                            ctx.lineTo(x,y);
	                        }
	                        flag = false;
	                    }
	                    // ctx.lineTo(x, y);
	                }
	                ctx.lineTo(x,y);
	            }
	
	            ctx.stroke();
	            ctx.restore();
	
	            return ma_data;
	        }
	    }
	
	    // 绘制K线图
	    ChartK.prototype.drawK = function(data){
	        
	        var data_arr = data == undefined ? this.options.currentData.data : data;
	
	        var ctx = this.options.context;
	        // 获取单位绘制区域
	        var rect_unit = this.options.rect_unit;
	        // 单位绘制区域的宽度
	        // var rect_w = rect_unit.rect_w;
	        // K线柱体的宽度
	        var bar_w = rect_unit.bar_w;
	        // K线柱体的颜色
	        var up_color = this.options.up_color;
	        var down_color =this.options.down_color
	        // 图表交互
	        var inter = this.options.interactive;
	        // 上榜日数组
	        var pointObj = {};
	        if(this.options.markPoint && this.options.markPoint.show){
	            var array = this.options.markPoint.dateList;
	            for(var index in array){
	                pointObj[array[index]] = array[index];
	            }
	        }
	
	        var params = {};
	       
	        for(var i = 0,item; item = data_arr[i]; i++){
	            // 是否上涨
	            var is_up = item.up;
	
	            ctx.beginPath();
	            ctx.lineWidth = 1;
	
	            if(is_up){
	                ctx.fillStyle = up_color;
	                ctx.strokeStyle = up_color
	            }else{
	                ctx.fillStyle = down_color
	                ctx.strokeStyle = down_color
	            }
	
	            params.ctx = ctx;
	            var x = params.x = common.get_x.call(this,i + 1);
	            var y_open = params.y_open = common.get_y.call(this,item.open);
	            var y_close = params.y_close = common.get_y.call(this,item.close);
	            var y_highest = params.y_highest = common.get_y.call(this,item.highest);
	            var y_lowest = params.y_lowest = common.get_y.call(this,item.lowest);
	
	            item.cross_x = x;
	            item.cross_y = y_close;
	
	            //标识上榜日
	            if(pointObj[item.data_time]){
	                inter.markPoint(x,item.data_time,this.options.context.canvas,this.options.scale_count);
	            }
	            // 获取单位绘制区域
	            var rect_unit = this.options.rect_unit;
	            // K线柱体的宽度
	            var bar_w = params.bar_w = rect_unit.bar_w;
	
	            DrawK.apply(this,[params]);
	
	        }
	
	    };
	
	
	
	    // 绘制RSI指标
	    ChartK.prototype.drawRSI = function(start,end){
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "rsi";
	
	        if(this.options.rsi){
	            temp_rsi.apply(_this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.rsi = {};
	                _this.options.rsi.rsi6 = data.rsi6;
	                _this.options.rsi.rsi12 = data.rsi12;
	                _this.options.rsi.rsi24 = data.rsi24;
	                temp_rsi.apply(_this,[]);
	            });
	        }
	
	        function temp_rsi(){
	            var rsi6 = this.options.rsi.rsi6;
	            var rsi12 = this.options.rsi.rsi12;
	            var rsi24 = this.options.rsi.rsi24;
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	            DrawRSI.apply(this,[this.options.context,rsi6.slice(start,end),rsi12.slice(start,end),rsi24.slice(start,end)]);
	        }
	
	    }
	
	    // 绘制KDJ指标
	    ChartK.prototype.drawKDJ = function(start,end){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "kdj";
	
	        if(this.options.kdj){
	            temp_kdj.apply(_this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.kdj = {};
	                _this.options.kdj.k = data.k;
	                _this.options.kdj.d = data.d;
	                _this.options.kdj.j = data.j;
	                temp_kdj.apply(_this,[]);
	            });
	        }
	
	        function temp_kdj(){
	            var k = this.options.kdj.k;
	            var d = this.options.kdj.d;
	            var j = this.options.kdj.j;
	
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	            DrawKDJ.apply(this,[this.options.context,k.slice(start,end),d.slice(start,end),j.slice(start,end)]);
	        }
	        
	    }
	
	    // 绘制MACD指标
	    ChartK.prototype.drawMACD = function(start,end){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "macd";
	
	        if(this.options.macd){
	            temp_macd.apply(this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.macd = {};
	                _this.options.macd.dea = data.dea;
	                _this.options.macd.diff = data.diff;
	                _this.options.macd.macd = data.macd;
	                temp_macd.apply(_this,[]);
	            });
	        }
	
	        function temp_macd(){
	            var dea = this.options.macd.dea;
	            var diff = this.options.macd.diff;
	            var macd = this.options.macd.macd;
	
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	            DrawMACD.apply(_this,[_this.options.context,dea.slice(start,end),diff.slice(start,end),macd.slice(start,end)]);
	        }
	        
	    }
	
	    // 绘制WD指标
	    ChartK.prototype.drawWR = function(start,end){
	        
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "wr";
	        if(this.options.wr){
	            temp_wr.apply(this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.wr = {};
	                _this.options.wr.wr6 = data.wr6;
	                _this.options.wr.wr10 = data.wr10;
	                temp_wr.apply(_this,[]);
	            });
	        }
	
	        function temp_wr(){
	
	            var wr6 = this.options.wr.wr6;
	            var wr10 = this.options.wr.wr10;
	
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	            DrawWR.apply(_this,[_this.options.context,wr6.slice(start,end),wr10.slice(start,end)]);
	
	        }
	
	    }
	
	    // 绘制DMI指标
	    ChartK.prototype.drawDMI = function(start,end){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "dmi";
	
	        if(this.options.dmi){
	             temp_dmi.apply(_this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.dmi = {};
	                _this.options.dmi.pdi = data.pdi;
	                _this.options.dmi.mdi = data.mdi;
	                _this.options.dmi.adx = data.adx;
	                _this.options.dmi.adxr = data.adxr;
	                temp_dmi.apply(_this,[]);
	            });
	
	        }
	
	        function temp_dmi(){
	
	            var pdi = this.options.dmi.pdi;
	            var mdi = this.options.dmi.mdi;
	            var adx = this.options.dmi.adx;
	            var adxr = this.options.dmi.adxr;
	
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	
	            DrawDMI.apply(_this,[_this.options.context,pdi.slice(start,end),mdi.slice(start,end),adx.slice(start,end),adxr.slice(start,end)]);
	
	        }
	
	        
	    }
	
	    // 绘制BIAS指标
	    ChartK.prototype.drawBIAS = function(start,end){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "bias";
	
	        if(this.options.bias){
	            temp_bias.apply(_this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.bias = {};
	                _this.options.bias.bias6 = data.bias6;
	                _this.options.bias.bias12 = data.bias12;
	                _this.options.bias.bias24 = data.bias24;
	                temp_bias.apply(_this,[]);
	            });
	        }
	
	        function temp_bias(){
	
	            var bias6 = this.options.bias.bias6;
	            var bias12 = this.options.bias.bias12;
	            var bias24 = this.options.bias.bias24;
	       
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	
	            DrawBIAS.apply(this,[this.options.context,bias6.slice(start,end),bias12.slice(start,end),bias24.slice(start,end)]);
	
	        }
	        
	    }
	
	    // 绘制OBV指标
	    ChartK.prototype.drawOBV = function(start,end){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "obv";
	
	        if(_this.options.obv){
	            temp_obv.apply(this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.obv = {};
	                var obv = _this.options.obv.obv = data.obv;
	                var maobv = _this.options.obv.maobv = data.maobv;
	                temp_obv.apply(_this,[]);
	            });
	        }
	
	        function temp_obv(){
	
	            var obv = this.options.obv.obv;
	            var maobv = this.options.obv.maobv;
	
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	
	            DrawOBV.apply(this,[this.options.context,obv.slice(start,end),maobv.slice(start,end)]);
	        }
	
	
	    }
	
	    // 绘制CCI指标
	    ChartK.prototype.drawCCI = function(start,end){
	
	        var _this = this;
	        
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "cci";
	        
	        if(this.options.cci){
	            temp_cci.apply(_this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.cci = {};
	                _this.options.cci.cci = data.cci;
	                temp_cci.apply(_this,[]);
	            });
	        }
	
	        function temp_cci(){
	            var cci = this.options.cci.cci;
	
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	
	            DrawCCI.apply(this,[this.options.context,cci.slice(start,end)]);
	        }
	        
	        
	    }
	
	    // 绘制ROC指标
	    ChartK.prototype.drawROC = function(start,end){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.down_t = "roc";
	
	        if(_this.options.roc){
	            temp_roc.apply(_this,[]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.roc = {};
	                _this.options.roc.roc = data.roc;
	                _this.options.roc.rocma = data.rocma;
	                
	                temp_roc.apply(_this,[]);
	            });
	        }
	
	        function temp_roc(){
	            var roc = _this.options.roc.roc;
	            var rocma = _this.options.roc.rocma;
	
	            if(start == undefined || end == undefined ){
	                start = this.options.start;
	                end = this.options.end;
	            }
	
	            DrawROC.apply(_this,[_this.options.context,roc.slice(start,end),rocma.slice(start,end)]);
	        }        
	    }
	
	    // 绘制expma指标
	    ChartK.prototype.drawEXPMA = function(){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.up_t = "expma";
	
	        if(this.options.expma){
	
	            temp_expma.apply(_this,[this.options.start, this.options.end]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.expma = {};
	
	                _this.options.expma.expma12 = data.expma12;
	                _this.options.expma.expma50 = data.expma50;
	
	                temp_expma.apply(_this,[_this.options.start, _this.options.end]);
	            });  
	        }
	
	        function temp_expma(start, end){
	            var expma12 = this.options.expma.expma12.slice(start, end);
	            var expma50 = this.options.expma.expma50.slice(start, end);
	            var expma_arr = expma12.concat(expma50);
	            var expma_arr_length = expma_arr.length;
	
	            var max = _this.options.currentData.max;
	            var min = _this.options.currentData.min;
	            for(var i = 0,item;item = expma_arr[i];i++){
	                max = Math.max(max,item.value);
	                min = Math.min(min,item.value);
	            }
	            this.options.currentData.max = max;
	            this.options.currentData.min = min;
	            this.options.drawXY.options.currentData = this.options.currentData;
	
	            DrawEXPMA.apply(this,[this.options.context,expma12,expma50]);
	        }    
	
	    }
	
	
	    // 绘制bool指标
	    ChartK.prototype.drawBOLL = function(){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.up_t = "boll";
	
	        if(this.options.boll){
	
	            temp_boll.apply(_this,[_this.options.start, _this.options.end]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.boll = {};
	                _this.options.boll.bollup = data.bollup;
	                _this.options.boll.bollmb = data.bollmb;
	                _this.options.boll.bolldn = data.bolldn;
	
	                temp_boll.apply(_this,[_this.options.start, _this.options.end]);
	            });   
	        }
	
	
	        function temp_boll(start, end){
	            var bollup = this.options.boll.bollup.slice(start, end);
	            var bollmb = this.options.boll.bollmb.slice(start, end);
	            var bolldn = this.options.boll.bolldn.slice(start, end);
	
	            var boll = bollup.concat(bollmb).concat(bolldn);
	            var max = _this.options.currentData.max;
	            var min = _this.options.currentData.min;
	            for(var i = 0,item;item = boll[i];i++){
	                max = Math.max(max,item.value);
	                min = Math.min(min,item.value);
	            }
	            this.options.currentData.max = max;
	            this.options.currentData.min = min;
	            this.options.drawXY.options.currentData = this.options.currentData;
	
	            DrawBOLL.apply(_this,[_this.options.context,bollup,bollmb,bolldn]);
	        }
	
	    }
	
	
	    // 绘制bool指标
	    ChartK.prototype.drawSAR = function(){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.up_t = "sar";
	        var k_data_arr = this.options.currentData.data;
	
	        if(this.options.sar){
	            temp_sar.apply(_this,[_this.options.start, _this.options.end]);
	        }else{
	            GetTeacData(params,function(data){
	                _this.options.sar = {};
	                _this.options.sar.sar = data.sar;
	                temp_sar.apply(_this,[_this.options.start, _this.options.end]);
	            });     
	        }
	         
	        function temp_sar(start, end){
	            var sar_arr = this.options.sar.sar.slice(start, end);
	            var sar_arr_length = sar_arr.length;
	           
	            var max = _this.options.currentData.max;
	            var min = _this.options.currentData.min;
	            for(var i = 0,item;item = sar_arr[i];i++){
	                max = Math.max(max,item.value);
	                min = Math.min(min,item.value);
	            }
	            this.options.currentData.max = max;
	            this.options.currentData.min = min;
	            this.options.drawXY.options.currentData = this.options.currentData;
	
	            DrawSAR.apply(_this,[_this.options.context,sar_arr,k_data_arr]);
	        }  
	
	    }
	
	
	    // 绘制bbi指标
	    ChartK.prototype.drawBBI = function(){
	
	        var _this = this;
	        var params = {};
	        params = getParamsObj.call(this);
	        params.extend = this.options.up_t = "bbi";
	        if (this.options.bbi) {
	            temp_bbi.apply(_this,[]);
	        } else {
	            GetTeacData(params, function(data) {
	                _this.options.bbi = {};
	                _this.options.bbi.bbi = data.bbi;
	                temp_bbi.apply(_this,[]);
	            });
	        }
	
	        function temp_bbi(){
	
	            var data = _this.options.bbi;
	
	            var max = _this.options.currentData.max;
	            var min = _this.options.currentData.min;
	            for(var i = 0,item;item = bbi[i];i++){
	                max = Math.max(max,item.value);
	                min = Math.min(min,item.value);
	            }
	            this.options.currentData.max = max;
	            this.options.currentData.min = min;
	            this.options.drawXY.options.currentData = this.options.currentData;
	
	            var bbi_arr = data.bbi.slice(_this.options.start, _this.options.end);
	            DrawBBI.apply(_this, [_this.options.context,  bbi_arr]);
	        }
	
	    }
	
	
	
	    // 清除k线图区域
	    ChartK.prototype.clearK = function(){
	        var ctx = this.options.context;
	        ctx.fillStyle = "#fff";
	        // ctx.clearRect(0,this.options.unit_height * (-1),this.options.padding.left + this.options.drawWidth + 10,this.options.c2_y_top);
	        ctx.fillRect(0,this.options.unit_height * (-1),this.options.padding.left + this.options.drawWidth + 10,this.options.c2_y_top);
	    }
	
	    // 清除技术指标区域
	    ChartK.prototype.clearT = function(){
	        var ctx = this.options.context;
	        ctx.fillStyle = "#fff";
	        // ctx.clearRect(0,this.options.c3_y_top - 10,this.options.padding.left + this.options.drawWidth + 10,this.options.c4_y_top);
	        ctx.fillRect(0,this.options.c3_y_top - 10,this.options.padding.left + this.options.drawWidth + 10,this.options.c4_y_top);
	    }
	    // 放大图表
	    ChartK.prototype.scalePlus = function(){
	        scaleClick.call(this,true);
	    }
	    // 缩小图表
	    ChartK.prototype.scaleMinus = function(){
	        scaleClick.call(this,false);
	    }
	
	    // 复权
	    ChartK.prototype.beforeBackRight = function(flag){
	
	        if(flag === "" || flag === undefined){
	            this.options.authorityType = "";
	        }else if(flag){
	            this.options.authorityType = "fa";
	        }else{
	            this.options.authorityType = "ba";
	        }
	        this.clear();
	        this.draw();
	    }
	
	    // 缩放图表
	    function scaleClick(flag) {
	        
	        var _this = this;
	        var start = _this.options.start;
	        var end = _this.options.end;
	        var type = _this.options.type;
	        var data_arr_length = _this.options.data.data.length;
	        var scale_count = flag || _this.options.scale_count;
	
	
	        if(scale_count){    
	
	            if(start + 20 >= end){
	                start = end - 20;
	            }else{
	                start = start + 20;
	            }
	
	        }else{
	
	            if(start - 20 <= 0){
	                start = 0;
	            }else{
	                start = start - 20;
	            }
	        }
	
	        _this.options.start = start;
	        _this.options.end = end;
	
	
	        // 初始化交互
	        var inter = _this.options.interactive
	        // 显示loading效果
	        this.options.interactive.showLoading();
	
	        try{
	            // slideBarCallback.apply(this,[start,end]);
	            slideBar.apply(this,[slideBarCallback,start,end]);
	            inter.hideLoading();
	        }catch(e){
	            // 缩放按钮点击有效
	            _this.options.clickable = true;
	            // 暂无数据
	            // inter.showNoData();
	            // 隐藏loading效果
	            inter.hideLoading();
	        }
	        
	        
	    };
	
	    // 获取参数对象
	    function getParamsObj(){
	        var obj = {};
	        obj.code = this.options.code;
	        obj.type = this.options.type;
	        obj.authorityType = this.options.authorityType;
	        obj.extend = this.options.extend;
	        return obj;
	    }
	    // 回调函数
	    function dataCallback(data){
	
	        var ctx = this.options.context;
	        var canvas = ctx.canvas;
	        this.options.data = data == undefined ? this.options.data : data;
	        data = this.options.data;
	
	        var data_arr = data.data;
	        
	        var data_arr_length = data_arr.length;
	
	        if(data_arr_length >= 1){
	            if(data_arr_length > 60){
	                this.options.start = data_arr_length - 60;
	            }else{
	                this.options.start = 0;
	            }
	            this.options.end = data_arr_length;
	        }else{
	            this.options.start = 0;
	            this.options.end = 0;
	        }
	
	        this.options.currentData = sliceData(this.options.data,this.options.start,this.options.end);
	        var current_arr = this.options.currentData.data;
	        var current_arr_length = current_arr.length;
	        this.options.XMark = getXMARK.apply(this,[current_arr]);
	
	        // 图表交互
	        var inter = this.options.interactive;
	
	        // try{
	
	            if(!data || !data.data || data.data.length == 0){
	                // 隐藏loading效果
	                // inter.hideLoading();
	                // 暂无数据
	                // inter.showNoData();
	                // return;
	            }
	
	            // 保留的小数位
	            this.options.pricedigit = data.pricedigit;
	
	            // 获取单位绘制区域
	            var rect_unit = common.get_rect.apply(this,[canvas,current_arr_length]);
	            this.options.rect_unit = rect_unit;
	
	            slideBar.call(this,slideBarCallback);
	            // slideBar({container: this.container, percent: 1486, width: this.options.drawWidth, height: 70, top:this.options.c4_y_top, left: this.options.padding.left, barStart: 200, barWidth: 100});
	            
	            // 绘制坐标轴
	            var drawXY = this.options.drawXY = new DrawXY(this.options);
	            // drawXY.draw.apply(this,[]);
	            // 绘制K线图
	            this.drawK();
	            // 绘制均线
	            this.options.up_t = "junxian";
	            // 绘制均线和rsi指标
	            init_ma_rsi.apply(this,[]);
	            
	
	            // 绘制成交量
	            drawV.apply(this,[this.options]);
	            // 绘制成交量均线
	            this.drawVMA();
	            // 绘制技术指标
	            drawT.apply(this,[this.options]);
	
	            // 上榜日标识点
	            if(this.options.interactive.options.pointsContainer){
	                var points =  this.options.interactive.options.pointsContainer.children;
	                this.markPointsDom = points;
	            }
	
	            // 隐藏loading效果
	            inter.hideLoading();
	            
	            // 图表加载完成时间
	            this.options.onChartLoaded(this);
	
	        // }catch(e){
	        //     // 缩放按钮点击有效
	        //     _this.options.clickable = true;
	        //     // 暂无数据
	        //     inter.showNoData();
	        //     // 隐藏loading效果
	        //     inter.hideLoading();
	        // }
	       return true;
	    }
	
	    function getXMARK(arr){
	
	        var XMark = [];
	        var current_arr = arr || this.options.currentData.data;
	        var current_arr_length = current_arr.length;
	
	        if(current_arr_length > 0){
	            XMark.push(current_arr[0].date_time);
	            XMark.push(current_arr[Math.floor(current_arr_length * 1 / 4)].date_time);
	            XMark.push(current_arr[Math.floor(current_arr_length * 2 / 4)].date_time);
	            XMark.push(current_arr[Math.floor(current_arr_length * 3 / 4)].date_time);
	            XMark.push(current_arr[current_arr_length - 1].date_time);
	        }
	
	        return XMark;
	    }
	    // 绑定事件
	    function bindEvent(ctx){
	        var _this = this;
	        var timer_s,timer_m,timer_e;
	        var canvas = ctx.canvas;
	        var inter = _this.options.interactive;
	        //缩放按钮是否可点击
	        this.options.clickable = true;
	
	        var delayed = false;
	        var delaytouch = this.options.delaytouch = true;
	
	
	        // if(!delaytouch){
	            common.addEvent.call(_this, canvas, "mousemove",function(event){
	                dealEvent.apply(_this,[inter,event]);
	                try {
	                    event.preventDefault();
	                } catch (e) {
	                    event.returnValue = false;
	                }
	            });
	
	            common.addEvent.call(_this, _this.container, "mouseleave",function(event){
	                inter.hide();
	                try {
	                    event.preventDefault();
	                } catch (e) {
	                    event.returnValue = false;
	                }
	            });
	
	            common.addEvent.call(_this, canvas, "mouseenter",function(event){
	                inter.show();
	                try {
	                    event.preventDefault();
	                } catch (e) {
	                    event.returnValue = false;
	                }
	            });
	        // }
	        
	
	    }
	    // 图表交互
	    function dealEvent(inter,eventposition){
	
	        var canvas = this.options.canvas;   
	
	        var k_data = this.options.currentData.data;
	
	        var five_average = this.options.junxian.ma5;
	        var ten_average = this.options.junxian.ma10;
	        var twenty_average = this.options.junxian.ma20;
	        var thirty_average = this.options.junxian.ma30;
	
	        var v_ma_5 = this.options.v_ma_5;
	        var v_ma_10 = this.options.v_ma_10;
	
	        // 单位绘制区域
	        var rect_unit = this.options.rect_unit;
	        // 单位绘制区域的宽度
	        var rect_w = rect_unit.rect_w;
	        // K线柱体的宽度
	        // var bar_w = rect_unit.bar_w;
	
	        // 鼠标事件位置
	        // var w_x = eventposition.clientX;
	        // var w_y = eventposition.clientY;
	
	        var w_x = eventposition.offsetX || (eventposition.clientX - this.container.getBoundingClientRect().left);
	        var w_y = eventposition.offsetY || (eventposition.clientY - this.container.getBoundingClientRect().top);
	
	        // 鼠标在画布中的坐标
	        var c_pos = common.windowToCanvas.apply(this,[canvas,w_x,w_y]);
	        var c_x = (c_pos.x).toFixed(0);
	        // var c_y = (c_pos.y).toFixed(0);
	
	        // 当前K线在数组中的下标
	
	        var index = Math.floor((c_x - this.options.padding.left)/rect_w);
	        try {
	            if(k_data[index]){
	                // 显示行情数据
	                inter.showTip(canvas,w_x,k_data[index]);
	                
	                // 显示十字指示线的
	                var cross = common.canvasToWindow.apply(this,[canvas,k_data[index].cross_x,k_data[index].cross_y]);
	                var cross_w_x = cross.x;
	                var cross_w_y = cross.y;
	                inter.cross(canvas,cross_w_x,cross_w_y);
	            }
	
	            if(five_average[index]){
	                 // 标识均线数据
	                 // inter.markMA(canvas,five_average[index],ten_average[index],twenty_average[index],thirty_average[index]);
	                 inter.markMA(canvas, this.options.up_t, this.options[this.options.up_t], this.options.start, this.options.end, index);
	                 inter.markVMA(canvas,k_data[index].volume,v_ma_5[index],v_ma_10[index]);
	                 inter.markT(canvas, this.options.down_t, this.options[this.options.down_t], this.options.start, this.options.end, index);
	            }
	        } catch(e){
	            
	        }
	
	    }
	
	    //截取数据
	    function sliceData(sourceData, start, end){
	
	        var result = deepCopy(sourceData);
	        result.max = 0;
	        result.min = 100000;
	        result.v_max = 0;
	        result.total = end - start + 1;
	        result.name = sourceData.name;
	        result.code = sourceData.code;
	        result.v_ma_5 = sourceData.v_ma_5.slice(start,end);
	        result.v_ma_10 = sourceData.v_ma_10.slice(start,end);
	        result.data = [];
	
	        for(var i = start; i <= end; i++){
	            if(sourceData.data[i]){
	                result.data.push(sourceData.data[i]);
	                result.max = Math.max(sourceData.data[i].highest, result.max);
	                result.min = Math.min(sourceData.data[i].lowest, result.min);
	                result.v_max = Math.max(sourceData.data[i].volume, result.v_max);
	            }
	        }
	
	        result.max = result.max * 1.05;
	        result.min = result.min * 0.95; 
	
	        return result;
	    }
	
	    function deepCopy(source) { 
	        var result={};
	        for (var key in source) {
	          result[key] = typeof source[key]==="object"? deepCopy(source[key]): source[key];
	        } 
	        return result; 
	    }
	
	    return ChartK;
	})();
	
	module.exports = ChartK;


/***/ },
/* 47 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 绘制直角坐标系
	 */
	var extend = __webpack_require__(32);
	/*主题*/
	var theme = __webpack_require__(7);
	/*绘制网格虚线*/
	var DrawDashLine = __webpack_require__(40);
	// 工具
	var common = __webpack_require__(44); 
	var DrawXY = (function(){
	    //构造方法
	    function DrawXY(options){
	        /*设置默认参数*/
	        this.defaultoptions = theme.draw_xy;
	        this.options = extend(this.defaultoptions,options);
	        /*绘图*/
	        this.draw();
	    };
	    /*绘图*/
	    DrawXY.prototype.draw = function(){
	
	        this.drawXYK();
	        //绘制成交量坐标轴
	        this.drawXYV();
	        //绘制技术指标坐标轴
	        this.drawXYT();
	    };
	
	    //绘制技术指标坐标轴
	    DrawXY.prototype.drawXYT = function(){
	
	        var ctx = this.options.context;
	        var canvas = this.options.canvas;
	
	        // 保存画笔状态
	        ctx.save();
	        ctx.beginPath();
	        ctx.fillStyle = this.options.color.fillStyle;
	        ctx.strokeStyle = this.options.color.strokeStyle;
	        ctx.moveTo(this.options.padding.left,this.options.c3_y_top - this.options.unit_height);
	        ctx.lineTo(this.options.padding.left,this.options.c3_y_top + this.options.c_t_height);
	        this.options.context.rect(this.options.padding.left,this.options.c3_y_top - this.options.unit_height,this.options.drawWidth - 2,this.options.c_t_height + this.options.unit_height);
	        ctx.stroke();
	
	        var c3_y_top = this.options.c3_y_top;
	        ctx.fillStyle = this.options.color.fillStyle;
	        ctx.strokeStyle = this.options.color.strokeStyle;
	        // ctx.rect(this.options.padding.left,c2_y_top,ctx.canvas.width - this.options.padding.left - 2,v_height);
	        for(var i = 0;i<3;i++){
	            var x1 = this.options.padding.left;
	            var y1 = c3_y_top + ctx.canvas.height * 1 / this.options.y_sepe_num * i;
	            var x2 = this.options.padding.left + this.options.drawWidth;
	            var y2 = c3_y_top + ctx.canvas.height * 1 / this.options.y_sepe_num * i;
	
	            if(i == 0 || i == 2){
	                ctx.moveTo(x1,y1);
	                ctx.lineTo(x2,y2);
	            }else{
	                DrawDashLine(ctx,x1, y1, x2, y2,5);
	            }
	        }
	        ctx.stroke();
	        ctx.beginPath();
	        // 恢复画笔状态
	        ctx.restore();
	
	    }
	
	    // 绘制成交量坐标轴
	    DrawXY.prototype.drawXYV = function(){
	
	        var ctx = this.options.context;
	        var canvas = this.options.canvas;
	        var data = this.options.currentData || this.options.data;
	
	        // 保存画笔状态
	        ctx.save();
	        ctx.beginPath();
	        this.options.context.rect(this.options.padding.left,this.options.c2_y_top - this.options.unit_height,this.options.drawWidth - 2,this.options.c_v_height + this.options.unit_height);
	        ctx.stroke();
	
	        var c2_y_top = this.options.c2_y_top;
	        ctx.fillStyle = this.options.color.fillStyle;
	        ctx.strokeStyle = this.options.color.strokeStyle;
	        // ctx.rect(this.options.padding.left,c2_y_top,ctx.canvas.width - this.options.padding.left - 2,v_height);
	        for(var i = 0;i<4;i++){
	            var x1 = this.options.padding.left;
	            var y1 = c2_y_top + ctx.canvas.height * 1 / this.options.y_sepe_num * i;
	            var x2 = ctx.canvas.width - this.options.padding.right;
	            var y2 = c2_y_top + ctx.canvas.height * 1 / this.options.y_sepe_num * i;
	
	            if(i == 0 || i == 3){
	                ctx.moveTo(x1,y1);
	                ctx.lineTo(x2,y2);
	            }else{
	                DrawDashLine(ctx,x1, y1, x2, y2,5);
	            }
	        }
	
	        var v_max = common.format_unit(data.v_max/1);
	        ctx.fillStyle = this.options.color.fillStyle;
	        ctx.strokeStyle = this.options.color.strokeStyle;
	        ctx.fillText(common.format_unit(data.v_max/1,2),  0, this.options.c2_y_top + 10);
	        ctx.fillText(common.format_unit(data.v_max/1 * 2/3,2),  0, this.options.c2_y_top + 10 + this.options.v_base_height * 1/3);
	        ctx.fillText(common.format_unit(data.v_max/1 * 1/3,2),  0, this.options.c2_y_top + 10 + this.options.v_base_height * 2/3);
	        ctx.fillText(0,  this.options.padding.left - 20, this.options.c2_y_top + 10 + this.options.v_base_height * 3/3);
	        ctx.stroke();
	        ctx.beginPath();
	        // 恢复画笔状态
	        ctx.restore();
	    }
	
	    //绘制K线图坐标轴
	    DrawXY.prototype.drawXYK = function(){
	        var ctx = this.options.context;
	        var canvas = this.options.canvas;
	        var data = this.options.currentData || this.options.data;
	        var type = this.options.type;
	
	        /*Y轴上的最大值*/
	        var y_max = data.max;
	        /*Y轴上的最小值*/
	        var y_min = data.min;
	
	        /*Y轴上分隔线数量*/
	        var sepe_num = 9;
	
	        /*K线图的高度*/
	        var k_height = this.options.c_k_height;
	        /*Y轴标识线列表*/
	        var line_list_array = getLineList(y_max/1, y_min/1, sepe_num, k_height);
	
	        // 保存画笔状态
	        ctx.save();
	        
	        var sepe_num = line_list_array.length;
	        ctx.fillStyle = this.options.color.fillStyle;
	        ctx.strokeStyle = this.options.color.strokeStyle;
	        for (var i = 0,item; item = line_list_array[i]; i++) {
	            
	            if(i == 0 || i == line_list_array.length - 1){
	                ctx.moveTo(this.options.padding.left, Math.round(item.y));
	                ctx.lineTo(ctx.canvas.width - this.options.padding.right, Math.round(item.y));
	                ctx.stroke();
	            }else{
	                DrawDashLine(ctx,this.options.padding.left, Math.round(item.y),ctx.canvas.width - this.options.padding.right, Math.round(item.y),5);
	            }
	            // 绘制纵坐标刻度
	            ctx.moveTo(0, item.y + 5);
	            ctx.fillText((item.num/1).toFixed(this.options.pricedigit), 0, item.y + 5);
	        }
	
	        /*K线图的高度*/
	        var k_height = this.options.c_k_height;
	        // 绘制横坐标刻度
	        drawXMark.apply(this,[ctx,k_height]);
	
	        // 恢复画笔状态
	        ctx.restore();
	    }
	   
	    /*绘制横坐标刻度值*/
	    function drawXMark(ctx,k_height){
	        // var dpr = this.options.dpr;
	        var padding_left = this.options.padding_left;
	        ctx.beginPath();
	        
	        /*画布宽度*/
	        var k_width = this.options.drawWidth;
	        
	        var unit_w = (k_width) / (this.options.x_sepe_num);
	        var XMark = this.options.XMark;
	
	        // 保存画笔状态
	        ctx.save();
	        ctx.beginPath();
	        for(var i = 0;i <= this.options.x_sepe_num;i++){
	
	            var x1 = this.options.padding.left + i * unit_w;
	            var y1 = 0;
	            var x2 = this.options.padding.left + i * unit_w;
	            var y2 = k_height;
	
	            if(i == 0){
	                ctx.moveTo(x1, y1);
	                ctx.lineTo(x2, y2);
	                ctx.stroke();
	            }else if(i == this.options.x_sepe_num){
	                ctx.moveTo(x1 - 1, y1);
	                ctx.lineTo(x2 - 1, y2);
	                ctx.stroke();
	            }else{
	                DrawDashLine(ctx, x1, y1, x2, y2, 5);
	            }
	            
	        }
	
	        var XMark_length = XMark.length;
	        for(var j = 0;j < XMark_length;j++){
	            if(j == 0){
	                ctx.fillText(XMark[j],  j / 4 * this.options.drawWidth + this.options.padding.left, this.options.c_k_height + this.options.unit_height/2 + 5);
	            }else if(j == XMark_length - 1){
	                ctx.fillText(XMark[j],  j / 4 * this.options.drawWidth + this.options.padding.left - ctx.measureText(XMark[j]).width, this.options.c_k_height + this.options.unit_height/2 + 5);
	            }else{
	                ctx.fillText(XMark[j],  j / 4 * this.options.drawWidth + this.options.padding.left - ctx.measureText(XMark[j]).width/2, this.options.c_k_height + this.options.unit_height/2 + 5);
	            }
	
	        }
	
	        // 恢复画笔状态
	        ctx.restore();
	    }
	    /*Y轴标识线列表*/
	    function getLineList(y_max, y_min, sepe_num, k_height) {
	        var ratio = (y_max - y_min) / (sepe_num-1);
	        var result = [];
	        for (var i = 0; i < sepe_num; i++) {
	            result.push({
	                num:  (y_min + i * ratio),
	                x: 0,
	                y: k_height - (i / (sepe_num-1)) * k_height
	            });
	
	        }
	        return result;
	    }
	    return DrawXY;
	})();
	
	module.exports = DrawXY;

/***/ },
/* 48 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * web端 k线图数据获取
	 *
	 * 返回的数据: result = {
	 *			     			name: 名字,
	 *			        		code: 编码,
	 *			          		total: 总共的数据个数,
	 *			          		extend(为 均线， sar等参数线): [{date:2012-11-22, value: 1000}, ....]
	 *			          		data:[	
	 *			          			{date_time(日期交易), 
	 *			          			height(当天最高价), 
	 *			          			low(最低价), 
	 *			          			open(开盘价), 
	 *			          			close(收盘价), 
	 *			          			volume(当日成交量), 
	 *			          			up(涨跌), 
	 *			          			percent(涨跌百分比),
	 *			          			(根据传入的extend参数不同会返回（ma, bbi, sar, expmas, bolls等数据）)
	 *			          			},
	 *			          			.....
	 *			          			{}
	 *			          		]
	 * 						}
	 */
	
	var jsonp = __webpack_require__(12);
	var dealData = __webpack_require__(49);
	
	/**
	 * 根据传入的options获取相应的k线数据
	 * @param 	obj   options  {
	 *                        		code : 股票id
	 *                        		type： 数据类型：K（日K）,WK（周K）,MK（月K），T2（两天分时），
	 *                        				T3（三天分时），T4（四天分时），T5（五天分时），m5k（历史五分钟），
	 *                        		 		m15k（历史十五分钟），m30k（历史三十分钟），m60k（历史六十分钟）
	 *                        		percent：返回数据的长度（[0,1]）,
	 *                        		extend: MA, EXPMA, SAR, BOLL, BBI 
	 *                        	}
	 * @param  {Function} callback 返回得到的数据
	 */
	function getData(options, callback){
		var url = "http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js";
		var callbackStr = "fsData" + (new Date()).getTime().toString();
		if(options.type.toLowerCase() == "dk"){
			options.type = 'k';
		}
		var urlData = {
			id: options.code,
	        TYPE: options.type,
	        js: callbackStr + '((x))',
	        'rtntype': 5,
	        'extend' : options.extend || "MA",
	        isCR:false
		};/*debugger;*/
		if(options.authorityType !== ""){
			urlData.authorityType = options.authorityType;
		}
		jsonp(url, urlData, callbackStr, function(json){
			var result = dealData(json, urlData.extend);
			callback(result);
		});
	}
	
	module.exports = getData;

/***/ },
/* 49 */
/***/ function(module, exports) {

	/**
	 * web的k线图的数据处理
	 * json为根据id和type获得的k线数据
	 */
	
	function dealData(json,  extendType) {
	
	    var result = {};
	    result.data = [];
	    result.max = 0;
	    result.min = json.info.yc;
	    result.v_max = 0;
	    result.total = json.info.total;
	    result.name = json.name;
	    result.code = json.code;
	    result.pricedigit = (json.info.pricedigit).split('.')[1].length;
	
	    var datas = json.data;
	    //如果percent没定义，默认显示60个数据（需要改进）
	    var askLength = json.data.length;
	    for (var i = askLength-1; i >= 0; i--) {
	        //分割data中的字符串
	        var items = datas[result.total - i - 1].split(/\[|\]/);
	        var itemBase = datas[result.total - i - 1].split(/\[|\]/)[0].split(",");
	
	        //得到每个时间点的数据
	        var rect = {};
	        rect.date_time = itemBase[0];
	        rect.highest = itemBase[3];
	        rect.lowest = itemBase[4];
	        rect.open = itemBase[1];
	        rect.close = itemBase[2];
	        rect.volume = itemBase[5];
	        rect.percent = (Math.abs(rect.close * 1.0 - rect.open * 1.0) / rect.open * 1.0).toFixed(2);
	        rect.priceChange = Math.abs(rect.close * 1.0 - rect.open * 1.0).toFixed(2);
	        rect.up = (rect.close * 1.0 - rect.open * 1.0) > 0 ? true : false;
	        var volume_5 = avgDays(datas, result.total - i - 1, 5);
	        var volume_10 = avgDays(datas, result.total - i - 1, 10);
	        
	        intoArr.call(result, "v_ma_5", volume_5, rect.date_time);
	        intoArr.call(result, "v_ma_10", volume_10, rect.date_time);
	        result.data.push(rect);
	        //获取时间段内的价格最大最小值和成交量的最大值
	        result.max = getMax([result.max, rect.lowest, rect.highest*1.0, items[1].split(",")[0], items[1].split(",")[1], items[1].split(",")[2], items[1].split(",")[3]]); 
	        result.min = getMin([result.min, rect.lowest, rect.highest, items[1].split(",")[0], items[1].split(",")[1], items[1].split(",")[2], items[1].split(",")[3]]);
	        result.v_max = result.v_max > rect.volume * 1.0 ? result.v_max : rect.volume;
	    }
	    return result;
	}
	
	function testData(data) {
	    return data === "-" ? null : data;
	}
	//创建一个数组，并且push值
	function intoArr(name, value, date) {
	    if (value === "-") {
	        value = null;
	    }
	    if (this[name] === undefined) {
	        this[name] = [{ value: value, date: date }];
	    } else {
	        this[name].push({ value: value, date: date });
	    }
	}
	//计算前n天的平均成交量
	function avgDays(datas, i, n) {
	    var result = 0;
	    var len = datas.length;
	    if(i < n){
	        return "-";
	    }else{
	    	for(var j = 0; j < n; j++){
	    		result += datas[i-j].split(",")[5]*1.0;
	    	}
	        result = result/n;
	        return result.toFixed(2) ;
	    }
	    
	}
	//数组冒泡得到最大值
	function getMax(arr){
	    var max = 0;
	    for(var i = 0; i < arr.length; i++){
	        max = max > arr[i]*1.0 ? max : arr[i]*1.0;
	    }
	    return max;
	}
	//数组冒泡得到最小值
	function getMin(arr){
	    var min = 100000;
	    for(var i = 0; i < arr.length; i++){
	        min = min < arr[i]*1.0 ? min : arr[i]*1.0;
	    }
	    return min;
	}
	
	module.exports = dealData;


/***/ },
/* 50 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * web 端技术指标图数据
	 * 获取的技术指标参数需要根据请求K线的格式来
	 */
	var dealData = __webpack_require__(51);
	var jsonp = __webpack_require__(12);
	
	function getData(options, callback){
	
		var url = "http://pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js";
		var callbackStr = "fsDataTeac"+ options.extend.substring(0, 2) + (new Date()).getTime().toString();
		var urlData = {
			id: options.code,
	        TYPE: options.type || "k",
	        js: callbackStr + '((x))',
	        'rtntype': 5,
	        'extend' : options.extend || "RSI|MA",
	        isCR :false,
	        check:"kte"
		};
		// if(options.authorityType != ""){
		// 	urlData.authorityType = options.authorityType;
		// }
		jsonp(url, urlData, callbackStr, function(json){
			var result = dealData(json, urlData.extend);
	
			callback(result);
		});
	}
	
	module.exports = getData;

/***/ },
/* 51 */
/***/ function(module, exports) {

	/**
	 * web端技术指标图相关数据的处理
	 * 返回各个指标对应的数据
	 */
	
	function dealData(json,  extendStr) {
	
	    var result = {};
	    result.name = json.name;
	    result.code = json.code;
	    result.pricedigit = (json.info.pricedigit).split('.')[1].length;
	
	    var datas = json.data;
	    var askLength =  json.info.total ;
	    for (var i = askLength - 1; i >= 0; i--) {
	        //分割data中的字符串
	        var strGroup = datas[json.info.total - i - 1].split(/\[|\]/);
	        var itemBase = [];
	        for(var k = 0; k < strGroup.length; k++){
	            if(strGroup[k] !== ","){
	                itemBase.push(strGroup[k]);
	            }
	        }
	        //获得的日期
	        var date = datas[json.info.total - i - 1].split(/\[|\]/)[0].split(",")[0];
	        //技术指标的名字
	        var Tname = extendStr.split('|');
	
	        for (var j = 0; j < Tname.length; j++) {
	            var item = itemBase[j+1].split(",");
	            switch (Tname[j].toLowerCase()) {
	                //K线的技术指标
	                case "bbi":
	                    intoArr.call(result, "bbi", item[0], date);
	                    break;
	                case "expma":
	                    intoArr.call(result, "expma12", item[0], date);
	                    intoArr.call(result, "expma50", item[1], date);
	                case "sar":
	                    intoArr.call(result, "sar", item[0], date);
	                    break;
	                case "boll":
	                    intoArr.call(result, "bollmb", item[0], date);
	                    intoArr.call(result, "bollup", item[1], date);
	                    intoArr.call(result, "bolldn", item[2], date);
	                    break;
	                case "ma":
	                    intoArr.call(result, "five_average", item[0], date);
	                    intoArr.call(result, "ten_average", item[1], date);
	                    intoArr.call(result, "twenty_average", item[2], date);
	                    intoArr.call(result, "thirty_average", item[3], date);
	                    break;
	                    //单独的技术指标
	                case "rsi":
	                    intoArr.call(result, "rsi6", item[0], date);
	                    intoArr.call(result, "rsi12", item[1], date);
	                    intoArr.call(result, "rsi24", item[2], date);
	                    break;
	                case "kdj":
	                    intoArr.call(result, "k", item[0], date);
	                    intoArr.call(result, "d", item[1], date);
	                    intoArr.call(result, "j", item[2], date);
	                    break;
	                case "macd":
	                    intoArr.call(result, "diff", item[0], date);
	                    intoArr.call(result, "dea", item[1], date);
	                    intoArr.call(result, "macd", item[2], date);
	                    break;
	                case "wr":
	                    intoArr.call(result, "wr10", item[0], date);
	                    intoArr.call(result, "wr6", item[1], date);
	                    break;
	                case "dmi":
	                    intoArr.call(result, "pdi", item[0], date);
	                    intoArr.call(result, "mdi", item[1], date);
	                    intoArr.call(result, "adx", item[2], date);
	                    intoArr.call(result, "adxr", item[3], date);
	                    break;
	                case "bias":
	                    intoArr.call(result, "bias6", item[0], date);
	                    intoArr.call(result, "bias12", item[1], date);
	                    intoArr.call(result, "bias24", item[2], date);
	                    break;
	                case "obv":
	                    /*数据不对*/
	                    intoArr.call(result, "obv", item[0], date);
	                    intoArr.call(result, "maobv", item[1], date);
	                    break;
	                case "cci":
	                    intoArr.call(result, "cci", item[0], date);
	                    break;
	                case "roc":
	                    intoArr.call(result, "roc", item[0], date);
	                    intoArr.call(result, "rocma", item[1], date);
	                    break;
	                default:
	                    break;
	            }
	        }
	
	    }
	    return result;
	}
	
	function intoArr(name, value, date) {
	    if (value === "-") {
	        value = null;
	    }
	    if (this[name] === undefined) {
	        this[name] = [{ value: value, date: date }];
	    } else {
	        this[name].push({ value: value, date: date });
	    }
	}
	module.exports = dealData;


/***/ },
/* 52 */
/***/ function(module, exports) {

	function drawK(params){
		// 保存画笔状态
		var ctx = params.ctx;
	    ctx.save();
		ctx.beginPath();
		ctx.lineWidth = 1;
	
		var x = params.x;
	 	var y_open = params.y_open;
	 	var y_close = params.y_close;
	 	var y_highest = params.y_highest;
	 	var y_lowest = params.y_lowest;
	 	var bar_w = params.bar_w;
	
	 	ctx.moveTo(x,y_lowest);
	 	ctx.lineTo(x,y_highest);
	 	ctx.stroke();
	
	 	ctx.beginPath();
	
	 	if(y_close >= y_open){
	 		ctx.rect(params.x - bar_w/2,y_open,bar_w,y_close - y_open);
	 	}else{
	 		ctx.rect(params.x - bar_w/2,y_close,bar_w,y_open - y_close);
	 	}
	
	 	ctx.stroke();
	 	ctx.fill();
	
	 	// 恢复画笔状态
		ctx.restore();
	 }
	 
	 module.exports = drawK;

/***/ },
/* 53 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawRSI(ctx,rsi6,rsi12,rsi24){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	    
	
	    var rsi_arr = rsi6.concat(rsi12).concat(rsi24);
	    var rsi_arr_length = rsi_arr.length;
	    if(rsi_arr && rsi_arr[0]){
	        var max = rsi_arr[0].value;
	        var min = rsi_arr[0].value;
	    }
	
	    for(var i = 0;i < rsi_arr_length;i++){
	        max = Math.max(max,rsi_arr[i].value);
	        min = Math.min(min,rsi_arr[i].value);
	    }
	
	    var base = max - min;
	    var c_t_height = this.options.c_t_height;
	
	    var rsi6_length = rsi6.length;
	    var rsi12_length = rsi12.length;
	    var rsi24_length = rsi24.length;
	
	    var unit_w = this.options.drawWidth/rsi6_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    for(var i = 0;i < rsi6_length;i++){
	
	        var y = (c_t_height - (rsi6[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    for(var i = 0;i < rsi12_length;i++){
	
	        var y = (c_t_height - (rsi12[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#fe59fe";
	    for(var i = 0;i < rsi24_length;i++){
	
	        var y = (c_t_height - (rsi24[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawRSI;

/***/ },
/* 54 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawRSI(ctx,k,d,j){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	
	    var kdj_arr = k.concat(d).concat(j);
	    var kdj_arr_length = kdj_arr.length;
	    if(kdj_arr && kdj_arr[0]){
	        var max = kdj_arr[0].value;
	        var min = kdj_arr[0].value;
	    }
	
	    for(var i = 0;i < kdj_arr_length;i++){
	        max = Math.max(max,kdj_arr[i].value);
	        min = Math.min(min,kdj_arr[i].value);
	    }
	
	    var base = max - min;
	    var c_t_height = this.options.c_t_height;
	
	    var k_length = k.length;
	    var d_length = d.length;
	    var j_length = j.length;
	
	    var unit_w = this.options.drawWidth/k_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    for(var i = 0;i < k_length;i++){
	
	        var y = (c_t_height - (k[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    for(var i = 0;i < d_length;i++){
	
	        var y = (c_t_height - (d[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#fe59fe";
	    for(var i = 0;i < j_length;i++){
	
	        var y = (c_t_height - (j[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawRSI;

/***/ },
/* 55 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawWR(ctx,wr6,wr10){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	
	    var wr_arr = wr6.concat(wr10);
	    var wr_arr_length = wr_arr.length;
	    if(wr_arr && wr_arr[0]){
	        var max = wr_arr[0].value;
	        var min = wr_arr[0].value;
	    }
	
	    for(var i = 0;i < wr_arr_length;i++){
	        max = Math.max(max,wr_arr[i].value);
	        min = Math.min(min,wr_arr[i].value);
	    }
	
	    var base = max - min;
	    var c_t_height = this.options.c_t_height;
	
	    var wr6_length = wr6.length;
	    var wr10_length = wr10.length;
	
	    var unit_w = this.options.drawWidth/wr6_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    for(var i = 0;i < wr6_length;i++){
	
	        var y = (c_t_height - (wr6[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    for(var i = 0;i < wr10_length;i++){
	
	        var y = (c_t_height - (wr10[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawWR;

/***/ },
/* 56 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawDMI(ctx,pdi,mdi,adx,adxr){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	
	    var dmi_arr = pdi.concat(mdi).concat(adx).concat(adxr);
	    var dmi_arr_length = dmi_arr.length;
	    if(dmi_arr && dmi_arr[0]){
	        var max = dmi_arr[0].value;
	        var min = dmi_arr[0].value;
	    }
	
	    for(var i = 0;i < dmi_arr_length;i++){
	        max = Math.max(max,dmi_arr[i].value);
	        min = Math.min(min,dmi_arr[i].value);
	    }
	
	    var base = max - min;
	    var c_t_height = this.options.c_t_height;
	
	    var pdi_length = pdi.length;
	    var mdi_length = mdi.length;
	    var adx_length = adx.length;
	    var adxr_length = adxr.length;
	
	    var unit_w = this.options.drawWidth/pdi_length;
	    ctx.beginPath();
	
	
	    ctx.strokeStyle = "#488ee6";
	    for(var i = 0;i < pdi_length;i++){
	
	        var y = (c_t_height - (pdi[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	
	    ctx.strokeStyle = "#f4cb15";
	    for(var i = 0;i < mdi_length;i++){
	
	        var y = (c_t_height - (mdi[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#fe59fe";
	    for(var i = 0;i < adx_length;i++){
	
	        var y = (c_t_height - (adx[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#ff5b10";
	    for(var i = 0;i < adxr_length;i++){
	
	        var y = (c_t_height - (adxr[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0 || y < this.options.c3_y_top || y > this.options.c3_y_top + 2 * this.options.unit_htight){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	   var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawDMI;

/***/ },
/* 57 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawRSI(ctx,bias6,bias12,bias24){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	
	    var bias_arr = bias6.concat(bias12).concat(bias24);
	    var bias_arr_length = bias_arr.length;
	    if(bias_arr && bias_arr[0]){
	        var max = bias_arr[0].value;
	        var min = bias_arr[0].value;
	    }
	
	    for(var i = 0;i < bias_arr_length;i++){
	        max = Math.max(max,bias_arr[i].value);
	        min = Math.min(min,bias_arr[i].value);
	    }
	
	    var base = max - min;
	    var c_t_height = this.options.c_t_height;
	
	    var bias6_length = bias6.length;
	    var bias12_length = bias12.length;
	    var bias24_length = bias24.length;
	
	    var unit_w = this.options.drawWidth/bias6_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    for(var i = 0;i < bias6_length;i++){
	
	        var y = (c_t_height - (bias6[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    for(var i = 0;i < bias12_length;i++){
	
	        var y = (c_t_height - (bias12[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#fe59fe";
	    for(var i = 0;i < bias24_length;i++){
	
	        var y = (c_t_height - (bias24[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawRSI;

/***/ },
/* 58 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawOBV(ctx,obv,maobv){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	
	    var obv_arr = obv.concat(maobv);
	    var obv_arr_length = obv_arr.length;
	    if(obv_arr && obv_arr[0]){
	        var max = obv_arr[0].value;
	        var min = obv_arr[0].value;
	    }
	
	    for(var i = 0;i < obv_arr_length;i++){
	        max = Math.max(max,obv_arr[i].value);
	        min = Math.min(min,obv_arr[i].value);
	    }
	
	    var base = max - min;
	    var c_t_height = this.options.c_t_height;
	
	    var obv_length = obv.length;
	    var maobv_length = maobv.length;
	
	    var unit_w = this.options.drawWidth/obv_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    for(var i = 0;i < obv_length;i++){
	
	        var y = (c_t_height - (obv[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    for(var i = 0;i < maobv_length;i++){
	
	        var y = (c_t_height - (maobv[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	 var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawOBV;

/***/ },
/* 59 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawOBV(ctx,cci){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	
	    var cci_arr = cci;
	    var cci_arr_length = cci.length;
	    if(cci_arr && cci_arr[0]){
	        var max = cci_arr[0].value;
	        var min = cci_arr[0].value;
	    }
	
	    for(var i = 0;i < cci_arr_length;i++){
	        max = Math.max(max,cci_arr[i].value);
	        min = Math.min(min,cci_arr[i].value);
	    }
	
	    var base = max - min;
	    var c_t_height = this.options.c_t_height;
	
	    var cci_length = cci.length;
	
	    var unit_w = this.options.drawWidth/cci_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    for(var i = 0;i < cci_length;i++){
	
	        var y = (c_t_height - (cci[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawOBV;

/***/ },
/* 60 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawOBV(ctx,roc,rocma){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	
	    var roc_arr = roc.concat(rocma);
	    var roc_arr_length = roc_arr.length;
	    if(roc_arr && roc_arr[0]){
	        var max = roc_arr[0].value;
	        var min = roc_arr[0].value;
	    }
	
	    for(var i = 0;i < roc_arr_length;i++){
	        max = Math.max(max,roc_arr[i].value);
	        min = Math.min(min,roc_arr[i].value);
	    }
	
	    var base = max - min;
	    var c_t_height = this.options.c_t_height;
	
	    var roc_length = roc.length;
	    var rocma_length = rocma.length;
	
	    var unit_w = this.options.drawWidth/roc_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    for(var i = 0;i < roc_length;i++){
	
	        var y = (c_t_height - (roc[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    for(var i = 0;i < rocma_length;i++){
	
	        var y = (c_t_height - (rocma[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    ctx.beginPath();
	    // 恢复画笔状态
	    ctx.restore();
	}
	
	module.exports = drawOBV;

/***/ },
/* 61 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawEXPMA(ctx,expma12,expma50){
	    // 保存画笔状态
	    ctx.save();
	    this.clearK();
	    this.options.drawXY.drawXYK();
	    this.drawK();
	    var c_t_height = this.options.c_t_height;
	
	    var expma12_length = expma12.length;
	    var expma50_length = expma50.length;
	
	    var unit_w = this.options.drawWidth/expma12_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    var flag = false;
	    for(var i = 0;i < expma12_length;i++){
	
	        var x = this.options.padding.left + i * unit_w + unit_w/2;
	        var y = common.get_y.call(this,expma12[i].value);
	
	        // var y = (c_t_height - (expma12[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        // var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0 || y < 0 || y > this.options.c_k_height){
	            ctx.moveTo(x,y);
	            flag = true;
	        }else{
	            if(flag){
	                ctx.moveTo(x,y);
	                flag = false;
	            }else{
	                ctx.lineTo(x,y);
	            }
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    flag = false;
	    for(var i = 0;i < expma50_length;i++){
	
	        var x = this.options.padding.left + i * unit_w + unit_w/2;
	        var y = common.get_y.call(this,expma50[i].value);
	        
	        if(i == 0 || y < 0 || y > this.options.c_k_height){
	            ctx.moveTo(x,y);
	            flag = true;
	        }else{
	            if(flag){
	                ctx.moveTo(x,y);
	                flag = false;
	            }else{
	                ctx.lineTo(x,y);
	            }
	            // ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawEXPMA;

/***/ },
/* 62 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawSAR(ctx,sar,k_data_arr){
	    // 保存画笔状态
	    ctx.save();
	    this.clearK();
	    this.options.drawXY.drawXYK();
	    this.drawK();
	
	    var c_t_height = this.options.c_t_height;
	    var sar_length = sar.length;
	
	    var unit_w = this.options.drawWidth/sar_length;
	    var up_color = this.options.up_color;
	    var down_color = this.options.down_color
	    
	    for(var i = 0;i < sar_length;i++){
	        ctx.beginPath();
	        var is_up = k_data_arr[i].up;
	        if(is_up){
	            ctx.fillStyle = up_color;
	            ctx.strokeStyle = up_color;
	        }else{
	            ctx.fillStyle = down_color;
	            ctx.strokeStyle = down_color;
	        }
	        
	        var x = this.options.padding.left + i * unit_w + unit_w/2;
	        var y = common.get_y.call(this,sar[i].value);
	
	        if(y <= this.options.c_k_height && y >= 0){
	            ctx.moveTo(x,y);
	            ctx.arc(x,y,3,0,Math.PI*2,true);
	            ctx.fill();
	            ctx.stroke();
	        }
	
	        
	        // if(i == 0){
	        //     ctx.moveTo(x,y);
	        // }else{
	        //     ctx.lineTo(x,y);
	        // }
	
	    }
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawSAR;

/***/ },
/* 63 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawBOLL(ctx,bollup,bollmb,bolldn){
	    // 保存画笔状态
	    ctx.save();
	    this.clearK();
	    this.options.drawXY.drawXYK();
	    this.drawK();
	    var c_t_height = this.options.c_t_height;
	
	    var bollup_length = bollup.length;
	    var bollmb_length = bollmb.length;
	    var bolldn_length = bolldn.length;
	
	    var unit_w = this.options.drawWidth/bollup_length;
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    var flag = false;
	    for(var i = 0;i < bollup_length;i++){
	
	        var x = this.options.padding.left + i * unit_w + unit_w/2;
	        var y = common.get_y.call(this,bollup[i].value);
	
	        if(i == 0 || y < 0 || y > this.options.c_k_height){
	            ctx.moveTo(x,y);
	            flag = true;
	        }else{
	            if(flag){
	                ctx.moveTo(x,y);
	                flag = false;
	            }else{
	                ctx.lineTo(x,y);
	            }
	            
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    flag = false;
	    for(var i = 0;i < bollmb_length;i++){
	
	        var x = this.options.padding.left + i * unit_w + unit_w/2;
	        var y = common.get_y.call(this,bollmb[i].value);
	
	        if(i == 0 || y < 0 || y > this.options.c_k_height){
	            ctx.moveTo(x,y);
	            flag = true;
	        }else{
	            if(flag){
	                ctx.moveTo(x,y);
	                flag = false;
	            }else{
	                ctx.lineTo(x,y);
	            }
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#fe59fe";
	    flag = false;
	    for(var i = 0;i < bolldn_length;i++){
	
	        var x = this.options.padding.left + i * unit_w + unit_w/2;
	        var y = common.get_y.call(this,bolldn[i].value);
	
	        if(i == 0 || y < 0 || y > this.options.c_k_height){
	            ctx.moveTo(x,y);
	            flag = true;
	        }else{
	            if(flag){
	                ctx.moveTo(x,y);
	                flag = false;
	            }else{
	                ctx.lineTo(x,y);
	            }
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	
	    ctx.restore();
	}
	
	module.exports = drawBOLL;

/***/ },
/* 64 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawEXPMA(ctx,bbi){
	    // 保存画笔状态
	    ctx.save();
	    this.clearK();
	    this.options.drawXY.drawXYK();
	    this.drawK();
	    var c_t_height = this.options.c_t_height;
	
	    var bbi_length = bbi.length;
	
	    var unit_w = this.options.drawWidth/bbi_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#488ee6";
	    var flag = false;
	    for(var i = 0;i < bbi_length;i++){
	
	        var x = this.options.padding.left + i * unit_w + unit_w/2;
	        var y = common.get_y.call(this,bbi[i].value);
	
	        // var y = (c_t_height - (expma12[i].value - min)/base *  c_t_height) + this.options.c3_y_top
	        // var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0 || y > this.options.c_k_height || y < 0){
	            ctx.moveTo(x,y);
	            flag = true;
	        }else{
	            if(flag){
	                ctx.moveTo(x,y);
	                flag = false;
	            }else{
	                ctx.lineTo(x,y);
	            }
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	
	    ctx.restore();
	}
	
	module.exports = drawEXPMA;

/***/ },
/* 65 */
/***/ function(module, exports, __webpack_require__) {

	// 工具
	var common = __webpack_require__(44); 
	function drawMACD(ctx,dea,diff,macd){
	    this.clearT();
	    this.options.drawXY.drawXYT();
	    // 保存画笔状态
	    ctx.save();
	
	    var macd_arr = dea.concat(diff).concat(macd);
	    var macd_arr_length = macd_arr.length;
	    if(macd_arr && macd_arr[0]){
	        var max = macd_arr[0].value;
	        var min = macd_arr[0].value;
	    }
	
	    for(var i = 0;i < macd_arr_length;i++){
	        max = Math.max(max,macd_arr[i].value);
	        min = Math.min(min,macd_arr[i].value);
	    }
	
	    var base = (max - min)/2;
	    var middle = (max + min)/2
	    var middle_y =  this.options.c3_y_top + this.options.c_t_height/2;
	
	    var c_t_height = this.options.c_t_height;
	
	    var dea_length = dea.length;
	    var diff_length = diff.length;
	    var macd_length = macd.length;
	
	    var unit_w = this.options.drawWidth/dea_length;
	    ctx.beginPath();
	    ctx.strokeStyle = "#f4cb15";
	    for(var i = 0;i < dea_length;i++){
	
	        if(dea[i].value >= 0){
	            var y = (c_t_height/2 - (dea[i].value - middle)/base *  c_t_height/2) + this.options.c3_y_top
	        }else{
	            var y = (middle - dea[i].value)/base *  c_t_height/2 + this.options.c3_y_top + c_t_height/2;
	        }
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0 || y > (this.options.c3_y_top + this.options.c_t_height) || y < this.options.c3_y_top){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    ctx.beginPath();
	    ctx.strokeStyle = "#fe59fe";
	    for(var i = 0;i < diff_length;i++){
	
	        if(dea[i].value >= 0){
	            var y = (c_t_height/2 - (diff[i].value - middle)/base *  c_t_height/2) + this.options.c3_y_top
	        }else{
	            var y = (middle - diff[i].value)/base *  c_t_height/2 + this.options.c3_y_top + c_t_height/2;
	        }        
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	
	        if(i == 0 || y > (this.options.c3_y_top + this.options.c_t_height) || y < this.options.c3_y_top){
	            ctx.moveTo(x,y);
	        }else{
	            ctx.lineTo(x,y);
	        }
	
	    }
	    ctx.stroke();
	
	    
	    // ctx.strokeStyle = "#fe59fe";
	    for(var i = 0;i < macd_length;i++){
	        ctx.beginPath();
	        var x = this.options.padding.left + (i + 1) * unit_w - unit_w/2;
	        if(macd[i].value >= middle){
	            ctx.strokeStyle = "#ff0000";
	            ctx.fillStyle = "#ff0000";
	            var y = (c_t_height/2 - (macd[i].value - middle)/base *  c_t_height/2) + this.options.c3_y_top
	            ctx.rect(x-(unit_w*0.6)/2,y,unit_w*0.6,Math.abs(y-middle_y));
	            ctx.fill();
	            ctx.stroke();
	        }else{
	            ctx.strokeStyle = "#17b03e";
	            ctx.fillStyle = "#17b03e";
	            var y = (middle - diff[i].value)/base *  c_t_height/2 + this.options.c3_y_top + c_t_height/2;
	            ctx.rect(x-(unit_w*0.6)/2,middle_y,unit_w*0.6,Math.abs(y-middle_y));
	            ctx.fill();
	            ctx.stroke();
	        }        
	
	    }
	
	    var middle = (max + min)/2;
	    ctx.fillStyle = "#333";
	    ctx.fillText(common.format_unit(max), 0, this.options.c3_y_top + 5);
	    ctx.fillText(common.format_unit(middle.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height/2);
	    ctx.fillText(common.format_unit(min.toFixed(2)), 0, this.options.c3_y_top + 5 + c_t_height);
	    ctx.beginPath();
	    ctx.restore();
	}
	
	module.exports = drawMACD;

/***/ },
/* 66 */
/***/ function(module, exports, __webpack_require__) {

	var getTData = __webpack_require__(48);
	var common = __webpack_require__(44);
	/*一个测试*/
	var slideBar = function() {
	    var _that = this;
	    var callback = arguments[0];
	
	    if (arguments.length == 1) {
	
	        //第一次绘制元素
	        var data = this.options.data;
	        var arr = [];
	        var arrYear = [];
	        var max = 0;
	        var min = 10000;
	        var len = data.data.length;
	        for (var i = 0; i < data.data.length; i++) {
	            arr.push({ date: data.data[i].date_time, value: data.data[i].close });
	            if (i == 0 || data.data[i].date_time.substring(0, 4) != data.data[i - 1].date_time.substring(0, 4)) {
	                arrYear.push({ year: data.data[i].date_time.substring(0, 4), order: i });
	            }
	            max = Math.max(max, data.data[i].close);
	            min = Math.min(min, data.data[i].close);
	        }
	        //添加包含的容器div和相应的canvas
	        var width = _that.options.drawWidth;
	        var height = _that.options.unit_height * 2;
	        var container = document.createElement("div");
	        container.style.position = "absolute";
	        container.style.left = _that.options.padding.left + "px";
	        container.style.top = _that.options.c4_y_top + "px";
	        _that.container.appendChild(container);
	
	        var cvs = document.createElement("canvas");
	        try {
	            var ctx = cvs.getContext('2d');
	        } catch (error) {
	            cvs = window.G_vmlCanvasManager.initElement(cvs);
	            var ctx = cvs.getContext('2d');
	        }
	        container.appendChild(cvs);
	
	        cvs.width = width;
	        cvs.height = height;
	        cvs.style.width = width + "px";
	        cvs.style.height = height + "px";
	        cvs.className = "slideBarCVS";
	
	        //绘制背景图
	        ctx.strokeStyle = "#59A7FF";
	        ctx.beginPath();
	        for (i = 0; i < len; i++) {
	            if (i == 0) {
	                ctx.moveTo(getX(len, i, cvs.width), getY(max, min, arr[i].value, cvs.height));
	            } else {
	                ctx.lineTo(getX(len, i, cvs.width), getY(max, min, arr[i].value, cvs.height));
	            }
	        }
	        ctx.stroke();
	
	        ctx.lineTo(getX(len, i, cvs.width), getY(max, min, 0, cvs.height));
	        ctx.lineTo(getX(len, 0, cvs.width), getY(max, min, 0, cvs.height));
	        ctx.lineTo(getX(len, 0, cvs.width), getY(max, min, arr[0].value, cvs.height));
	        ctx.fillStyle = "#E4EFFF";
	        ctx.fill();
	
	        //写上年标记
	        var yearLen = arrYear.length;
	        var sapce = 1;
	        if (yearLen <= 2) {
	            sapce  = 1;
	        } else if (yearLen <= 7) {
	            sapce = 2;
	        } else if (yearLen <= 13) {
	            sapce = 3;
	        }else if(yearLen <= 17){
	            sapce = 4;
	        }else{
	            sapce = 5;
	        }
	        for (i = 0; i < yearLen; i += sapce) {
	            drawYear(ctx, arrYear[i].order, arrYear[i].year, arr.length, width, height);
	        }
	
	        //添加滑动块
	        var containerBar = document.createElement("div");
	        containerBar.setAttribute("id", "slideBarWrap");
	        containerBar.style.position = "absolute";
	        containerBar.style.height = height + "px";
	        containerBar.style.width = (len >= 60 ? 60/ len : 1)  * width + "px";
	        containerBar.style.top = "0px";
	        containerBar.style.left = _that.options.start / len * width + "px";
	        containerBar.className = "containerBar";
	
	        var leftDrag = document.createElement("div");
	        leftDrag.style.position = "absolute";
	        leftDrag.style.height = height / 2 + "px";
	        leftDrag.style.width = "7px";
	        leftDrag.style.border = "solid 1px #999";
	        leftDrag.style.top = height / 4 + "px";
	        leftDrag.style.left = "-4px";
	        leftDrag.style.color = "#999";
	        leftDrag.className = "leftDrag";
	        leftDrag.innerHTML = "|";
	
	
	        var rightDrag = document.createElement("div");
	        rightDrag.style.position = "absolute";
	        rightDrag.style.height = height / 2 + "px";
	        rightDrag.style.width = "7px";
	        rightDrag.style.border = "solid 1px #999";
	        rightDrag.style.top = height / 4 + "px";
	        rightDrag.style.right = "-4px";
	        rightDrag.style.color = "#999";
	        rightDrag.className = "rightDrag";
	        rightDrag.innerHTML = "|";
	
	        container.appendChild(containerBar);
	        containerBar.appendChild(leftDrag);
	        containerBar.appendChild(rightDrag);
	
	        //添加滑动块中的事件处理
	        dragEvent.call(_that, callback, arr, cvs, containerBar, leftDrag, rightDrag);
	    } else {
	        var start = _that.options.start;
	        var end = _that.options.end;
	        var len = this.options.data.data.length;
	        var slideBar = document.getElementById("slideBarWrap");
	        var width = _that.options.drawWidth;
	        var slideBarLeft = width * start / len + "px";
	        var slideBarWidth = width * (end - start) / len + "px";
	        slideBar.style.left = slideBarLeft;
	        slideBar.style.width = slideBarWidth;
	        callback.call(_that, start, end);
	    }
	
	}
	
	/*根据数据获取坐标*/
	function getX(len, i, width) {
	    return i / len * width;
	}
	
	/*画年限*/
	function drawYear(ctx, order, yearText, len, totalWidth, totalHeight) {
	    ctx.save()
	    ctx.fillStyle = "#aaa";
	    ctx.strokeStyle = "#aaa";
	    ctx.lineWidth = 1;
	    ctx.beginPath();
	
	    ctx.moveTo(Math.ceil(getX(len, order, totalWidth)) + 0.5, totalHeight);
	    ctx.lineTo(Math.ceil(getX(len, order, totalWidth)) + 0.5, totalHeight / 2);
	    ctx.font = "12px";
	    ctx.fillText(yearText, Math.ceil(getX(len, order, totalWidth) + 5), totalHeight * 2 / 3);
	
	    ctx.stroke();
	    ctx.restore();
	}
	
	function getY(max, min, value, height) {
	    return height - (value - min) / (max - min) * height;
	}
	
	var dragEvent = function(callback, dataArr, container, containerBar, leftDrag, rightDrag) {
	    var _this = this;
	    //containerBar的位置以及宽度
	    var ContainerB_left = toNumber(containerBar.style.left);
	    var ContainerB_width = toNumber(containerBar.style.width);
	    var ContainerB_height = toNumber(containerBar.style.height);
	    //左边拖拽条的位置以及宽度
	    var LeftD_width = toNumber(leftDrag.style.width);
	    var LeftD_left = ContainerB_left - LeftD_width;
	    //右边拖拽条的位置以及宽度
	    var RightD_width = toNumber(rightDrag.style.width);
	    var RightD_left = ContainerB_left + ContainerB_width;
	    var body = document.getElementsByTagName("html")[0];
	    var len = dataArr.length;
	    var width = toNumber(container.style.width);
	    var min_width = (len > 20 ? (20 / len) : 1) * width;
	    //点击状态
	    var clickedLeft = false;
	    var clickedRight = false;
	    var clickedBar = false;
	    //是否点击了点击区
	    var inArea = false;
	    //连击
	    var clickContinue = false;
	    var timer;
	
	    var offset = 0;
	    var pageOffset = getOffset(container);
	
	    common.addEvent(body, "mousedown", function(e) {
	        /*检测点击了哪一个元素*/
	        var winX = e.clientX - pageOffset.left;
	
	        //判断点击了那个区域
	        var target = e.target || e.srcElement;
	        // debugger;
	        if (target == leftDrag) {
	            //点击了左边拖拽
	            clickedLeft = true;
	            inArea = true;
	            offset = ContainerB_left - winX;
	        } else if (target == rightDrag) {
	            //点击了右边拖拽
	            clickedRight = true;
	            inArea = true;
	            offset = winX - ContainerB_left - ContainerB_width;
	        } else if (target == containerBar) {
	            //点击了半透明区域
	            clickedBar = true;
	            inArea = true;
	            offset = winX - ContainerB_left;
	        }
	    });
	
	    common.addEvent(body, "mouseup", function(e) {
	        //状态恢复
	        clickedLeft = false;
	        clickedRight = false;
	        clickedBar = false;
	        body.style.cursor = "default";
	        ContainerB_left = toNumber(containerBar.style.left);
	        ContainerB_width = toNumber(containerBar.style.width);
	        LeftD_left = ContainerB_left - LeftD_width;
	        RightD_left = ContainerB_left + ContainerB_width;
	        var start = ContainerB_left / toNumber(container.style.width);
	        var end = (ContainerB_left + ContainerB_width) / toNumber(container.style.width);
	        if (inArea) {
	            inArea = false;
	            callback.call(_this, getDuring(dataArr, start, end).start, getDuring(dataArr, start, end).end);
	        }
	
	    });
	
	    common.addEvent(body, "mousemove", function(e) {
	
	        var winX = e.clientX - pageOffset.left;
	
	        //判断点击了那个区域
	        if (clickedLeft === true) {
	            //分别改变left和width
	            if ((winX - offset) >= 0) {
	                if (ContainerB_width - (winX + offset - ContainerB_left) > min_width) {
	                    containerBar.style.left = (winX + offset) + "px";
	                    containerBar.style.width = ContainerB_width - (winX + offset - ContainerB_left) + "px";
	                }
	            } else {
	                containerBar.style.left = "0px";
	                containerBar.style.width = ContainerB_width + ContainerB_left + "px";
	            }
	
	        }
	
	        if (clickedRight === true) {
	            //拖动右边
	            if ((winX - offset) <= toNumber(container.style.width)) {
	                //保证最小宽度
	                if (winX - ContainerB_left - offset > min_width) {
	                    containerBar.style.width = winX - ContainerB_left - offset + "px";
	                }
	            } else {
	                //当大于外部元素宽度时，直接复制为靠近右边界
	                containerBar.style.width = (toNumber(container.style.width) - ContainerB_left) + "px";
	            }
	        }
	
	        if (clickedBar === true) {
	            //移动滑块
	            if ((winX - offset) <= 0) {
	                containerBar.style.left = "0px";
	            } else if ((winX - offset) >= (toNumber(container.style.width) - ContainerB_width)) {
	                containerBar.style.left = toNumber(container.style.width) - ContainerB_width + "px";
	            } else {
	                containerBar.style.left = (winX - offset) + "px";
	            }
	
	            ContainerB_left = toNumber(containerBar.style.left);
	            ContainerB_width = toNumber(containerBar.style.width);
	            LeftD_left = ContainerB_left - LeftD_width;
	            RightD_left = ContainerB_left + ContainerB_width;
	            var start = ContainerB_left / toNumber(container.style.width);
	            var end = (ContainerB_left + ContainerB_width) / toNumber(container.style.width);
	            if (inArea) {
	                callback.call(_this, getDuring(dataArr, start, end).start, getDuring(dataArr, start, end).end);
	            }
	
	        }
	        try {
	            e.preventDefault();
	        } catch (e) {
	            e.returnValue = false;
	        }
	    });
	
	    function toNumber(str) {
	        return str.replace("px", "") * 1.0;
	    }
	};
	/*获取e元素相对于整个页面的位置*/
	function getOffset(e) {
	    var result = {};
	    result.top = e.offsetTop;
	    result.left = e.offsetLeft;
	    var parent = e.offsetParent;
	    while (parent) {
	        if (parent.nodeName === "BODY") {
	            break;
	        }
	        result.left += parent.offsetLeft;
	        result.top += parent.offsetTop;
	        parent = parent.offsetParent;
	
	    }
	    return result;
	}
	
	/*根据比例拿时间段*/
	function getDuring(arr, start, end) {
	    var result = {};
	    var len = (arr.length - 1);
	    result.start = Math.floor(len * start);
	    result.end = Math.ceil(len * end);
	    return result;
	}
	
	module.exports = slideBar;


/***/ },
/* 67 */
/***/ function(module, exports, __webpack_require__) {

	// style-loader: Adds some css to the DOM by adding a <style> tag
	
	// load the styles
	var content = __webpack_require__(68);
	if(typeof content === 'string') content = [[module.id, content, '']];
	// add the styles to the DOM
	var update = __webpack_require__(73)(content, {});
	if(content.locals) module.exports = content.locals;
	// Hot Module Replacement
	if(false) {
		// When the styles change, update the <style> tags
		if(!content.locals) {
			module.hot.accept("!!./../../node_modules/css-loader/index.js!./style.css", function() {
				var newContent = require("!!./../../node_modules/css-loader/index.js!./style.css");
				if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
				update(newContent);
			});
		}
		// When the module is disposed, remove the <style> tags
		module.hot.dispose(function() { update(); });
	}

/***/ },
/* 68 */
/***/ function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(69)();
	// imports
	
	
	// module
	exports.push([module.id, "/*手机版图表样式*/\r\n.show-tip {\r\n    position: absolute;\r\n    top: 0px;\r\n    background-color: red;\r\n    z-index: 999;\r\n    border: 0;\r\n    padding: 10px;\r\n    border-radius: 7px;\r\n    background-color: #17b03e;\r\n    color: #fff;\r\n    font-size: 16px;\r\n    font-weight: lighter;\r\n    font-family: 'Microsoft Yahei';\r\n   \r\n}\r\n.show-tip .span-price{\r\n\tfont-size: 22px;\r\n}\r\n.show-tip span{\r\n\tfont-size: 14px;height:25px;line-height:25px;\r\n    white-space: nowrap;\r\n}\r\n\r\n.tip-line-1,.tip-line-2{\r\n\theight:25px;\r\n\tline-height:25px;\r\n}\r\n.time-tip{\r\n\r\n}\r\n.show-tip .span-time-c1{\r\n\ttext-align: left;\r\n\tmargin-right: 10px;\r\n}\r\n.show-tip .span-time-c2{\r\n\ttext-align: right;\r\n}\r\n\r\n.show-tip .span-k-c1{\r\n\ttext-align: left;\r\n\tmargin-right: 10px;\r\n}\r\n.show-tip .span-k-c2{\r\n\ttext-align: right;\r\n}\r\n\r\n\r\n.cross-y{\r\n\tposition:absolute;top:0px;z-index:98;border-left:1px dashed #8f8f8f;width:0px;background-color:#fff;\r\n}\r\n.cross-x{\r\n\tposition:absolute;left:0px;z-index:98;border-top:1px dashed #8f8f8f;height:0px;\r\n}\r\n.cross-p{\r\n\tposition:absolute;z-index:100;\r\n}\r\n.mark-ma{\r\n\tposition:absolute;top:0px;right:0px;z-index:97;border:0;height:30px;line-height:30px;font-family:Microsoft Yahei;font-weight:lighter;\r\n}\r\n.mark-ma span {\r\n\tdisplay:inline-block;padding-right:10px;font-size:14px;text-align:left;color:#ffba42;\r\n}\r\n\r\n.mark-ma .span-m5{\r\n\tcolor:#f4cb15;\r\n}\r\n.mark-ma .span-m10{\r\n\tcolor:#ff5b10;\r\n}\r\n.mark-ma .span-m20{\r\n\tcolor:#488ee6;\r\n}\r\n.mark-ma .span-m30{\r\n\tcolor:#fe59fe;\r\n}\r\n.scale-div{\r\n\tposition:absolute;z-index:99;border:0px;width:90px;height:45px;\r\n\topacity:0.7;\r\n}\r\n.scale-div .span-minus{\r\n\twidth: 30px;height: 30px;float: left;border-radius: 6px;\r\n\tbackground: url(" + __webpack_require__(70) + ") no-repeat center center #cccccc;\r\n}\r\n.scale-div .span-plus{\r\n\twidth: 30px;height: 30px;float: right;border-radius: 6px;\r\n\tbackground: url(" + __webpack_require__(71) + ") no-repeat center center #cccccc;\r\n}\r\n.scale-opacity{\r\n\topacity:0.3;\r\n}\r\n\r\n.header .tool-bar{\r\n    background: -webkit-linear-gradient(top, #4d74ae, #2e5186); /* Safari 5.1 - 6.0 */\r\n    background: -o-linear-gradient(bottom, #4d74ae, #2e5186); /* Opera 11.1 - 12.0 */\r\n    background: -moz-linear-gradient(bottom, #4d74ae, #2e5186); /* Firefox 3.6 - 15 */\r\n    background: linear-gradient(to bottom, #4d74ae, #2e5186); /* 标准的语法 */\r\n\tbackground:#2e5186;\r\n\theight:70px;\r\n}\r\n.header .sepe{\r\n\theight:50px;\r\n\tbackground-color: #d1e1f9;\r\n}\r\n.content{\r\n\tbackground-color: #f2f2f2;\r\n}\r\n\r\n.content .emchart{\r\n\tbackground-color: #fff;\r\n\tpadding:0px 10px;\r\n}\r\n\r\n.tabs{\r\n\tbackground-color: #fff;\r\n\theight:50px;\r\n\tfont-size: 18px;\r\n\tcolor:#000;\r\n\tborder-bottom: 1px solid #ccc;\r\n\tmargin-bottom: 15px;\r\n}\r\n.tabs .tab{\r\n\tfloat:left;\r\n\twidth: 25%;\r\n\theight: 47px;\r\n\tline-height: 47px;\r\n\ttext-align: center;\r\n}\r\n.tabs .tab.current{\r\n\tcolor: #2f5895;\r\n\tborder-bottom: 3px solid #2f5895;\r\n}\r\n\r\n.loading-chart {\r\n\tposition: absolute;\r\n\tleft:0;\r\n\ttop:0;\r\n\tz-index: 100;\r\n\twidth: 100%;\r\n\theight: 100%;\r\n\tbackground-color: #fff;\r\n\ttext-align: center;\r\n\r\n    opacity: 0.7;\r\n    font-size: 20px;\r\n}\r\n\r\n.delay-div{\r\n\tposition: absolute;\r\n\tleft:0;\r\n\ttop:0;\r\n\tz-index: 10000;\r\n\twidth: 100%;\r\n\theight: 100%;\r\n\tbackground-color: #fff;\r\n    opacity: 0;\r\n}\r\n\r\n.mark-point{\r\n\tposition: absolute;\r\n\tz-index: 97;\r\n\tmin-width: 15px;\r\n\tmin-height: 15px;\r\n\tborder-radius: 10px;\r\n\tbackground: url(" + __webpack_require__(72) + ") no-repeat center center/15px 15px #fff;\r\n\topacity: 1;\r\n}\r\n\r\n\r\n/*web港股的样式*/\r\n.web-tips{\r\n\tdisplay: none;\r\n\tleft: -10000px;\r\n\ttop: -10000px;\r\n\tposition: absolute;\r\n\ttext-align: left;\r\n\tbackground-color: #898989;\r\n\tborder-radius: 2px;\r\n\tz-index: 10000;\r\n\tdisplay: inline-block;\r\n\tcolor: white;\r\n\tfont-size: 12px;\r\n\ttext-align: center;\r\n\tpadding: 2px;\r\n\twhite-space:nowrap;\r\n}\r\n.web-middleLine{\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\twidth: 0px;\r\n\tborder-right: dashed 1px #898989;\r\n}\r\n\r\n.tech-index{\r\n\tposition:absolute;\r\n\tz-index: 99;\r\n}\r\n\r\n.tech-index-item{\r\n\tbackground-color: #707070;\r\n\tfloat:left;\r\n\ttext-align: center;\r\n\tcolor:#fff;\r\n\tcursor: pointer;\r\n}\r\n\r\n.tech-index .current{\r\n\tbackground-color: #c2c2c2;\r\n\tcolor:#707070;\r\n}\r\n\r\n\r\n/*web版图表样式*/\r\n.web-show-tip {\r\n\tposition: absolute;\r\n\ttop: 0px;\r\n\tbackground-color: red;\r\n\tz-index: 999;\r\n\tborder: 1px solid #97c8ff;\r\n\t/*padding: 8px;*/\r\n\tbox-shadow: 2px 2px 2px rgba(0,0,0,0.1);\r\n\tbackground-color: #fff;\r\n\tcolor: #666;\r\n\twidth: 120px;\r\n\tfont-size: 12px;\r\n\tfont-weight: lighter;\r\n\tfont-family: 'arial';\r\n\r\n\t/*white-space: nowrap;*/\r\n}\r\n\r\n.web-tip-line-left{\r\n\tfloat: left;\r\n\twidth:50%;\r\n\ttext-align: left;\r\n\theight:20px;\r\n\tline-height: 20px;\r\n\r\n\t*height:15px;\r\n\t*line-height: 15px;\r\n}\r\n\r\n.web-tip-line-right{\r\n\tfloat: left;\r\n\twidth:50%;\r\n\ttext-align: right;\r\n\theight:20px;\r\n\tline-height: 20px;\r\n\t\r\n\t*height:15px;\r\n\t*line-height: 15px;\r\n}\r\n\r\n.web-tip-first-line{\r\n\twidth:100%;\r\n\tbackground: #edf5ff;\r\n\theight:30px;\r\n\tline-height: 30px;\r\n\ttext-align: center;\r\n}\r\n\r\n.web-tip-line-container{\r\n\tpadding:8px;\r\n\t*margin-bottom: 8px;\r\n}\r\n\r\n.time-tips-coordinate{\r\n\tdisplay: none;\r\n\tposition: absolute;\r\n\tpadding: 0px 3px;\r\n\tfont-size: 14px;\r\n\tbackground-color: #aaa;\r\n\tcolor: white;\r\n\tz-index: 1000;\r\n}\r\n.time-tips-top{\r\n\tdisplay: none;\r\n\tfont-size: 14px;\r\n\tcolor: #888;\r\n\tposition: absolute;\r\n\ttop: 0px;\r\n}\r\n\r\n/* web版 k线图指标样式 */\r\n\r\n.kt-pad {\r\n    position: absolute;\r\n    color: #5F5F5F;\r\n    margin-left: 15px;\r\n    min-width: 70px;\r\n}\r\n\r\n.kt-title {\r\n    margin-bottom: 5px;\r\n    font-size: 14px;\r\n}\r\n\r\n.kt-line {\r\n    background-color: white; position: relative; margin: 10px 0px;\r\n}\r\n\r\n.kt-line:hover{\r\n    cursor: pointer;\r\n}\r\n\r\n.kt-radio-wrap{\r\n\tposition: relative; display: inline-block; *zoom:1;*display:inline; border: solid 1px #305896;height: 10px; width: 10px;background-color: white;\r\n}\r\n\r\n.kt-radio {\r\n    position:absolute; margin: 2px; width: 6px; height: 6px; background-color: #305896;display: none;\r\n}\r\n\r\n.kt-name {\r\n    color: #555;line-height: 10px;display: inline-block; height: 10px;padding-left: 5px;position: absolute; top: 3px; left: 15px;\r\n}\r\n\r\n.kt-radio-choose {\r\n    display: block;\r\n}\r\n\r\n/* web k 线的滑动 */\r\n.slideBarCVS{\r\n\tbackground-color: white;\r\n\toutline: solid 1px #E9E9E9;\r\n\r\n}\r\n\r\n.leftDrag{\r\n\tbackground-color: white;\r\n\topacity: 2;\r\n\tfilter: alpha(opacity=200);\r\n}\r\n.leftDrag:hover{\r\n\tcursor: w-resize;\r\n}\r\n\r\n.rightDrag{\r\n\tbackground-color: white;\r\n}\r\n.rightDrag:hover{cursor: e-resize;}\r\n.containerBar{\r\n\tbackground-color: #e0e0e0;\r\n\topacity: 0.5;\r\n\tfilter: alpha(opacity=50);\r\n\tborder:solid 1px #35709C;\r\n}\r\n.containerBar:hover{cursor: move;}", ""]);
	
	// exports


/***/ },
/* 69 */
/***/ function(module, exports) {

	/*
		MIT License http://www.opensource.org/licenses/mit-license.php
		Author Tobias Koppers @sokra
	*/
	// css base code, injected by the css-loader
	module.exports = function() {
		var list = [];
	
		// return the list of modules as css string
		list.toString = function toString() {
			var result = [];
			for(var i = 0; i < this.length; i++) {
				var item = this[i];
				if(item[2]) {
					result.push("@media " + item[2] + "{" + item[1] + "}");
				} else {
					result.push(item[1]);
				}
			}
			return result.join("");
		};
	
		// import a list of modules into the list
		list.i = function(modules, mediaQuery) {
			if(typeof modules === "string")
				modules = [[null, modules, ""]];
			var alreadyImportedModules = {};
			for(var i = 0; i < this.length; i++) {
				var id = this[i][0];
				if(typeof id === "number")
					alreadyImportedModules[id] = true;
			}
			for(i = 0; i < modules.length; i++) {
				var item = modules[i];
				// skip already imported module
				// this implementation is not 100% perfect for weird media query combinations
				//  when a module is imported multiple times with different media queries.
				//  I hope this will never occur (Hey this way we have smaller bundles)
				if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
					if(mediaQuery && !item[2]) {
						item[2] = mediaQuery;
					} else if(mediaQuery) {
						item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
					}
					list.push(item);
				}
			}
		};
		return list;
	};


/***/ },
/* 70 */
/***/ function(module, exports) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAADCAYAAAB4bZQtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAdSURBVHjaYvz///9/BhoBJgYaApoaDgAAAP//AwBSRgQCNPlECAAAAABJRU5ErkJggg=="

/***/ },
/* 71 */
/***/ function(module, exports) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAXCAYAAADgKtSgAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAABFSURBVHjaYjxz5gwDMcDY2Pg/jH327FlGYvQwMdAQjBo+avhIMJzx/////0eDBR2wEFsIjRZco4aPGj4AhgMAAAD//wMAq70Q99ei408AAAAASUVORK5CYII="

/***/ },
/* 72 */
/***/ function(module, exports) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoxQjBBMjM2MjI2REMxMUU2QURERTg3REFCOEYzQUQzNiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoxQjBBMjM2MzI2REMxMUU2QURERTg3REFCOEYzQUQzNiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjFCMEEyMzYwMjZEQzExRTZBRERFODdEQUI4RjNBRDM2IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjFCMEEyMzYxMjZEQzExRTZBRERFODdEQUI4RjNBRDM2Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+FqRI6gAAAypJREFUeNqsVktIlFEUPhND6DRgOfSCCFs0jQYNWTaJ1qRGjQxhRNKDFi2KJCOoyFVFJgQ9XAQtkhRclVCJFoa5GJUpQQrCFmkygdAsejCZYSO1mb7Dvf/8j7nzAg98zP3Pvfd8cx733GtLHKRs4gZ41T6gDHBJfQz4CAwBfcB0JiO2DER+oA3YRblJGLgKjKomlyh0BcADYDgPEpJrh+XegmxExUAIOMPeUv5ik3tD0paSyAG8BCqTmtsTRCvcapOH24kuD6YjrJS2HJrCbpi8B/hMy11riIrWEc3KPJfU6nPTb4kO4c8HkJapN7p+Lqqt90mbp43F4JfxNYer6xvK4RjRTEh4djcs9IXLiBb+6Ov4m4V14RdE3ae0mQRQwwWiEbGF6uS/3h4Uy+pPiI3zc0RPL+le3XxO1Fyue3odHs1MGgmM8poLhXPkTZKweKoEAaN4FZYcEGMtV+xd9DNRQ4v4Zr0bJiLv0+WLbXvZo1YMrqVMbzlK1PqY6EKdOnRaqKyhfHKfaLDNau2GPe1ZKd8rfvccR0hCoijYw/4uEUoWZ5E+ZtmBPc7lKmu7mcijJCqrIPr5nWgbchlpRrgmhX7kkfCwGrqzt8y5cnaC+JfK2ia7oXeZw1boFOOBbqIjFxHceqL2c3pBMDGHqw4l/m5A/xNc3qni4hz9xWCpSc0H8UdUFAKXdyMSH/+NcPrNJW0scU1iX4lavFbtP7vswmtN3ni2EnWeF0QsdwLmbScRopJSlHVVrq0pxkRTJiIuAj47sxm6/koUhsMp2pBRuFt86FHt+GSXh7UmqdKSnUnY4y8Rog2bdd36jeJbTRRmol7TOcpGwl7E51PDpuVVLc+4M0zINpFduNq4kY72pc6xR8YzZW5BE1r3vqJsqkbhLt2I8h7q0fseF467Qhxc12qRI7Mk5K2bvI/4+n2oLFXtXOwMWDuzKBzug3y4eztU+WGbI9Y3g0PejD5aHBkH+AKLW29YVgTlgsUgCWokqjdDTJZ6h4xvvpKQe2ulrYyvoAWgSRKO5UEyJgmajJ7k8q5LHk+gAdgPlFoekNzSXwH9ssOklf8CDADTqe/lOuA5/wAAAABJRU5ErkJggg=="

/***/ },
/* 73 */
/***/ function(module, exports, __webpack_require__) {

	/*
		MIT License http://www.opensource.org/licenses/mit-license.php
		Author Tobias Koppers @sokra
	*/
	var stylesInDom = {},
		memoize = function(fn) {
			var memo;
			return function () {
				if (typeof memo === "undefined") memo = fn.apply(this, arguments);
				return memo;
			};
		},
		isOldIE = memoize(function() {
			return /msie [6-9]\b/.test(window.navigator.userAgent.toLowerCase());
		}),
		getHeadElement = memoize(function () {
			return document.head || document.getElementsByTagName("head")[0];
		}),
		singletonElement = null,
		singletonCounter = 0,
		styleElementsInsertedAtTop = [];
	
	module.exports = function(list, options) {
		if(false) {
			if(typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
		}
	
		options = options || {};
		// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
		// tags it will allow on a page
		if (typeof options.singleton === "undefined") options.singleton = isOldIE();
	
		// By default, add <style> tags to the bottom of <head>.
		if (typeof options.insertAt === "undefined") options.insertAt = "bottom";
	
		var styles = listToStyles(list);
		addStylesToDom(styles, options);
	
		return function update(newList) {
			var mayRemove = [];
			for(var i = 0; i < styles.length; i++) {
				var item = styles[i];
				var domStyle = stylesInDom[item.id];
				domStyle.refs--;
				mayRemove.push(domStyle);
			}
			if(newList) {
				var newStyles = listToStyles(newList);
				addStylesToDom(newStyles, options);
			}
			for(var i = 0; i < mayRemove.length; i++) {
				var domStyle = mayRemove[i];
				if(domStyle.refs === 0) {
					for(var j = 0; j < domStyle.parts.length; j++)
						domStyle.parts[j]();
					delete stylesInDom[domStyle.id];
				}
			}
		};
	}
	
	function addStylesToDom(styles, options) {
		for(var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];
			if(domStyle) {
				domStyle.refs++;
				for(var j = 0; j < domStyle.parts.length; j++) {
					domStyle.parts[j](item.parts[j]);
				}
				for(; j < item.parts.length; j++) {
					domStyle.parts.push(addStyle(item.parts[j], options));
				}
			} else {
				var parts = [];
				for(var j = 0; j < item.parts.length; j++) {
					parts.push(addStyle(item.parts[j], options));
				}
				stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
			}
		}
	}
	
	function listToStyles(list) {
		var styles = [];
		var newStyles = {};
		for(var i = 0; i < list.length; i++) {
			var item = list[i];
			var id = item[0];
			var css = item[1];
			var media = item[2];
			var sourceMap = item[3];
			var part = {css: css, media: media, sourceMap: sourceMap};
			if(!newStyles[id])
				styles.push(newStyles[id] = {id: id, parts: [part]});
			else
				newStyles[id].parts.push(part);
		}
		return styles;
	}
	
	function insertStyleElement(options, styleElement) {
		var head = getHeadElement();
		var lastStyleElementInsertedAtTop = styleElementsInsertedAtTop[styleElementsInsertedAtTop.length - 1];
		if (options.insertAt === "top") {
			if(!lastStyleElementInsertedAtTop) {
				head.insertBefore(styleElement, head.firstChild);
			} else if(lastStyleElementInsertedAtTop.nextSibling) {
				head.insertBefore(styleElement, lastStyleElementInsertedAtTop.nextSibling);
			} else {
				head.appendChild(styleElement);
			}
			styleElementsInsertedAtTop.push(styleElement);
		} else if (options.insertAt === "bottom") {
			head.appendChild(styleElement);
		} else {
			throw new Error("Invalid value for parameter 'insertAt'. Must be 'top' or 'bottom'.");
		}
	}
	
	function removeStyleElement(styleElement) {
		styleElement.parentNode.removeChild(styleElement);
		var idx = styleElementsInsertedAtTop.indexOf(styleElement);
		if(idx >= 0) {
			styleElementsInsertedAtTop.splice(idx, 1);
		}
	}
	
	function createStyleElement(options) {
		var styleElement = document.createElement("style");
		styleElement.type = "text/css";
		insertStyleElement(options, styleElement);
		return styleElement;
	}
	
	function createLinkElement(options) {
		var linkElement = document.createElement("link");
		linkElement.rel = "stylesheet";
		insertStyleElement(options, linkElement);
		return linkElement;
	}
	
	function addStyle(obj, options) {
		var styleElement, update, remove;
	
		if (options.singleton) {
			var styleIndex = singletonCounter++;
			styleElement = singletonElement || (singletonElement = createStyleElement(options));
			update = applyToSingletonTag.bind(null, styleElement, styleIndex, false);
			remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true);
		} else if(obj.sourceMap &&
			typeof URL === "function" &&
			typeof URL.createObjectURL === "function" &&
			typeof URL.revokeObjectURL === "function" &&
			typeof Blob === "function" &&
			typeof btoa === "function") {
			styleElement = createLinkElement(options);
			update = updateLink.bind(null, styleElement);
			remove = function() {
				removeStyleElement(styleElement);
				if(styleElement.href)
					URL.revokeObjectURL(styleElement.href);
			};
		} else {
			styleElement = createStyleElement(options);
			update = applyToTag.bind(null, styleElement);
			remove = function() {
				removeStyleElement(styleElement);
			};
		}
	
		update(obj);
	
		return function updateStyle(newObj) {
			if(newObj) {
				if(newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap)
					return;
				update(obj = newObj);
			} else {
				remove();
			}
		};
	}
	
	var replaceText = (function () {
		var textStore = [];
	
		return function (index, replacement) {
			textStore[index] = replacement;
			return textStore.filter(Boolean).join('\n');
		};
	})();
	
	function applyToSingletonTag(styleElement, index, remove, obj) {
		var css = remove ? "" : obj.css;
	
		if (styleElement.styleSheet) {
			styleElement.styleSheet.cssText = replaceText(index, css);
		} else {
			var cssNode = document.createTextNode(css);
			var childNodes = styleElement.childNodes;
			if (childNodes[index]) styleElement.removeChild(childNodes[index]);
			if (childNodes.length) {
				styleElement.insertBefore(cssNode, childNodes[index]);
			} else {
				styleElement.appendChild(cssNode);
			}
		}
	}
	
	function applyToTag(styleElement, obj) {
		var css = obj.css;
		var media = obj.media;
	
		if(media) {
			styleElement.setAttribute("media", media)
		}
	
		if(styleElement.styleSheet) {
			styleElement.styleSheet.cssText = css;
		} else {
			while(styleElement.firstChild) {
				styleElement.removeChild(styleElement.firstChild);
			}
			styleElement.appendChild(document.createTextNode(css));
		}
	}
	
	function updateLink(linkElement, obj) {
		var css = obj.css;
		var sourceMap = obj.sourceMap;
	
		if(sourceMap) {
			// http://stackoverflow.com/a/26603875
			css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
		}
	
		var blob = new Blob([css], { type: "text/css" });
	
		var oldSrc = linkElement.href;
	
		linkElement.href = URL.createObjectURL(blob);
	
		if(oldSrc)
			URL.revokeObjectURL(oldSrc);
	}


/***/ }
/******/ ]);
//# sourceMappingURL=emcharts.js.map